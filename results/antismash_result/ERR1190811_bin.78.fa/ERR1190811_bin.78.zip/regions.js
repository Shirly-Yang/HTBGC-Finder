var recordData = [
 {
  "length": 17052,
  "seq_id": "c00001_NODE_22..",
  "regions": []
 },
 {
  "length": 15343,
  "seq_id": "c00002_NODE_26..",
  "regions": []
 },
 {
  "length": 13478,
  "seq_id": "c00003_NODE_30..",
  "regions": []
 },
 {
  "length": 10479,
  "seq_id": "c00004_NODE_40..",
  "regions": []
 },
 {
  "length": 9894,
  "seq_id": "c00005_NODE_42..",
  "regions": []
 },
 {
  "length": 9429,
  "seq_id": "c00006_NODE_44..",
  "regions": []
 },
 {
  "length": 9317,
  "seq_id": "c00007_NODE_45..",
  "regions": []
 },
 {
  "length": 9213,
  "seq_id": "c00008_NODE_45..",
  "regions": []
 },
 {
  "length": 9036,
  "seq_id": "c00009_NODE_46..",
  "regions": []
 },
 {
  "length": 8753,
  "seq_id": "c00010_NODE_48..",
  "regions": []
 },
 {
  "length": 8649,
  "seq_id": "c00011_NODE_49..",
  "regions": []
 },
 {
  "length": 8255,
  "seq_id": "c00012_NODE_51..",
  "regions": []
 },
 {
  "length": 8062,
  "seq_id": "c00013_NODE_53..",
  "regions": []
 },
 {
  "length": 8051,
  "seq_id": "c00014_NODE_53..",
  "regions": []
 },
 {
  "length": 7943,
  "seq_id": "c00015_NODE_54..",
  "regions": []
 },
 {
  "length": 7804,
  "seq_id": "c00016_NODE_55..",
  "regions": []
 },
 {
  "length": 7778,
  "seq_id": "c00017_NODE_55..",
  "regions": []
 },
 {
  "length": 7773,
  "seq_id": "c00018_NODE_55..",
  "regions": []
 },
 {
  "length": 7680,
  "seq_id": "c00019_NODE_56..",
  "regions": []
 },
 {
  "length": 7501,
  "seq_id": "c00020_NODE_57..",
  "regions": []
 },
 {
  "length": 7472,
  "seq_id": "c00021_NODE_57..",
  "regions": []
 },
 {
  "length": 7377,
  "seq_id": "c00022_NODE_58..",
  "regions": []
 },
 {
  "length": 7022,
  "seq_id": "c00023_NODE_61..",
  "regions": []
 },
 {
  "length": 6885,
  "seq_id": "c00024_NODE_62..",
  "regions": []
 },
 {
  "length": 6793,
  "seq_id": "c00025_NODE_63..",
  "regions": []
 },
 {
  "length": 6764,
  "seq_id": "c00026_NODE_63..",
  "regions": []
 },
 {
  "length": 6729,
  "seq_id": "c00027_NODE_63..",
  "regions": []
 },
 {
  "length": 6499,
  "seq_id": "c00028_NODE_66..",
  "regions": []
 },
 {
  "length": 6429,
  "seq_id": "c00029_NODE_67..",
  "regions": []
 },
 {
  "length": 6365,
  "seq_id": "c00030_NODE_67..",
  "regions": []
 },
 {
  "length": 6318,
  "seq_id": "c00031_NODE_68..",
  "regions": []
 },
 {
  "length": 6162,
  "seq_id": "c00032_NODE_70..",
  "regions": []
 },
 {
  "length": 6097,
  "seq_id": "c00033_NODE_71..",
  "regions": []
 },
 {
  "length": 6075,
  "seq_id": "c00034_NODE_71..",
  "regions": []
 },
 {
  "length": 5923,
  "seq_id": "c00035_NODE_73..",
  "regions": []
 },
 {
  "length": 5897,
  "seq_id": "c00036_NODE_74..",
  "regions": []
 },
 {
  "length": 5853,
  "seq_id": "c00037_NODE_74..",
  "regions": []
 },
 {
  "length": 5836,
  "seq_id": "c00038_NODE_75..",
  "regions": []
 },
 {
  "length": 5681,
  "seq_id": "c00039_NODE_77..",
  "regions": []
 },
 {
  "length": 5672,
  "seq_id": "c00040_NODE_77..",
  "regions": []
 },
 {
  "length": 5662,
  "seq_id": "c00041_NODE_77..",
  "regions": []
 },
 {
  "length": 5642,
  "seq_id": "c00042_NODE_77..",
  "regions": []
 },
 {
  "length": 5610,
  "seq_id": "c00043_NODE_78..",
  "regions": []
 },
 {
  "length": 5542,
  "seq_id": "c00044_NODE_79..",
  "regions": []
 },
 {
  "length": 5495,
  "seq_id": "c00045_NODE_80..",
  "regions": []
 },
 {
  "length": 5495,
  "seq_id": "c00046_NODE_80..",
  "regions": []
 },
 {
  "length": 5381,
  "seq_id": "c00047_NODE_81..",
  "regions": []
 },
 {
  "length": 5340,
  "seq_id": "c00048_NODE_82..",
  "regions": []
 },
 {
  "length": 5338,
  "seq_id": "c00049_NODE_82..",
  "regions": []
 },
 {
  "length": 5308,
  "seq_id": "c00050_NODE_82..",
  "regions": []
 },
 {
  "length": 5172,
  "seq_id": "c00051_NODE_85..",
  "regions": []
 },
 {
  "length": 5143,
  "seq_id": "c00052_NODE_85..",
  "regions": []
 },
 {
  "length": 5099,
  "seq_id": "c00053_NODE_86..",
  "regions": []
 },
 {
  "length": 5077,
  "seq_id": "c00054_NODE_87..",
  "regions": []
 },
 {
  "length": 5062,
  "seq_id": "c00055_NODE_87..",
  "regions": []
 },
 {
  "length": 5037,
  "seq_id": "c00056_NODE_88..",
  "regions": []
 },
 {
  "length": 5020,
  "seq_id": "c00057_NODE_88..",
  "regions": []
 },
 {
  "length": 5008,
  "seq_id": "c00058_NODE_88..",
  "regions": []
 },
 {
  "length": 4952,
  "seq_id": "c00059_NODE_89..",
  "regions": []
 },
 {
  "length": 4889,
  "seq_id": "c00060_NODE_90..",
  "regions": []
 },
 {
  "length": 4870,
  "seq_id": "c00061_NODE_91..",
  "regions": []
 },
 {
  "length": 4856,
  "seq_id": "c00062_NODE_91..",
  "regions": []
 },
 {
  "length": 4827,
  "seq_id": "c00063_NODE_91..",
  "regions": []
 },
 {
  "length": 4812,
  "seq_id": "c00064_NODE_92..",
  "regions": []
 },
 {
  "length": 4791,
  "seq_id": "c00065_NODE_92..",
  "regions": []
 },
 {
  "length": 4773,
  "seq_id": "c00066_NODE_93..",
  "regions": []
 },
 {
  "length": 4699,
  "seq_id": "c00067_NODE_94..",
  "regions": []
 },
 {
  "length": 4688,
  "seq_id": "c00068_NODE_94..",
  "regions": []
 },
 {
  "length": 4684,
  "seq_id": "c00069_NODE_94..",
  "regions": []
 },
 {
  "length": 4676,
  "seq_id": "c00070_NODE_95..",
  "regions": []
 },
 {
  "length": 4644,
  "seq_id": "c00071_NODE_95..",
  "regions": []
 },
 {
  "length": 4642,
  "seq_id": "c00072_NODE_95..",
  "regions": []
 },
 {
  "length": 4619,
  "seq_id": "c00073_NODE_96..",
  "regions": []
 },
 {
  "length": 4554,
  "seq_id": "c00074_NODE_97..",
  "regions": []
 },
 {
  "length": 4519,
  "seq_id": "c00075_NODE_98..",
  "regions": [
   {
    "start": 1,
    "end": 4519,
    "idx": 1,
    "orfs": [
     {
      "start": 2,
      "end": 1354,
      "strand": -1,
      "locus_tag": "ctg75_1",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg75_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg75_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2 - 1,354,\n (total: 1353 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: AMP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKLSFSTKGWHNKSFEEFCNIAKELKFGGIELHNINGELFKNKDGAFHGYAAAATVRRLYEMKLELPCIDVISDISEDTAIAETESCIKIAKDLHIPNIRIKSAECDNDTAKKFITAVLPKAEKAGVTLVIETSGAFCDTAALRELLDSFASDNLAALWDMYSTFFKAGEQPEETIKNLGAYVKQVHIKDFDGEGFCLIGEGKLPVGDMMSALRSVNYDGFISLEWDPAWCEGLDDSEIIFSHFVNFISQFGDTSKAESALYYNRARTGKYVWKKNLLIDETFSQVLDRMVEEFPDQYAFKYTTLDYTRTYSEFRDDVDEFCRSLIALGVKAGSHVAVWATNIPQWYIDSCKKIKYMFPRAHAAAYVMMSFRVAYYKVHYPLAFYAVYFTVRADKFDIEQCLGGAERVLGNLEELKAKDKLETKDEEQIVILEMVYEMNLRGIELLPIDIY&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00075_NODE_98..&amp;from=0&amp;to=4519\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKLSFSTKGWHNKSFEEFCNIAKELKFGGIELHNINGELFKNKDGAFHGYAAAATVRRLYEMKLELPCIDVISDISEDTAIAETESCIKIAKDLHIPNIRIKSAECDNDTAKKFITAVLPKAEKAGVTLVIETSGAFCDTAALRELLDSFASDNLAALWDMYSTFFKAGEQPEETIKNLGAYVKQVHIKDFDGEGFCLIGEGKLPVGDMMSALRSVNYDGFISLEWDPAWCEGLDDSEIIFSHFVNFISQFGDTSKAESALYYNRARTGKYVWKKNLLIDETFSQVLDRMVEEFPDQYAFKYTTLDYTRTYSEFRDDVDEFCRSLIALGVKAGSHVAVWATNIPQWYIDSCKKIKYMFPRAHAAAYVMMSFRVAYYKVHYPLAFYAVYFTVRADKFDIEQCLGGAERVLGNLEELKAKDKLETKDEEQIVILEMVYEMNLRGIELLPIDIY\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGTTATCGTTTTCTACAAAGGGCTGGCATAACAAAAGCTTTGAAGAATTTTGCAATATTGCAAAAGAGCTTAAATTCGGCGGCATTGAGCTGCACAACATAAACGGCGAGCTGTTTAAAAATAAGGACGGCGCGTTTCACGGCTACGCCGCCGCGGCGACGGTAAGGCGGCTTTACGAAATGAAACTGGAGTTACCGTGTATAGACGTAATTTCCGATATAAGCGAAGATACTGCTATAGCTGAAACCGAAAGCTGCATTAAAATTGCTAAAGATTTGCACATACCGAATATTCGCATAAAATCCGCCGAGTGTGATAATGATACCGCAAAGAAATTTATAACCGCGGTTCTGCCTAAGGCTGAAAAAGCGGGCGTTACGCTTGTTATTGAGACCTCCGGCGCGTTTTGCGATACCGCCGCGCTCAGAGAGCTGCTTGACAGCTTTGCAAGCGATAATTTAGCCGCCCTTTGGGATATGTATTCAACATTTTTCAAGGCGGGCGAGCAACCCGAAGAAACCATTAAAAATTTGGGCGCGTATGTAAAGCAAGTGCATATAAAGGACTTTGACGGCGAGGGCTTTTGCCTTATAGGCGAGGGCAAGCTGCCGGTCGGGGATATGATGTCCGCCCTGCGCTCTGTTAATTACGACGGCTTTATTTCGCTTGAATGGGACCCCGCGTGGTGCGAGGGGCTTGACGACAGCGAGATAATATTCTCCCACTTTGTAAACTTTATAAGCCAGTTTGGGGATACCTCAAAGGCGGAGTCTGCCCTTTATTACAACCGCGCCCGCACCGGAAAATATGTTTGGAAGAAAAACTTGCTTATTGACGAAACCTTTTCGCAGGTGCTTGACAGAATGGTTGAGGAATTTCCCGACCAATACGCCTTTAAATACACCACGCTTGATTATACGAGGACTTACAGCGAATTCCGCGACGATGTGGACGAATTTTGCCGCTCGCTTATAGCGCTGGGGGTAAAGGCAGGCTCGCACGTGGCGGTTTGGGCCACCAATATTCCGCAGTGGTATATCGACAGCTGCAAAAAAATCAAGTATATGTTCCCGCGCGCTCATGCAGCGGCGTATGTTATGATGTCTTTCCGCGTAGCATACTATAAGGTGCATTACCCGCTTGCGTTCTATGCGGTTTATTTCACGGTTCGTGCGGATAAATTTGATATTGAACAGTGCCTCGGCGGCGCGGAACGCGTACTCGGCAATCTTGAGGAGCTTAAGGCAAAGGATAAACTTGAAACAAAGGACGAGGAACAGATAGTTATCCTTGAAATGGTCTACGAGATGAATCTGCGCGGAATCGAGCTGCTCCCGATAGATATTTAC\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 1360,
      "end": 2736,
      "strand": -1,
      "locus_tag": "ctg75_2",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg75_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg75_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,360 - 2,736,\n (total: 1377 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: HMGL-like<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKNIKICDRTLCAAGAHFSFKEKIEISRQLERLNVTAVELPEIENAKTDTLLVRTVASFVKNSVLSVCGGKTRESIDLAADALRTAAKPRIRIELPLSTVGMEYICHKKAPKMGEFITELVSYAKEKCGDTEFCAMDATRADKAFLYEMIDTAIAAGAGVITVSDDAAEQMPDEFAAFIAEIAAHIGGKAEISVMCSDKNGLASAASVMAVKQGADSVKTAVSGDITALEGFAAMIKNCGDTCGFCSDIKNTELNRIIKQIVRITGGKTDTAAPIAAEQSGITLDGSDGKDAVVSAAAVLGYDLSDEDAQKVYEEFRRVAAKKKVGAKELEVIITSTAMQAPPTYTLVNYVINNGNVISASAQVTLERDGNRTTGISIGDGPIDAAFLALEQIIGSRYELEDFKIETVTEGKESIGSALVKLRFSGKLYSGNGISTDIIGASIRAYINAVNKIVYGEA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00075_NODE_98..&amp;from=0&amp;to=4519\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKNIKICDRTLCAAGAHFSFKEKIEISRQLERLNVTAVELPEIENAKTDTLLVRTVASFVKNSVLSVCGGKTRESIDLAADALRTAAKPRIRIELPLSTVGMEYICHKKAPKMGEFITELVSYAKEKCGDTEFCAMDATRADKAFLYEMIDTAIAAGAGVITVSDDAAEQMPDEFAAFIAEIAAHIGGKAEISVMCSDKNGLASAASVMAVKQGADSVKTAVSGDITALEGFAAMIKNCGDTCGFCSDIKNTELNRIIKQIVRITGGKTDTAAPIAAEQSGITLDGSDGKDAVVSAAAVLGYDLSDEDAQKVYEEFRRVAAKKKVGAKELEVIITSTAMQAPPTYTLVNYVINNGNVISASAQVTLERDGNRTTGISIGDGPIDAAFLALEQIIGSRYELEDFKIETVTEGKESIGSALVKLRFSGKLYSGNGISTDIIGASIRAYINAVNKIVYGEA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAAACATTAAAATCTGCGACAGAACGCTCTGCGCGGCAGGGGCGCATTTCAGCTTTAAGGAAAAAATAGAAATTTCACGTCAGCTTGAAAGGCTTAACGTCACCGCGGTCGAGCTGCCCGAAATTGAAAACGCAAAGACCGATACTTTACTTGTGCGCACGGTGGCGTCGTTTGTTAAAAACAGCGTGTTATCGGTTTGCGGCGGTAAAACGCGCGAGAGCATTGATTTAGCCGCCGACGCGCTGCGCACCGCCGCAAAACCGCGTATTCGCATTGAGCTGCCGCTTTCTACCGTGGGTATGGAATATATATGCCACAAAAAAGCGCCTAAAATGGGCGAGTTTATAACCGAACTTGTAAGCTATGCAAAGGAAAAGTGCGGCGATACCGAGTTTTGCGCTATGGACGCAACGCGTGCTGACAAGGCTTTTCTTTACGAAATGATCGATACCGCAATAGCGGCGGGCGCGGGCGTTATTACCGTAAGCGACGACGCAGCGGAGCAAATGCCCGATGAATTTGCCGCCTTTATTGCCGAAATCGCCGCACATATAGGCGGCAAAGCCGAAATTTCGGTTATGTGCAGCGATAAAAACGGGCTGGCTTCCGCCGCGTCGGTTATGGCGGTAAAGCAGGGGGCTGACAGCGTTAAAACCGCCGTTTCGGGCGATATTACCGCGCTTGAGGGCTTTGCCGCAATGATAAAAAACTGCGGCGATACCTGCGGCTTTTGTTCAGACATTAAAAATACCGAGCTTAACAGAATTATAAAGCAGATTGTAAGAATTACGGGCGGCAAAACAGATACCGCAGCCCCCATAGCAGCCGAGCAGAGCGGAATTACCCTTGACGGCAGCGACGGAAAGGACGCGGTCGTATCTGCCGCGGCGGTGCTTGGGTACGATTTATCGGACGAGGACGCGCAAAAGGTTTACGAGGAGTTTCGCCGCGTAGCGGCTAAAAAGAAAGTAGGCGCCAAGGAGCTTGAGGTTATTATTACAAGCACGGCTATGCAGGCGCCGCCCACATATACGCTTGTGAATTACGTTATAAACAACGGCAATGTAATTTCCGCCTCGGCTCAGGTAACGCTTGAGCGCGACGGTAATCGCACTACGGGCATAAGCATAGGCGACGGACCTATTGACGCGGCGTTTTTGGCGCTTGAGCAGATTATAGGCAGCCGCTATGAGCTTGAGGATTTTAAAATCGAGACCGTAACCGAGGGTAAGGAGTCGATAGGCAGCGCGCTTGTTAAGCTGCGCTTTTCGGGCAAGCTTTATTCGGGCAACGGTATTTCAACCGATATTATAGGTGCGAGCATAAGGGCGTACATAAACGCCGTTAATAAGATAGTTTACGGGGAGGCTTGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 3195,
      "end": 4517,
      "strand": 1,
      "locus_tag": "ctg75_3",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg75_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg75_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,195 - 4,517,\n (total: 1323 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKFYEKLNEYISALNCTAKDIARISGISAATLSRYRSGERAPETGSEVFSKLCSAIAEAAGERGITDITEKSVADAFLSCEDFKTADKNRLCRNFSALAAALDINLAELCRHTNYDASTVFRFKNGTRRPSEPEKFADDAAQYISGIINTKEIAAVLYEATGIKGGSRASLYADIKNWLLNSESPAESGRGVSVFLNKLDEFDLNKYIKAIHFDEVKVPSLPFQLPTSKYYYGISEMMQSELDFLKATVLSKSNGSVTLYSDMPMTEMAKDKEFPKKWMYGMALMLKKGLHLNNIHNIDRSFEEMMLGLESWIPMYMTGQISPYYLKRAPGGTFNHFLRVSGAAALSGEAIAGFHSNGRYYLSKTKEDIAYYQKRADDLLKNASPLMDIYREDSAQRLNAFLLTDSETAGNRRSVLSVPPVYTADNAYLEKLLAAHGISAE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00075_NODE_98..&amp;from=0&amp;to=4519\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKFYEKLNEYISALNCTAKDIARISGISAATLSRYRSGERAPETGSEVFSKLCSAIAEAAGERGITDITEKSVADAFLSCEDFKTADKNRLCRNFSALAAALDINLAELCRHTNYDASTVFRFKNGTRRPSEPEKFADDAAQYISGIINTKEIAAVLYEATGIKGGSRASLYADIKNWLLNSESPAESGRGVSVFLNKLDEFDLNKYIKAIHFDEVKVPSLPFQLPTSKYYYGISEMMQSELDFLKATVLSKSNGSVTLYSDMPMTEMAKDKEFPKKWMYGMALMLKKGLHLNNIHNIDRSFEEMMLGLESWIPMYMTGQISPYYLKRAPGGTFNHFLRVSGAAALSGEAIAGFHSNGRYYLSKTKEDIAYYQKRADDLLKNASPLMDIYREDSAQRLNAFLLTDSETAGNRRSVLSVPPVYTADNAYLEKLLAAHGISAE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAATTTTACGAAAAATTAAACGAATATATAAGCGCCCTAAACTGTACCGCAAAGGATATAGCCCGTATATCGGGAATTTCCGCAGCAACGCTCAGCCGTTACCGTTCGGGCGAAAGGGCCCCCGAAACAGGATCGGAGGTATTTTCAAAGCTTTGCTCCGCTATTGCCGAAGCCGCAGGAGAACGCGGTATAACCGATATAACCGAAAAAAGCGTTGCAGACGCCTTTCTTTCCTGCGAAGACTTTAAAACGGCTGATAAAAACAGGCTTTGCCGCAATTTCAGCGCGCTTGCAGCCGCTCTTGACATTAACCTTGCCGAACTTTGCAGGCATACCAATTACGACGCTTCAACCGTTTTCCGCTTTAAAAACGGCACGCGCAGACCGTCCGAACCCGAAAAATTTGCAGACGACGCCGCACAGTATATTTCCGGCATAATAAATACAAAGGAAATTGCCGCCGTGCTTTACGAGGCAACGGGCATTAAGGGCGGCAGCAGGGCTTCGCTTTACGCCGATATTAAGAATTGGCTGCTCAACAGCGAAAGCCCTGCGGAAAGCGGGCGCGGCGTTTCGGTTTTTTTGAATAAGCTTGATGAATTTGACCTAAACAAATACATAAAGGCAATACATTTTGATGAGGTGAAGGTGCCGTCGCTCCCGTTTCAGCTGCCCACCTCTAAATACTATTACGGGATTTCGGAAATGATGCAAAGCGAGCTTGATTTTCTTAAAGCTACCGTGCTTTCAAAATCAAACGGCAGCGTTACGCTTTACAGCGATATGCCGATGACCGAAATGGCAAAGGATAAGGAATTTCCTAAAAAATGGATGTACGGTATGGCGCTTATGCTTAAAAAGGGTCTGCATCTTAATAATATACATAATATAGACCGCTCCTTTGAGGAAATGATGTTGGGCCTTGAAAGCTGGATTCCGATGTATATGACCGGTCAGATCTCCCCGTATTACCTTAAACGGGCGCCCGGCGGCACATTTAACCATTTTTTGCGTGTTTCGGGCGCGGCGGCGCTTTCCGGCGAGGCAATAGCCGGCTTTCACTCAAACGGAAGATACTACCTTTCAAAAACAAAGGAGGATATAGCCTATTACCAGAAACGGGCGGACGATCTTTTGAAAAACGCGTCCCCCTTAATGGATATTTACCGGGAAGACAGCGCGCAGCGGCTTAACGCGTTTTTACTTACAGACTCTGAAACCGCGGGAAACCGAAGAAGCGTTTTATCCGTGCCGCCTGTTTACACGGCGGATAACGCTTACCTTGAAAAGCTTTTGGCGGCGCACGGTATTTCGGCGGAG\">Copy to clipboard</span><br>\n</div>"
     }
    ],
    "clusters": [
     {
      "start": 1,
      "end": 2736,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 4519,
      "product": "betalactone",
      "category": "other",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "ttaCodons": [],
    "type": "betalactone",
    "products": [
     "betalactone"
    ],
    "product_categories": [
     "other"
    ],
    "cssClass": "other betalactone",
    "anchor": "r75c1"
   }
  ]
 },
 {
  "length": 4510,
  "seq_id": "c00076_NODE_98..",
  "regions": []
 },
 {
  "length": 4503,
  "seq_id": "c00077_NODE_99..",
  "regions": []
 },
 {
  "length": 4485,
  "seq_id": "c00078_NODE_99..",
  "regions": []
 },
 {
  "length": 4426,
  "seq_id": "c00079_NODE_10..",
  "regions": []
 },
 {
  "length": 4371,
  "seq_id": "c00080_NODE_10..",
  "regions": []
 },
 {
  "length": 4360,
  "seq_id": "c00081_NODE_10..",
  "regions": []
 },
 {
  "length": 4359,
  "seq_id": "c00082_NODE_10..",
  "regions": []
 },
 {
  "length": 4358,
  "seq_id": "c00083_NODE_10..",
  "regions": []
 },
 {
  "length": 4352,
  "seq_id": "c00084_NODE_10..",
  "regions": []
 },
 {
  "length": 4338,
  "seq_id": "c00085_NODE_10..",
  "regions": []
 },
 {
  "length": 4325,
  "seq_id": "c00086_NODE_10..",
  "regions": []
 },
 {
  "length": 4316,
  "seq_id": "c00087_NODE_10..",
  "regions": []
 },
 {
  "length": 4288,
  "seq_id": "c00088_NODE_10..",
  "regions": []
 },
 {
  "length": 4213,
  "seq_id": "c00089_NODE_10..",
  "regions": []
 },
 {
  "length": 4184,
  "seq_id": "c00090_NODE_10..",
  "regions": []
 },
 {
  "length": 4130,
  "seq_id": "c00091_NODE_10..",
  "regions": []
 },
 {
  "length": 4127,
  "seq_id": "c00092_NODE_10..",
  "regions": []
 },
 {
  "length": 4124,
  "seq_id": "c00093_NODE_10..",
  "regions": []
 },
 {
  "length": 4124,
  "seq_id": "c00094_NODE_10..",
  "regions": []
 },
 {
  "length": 4123,
  "seq_id": "c00095_NODE_10..",
  "regions": []
 },
 {
  "length": 4098,
  "seq_id": "c00096_NODE_10..",
  "regions": []
 },
 {
  "length": 4088,
  "seq_id": "c00097_NODE_10..",
  "regions": []
 },
 {
  "length": 4065,
  "seq_id": "c00098_NODE_11..",
  "regions": []
 },
 {
  "length": 4055,
  "seq_id": "c00099_NODE_11..",
  "regions": []
 },
 {
  "length": 4032,
  "seq_id": "c00100_NODE_11..",
  "regions": []
 },
 {
  "length": 4004,
  "seq_id": "c00101_NODE_11..",
  "regions": []
 },
 {
  "length": 4003,
  "seq_id": "c00102_NODE_11..",
  "regions": []
 },
 {
  "length": 3991,
  "seq_id": "c00103_NODE_11..",
  "regions": []
 },
 {
  "length": 3988,
  "seq_id": "c00104_NODE_11..",
  "regions": []
 },
 {
  "length": 3984,
  "seq_id": "c00105_NODE_11..",
  "regions": []
 },
 {
  "length": 3974,
  "seq_id": "c00106_NODE_11..",
  "regions": []
 },
 {
  "length": 3973,
  "seq_id": "c00107_NODE_11..",
  "regions": []
 },
 {
  "length": 3931,
  "seq_id": "c00108_NODE_11..",
  "regions": []
 },
 {
  "length": 3913,
  "seq_id": "c00109_NODE_11..",
  "regions": []
 },
 {
  "length": 3885,
  "seq_id": "c00110_NODE_11..",
  "regions": []
 },
 {
  "length": 3875,
  "seq_id": "c00111_NODE_11..",
  "regions": []
 },
 {
  "length": 3866,
  "seq_id": "c00112_NODE_11..",
  "regions": []
 },
 {
  "length": 3859,
  "seq_id": "c00113_NODE_11..",
  "regions": []
 },
 {
  "length": 3813,
  "seq_id": "c00114_NODE_11..",
  "regions": []
 },
 {
  "length": 3786,
  "seq_id": "c00115_NODE_11..",
  "regions": []
 },
 {
  "length": 3783,
  "seq_id": "c00116_NODE_11..",
  "regions": []
 },
 {
  "length": 3773,
  "seq_id": "c00117_NODE_11..",
  "regions": []
 },
 {
  "length": 3757,
  "seq_id": "c00118_NODE_12..",
  "regions": []
 },
 {
  "length": 3745,
  "seq_id": "c00119_NODE_12..",
  "regions": []
 },
 {
  "length": 3743,
  "seq_id": "c00120_NODE_12..",
  "regions": []
 },
 {
  "length": 3734,
  "seq_id": "c00121_NODE_12..",
  "regions": []
 },
 {
  "length": 3730,
  "seq_id": "c00122_NODE_12..",
  "regions": []
 },
 {
  "length": 3726,
  "seq_id": "c00123_NODE_12..",
  "regions": []
 },
 {
  "length": 3693,
  "seq_id": "c00124_NODE_12..",
  "regions": []
 },
 {
  "length": 3679,
  "seq_id": "c00125_NODE_12..",
  "regions": []
 },
 {
  "length": 3658,
  "seq_id": "c00126_NODE_12..",
  "regions": []
 },
 {
  "length": 3653,
  "seq_id": "c00127_NODE_12..",
  "regions": []
 },
 {
  "length": 3642,
  "seq_id": "c00128_NODE_12..",
  "regions": []
 },
 {
  "length": 3641,
  "seq_id": "c00129_NODE_12..",
  "regions": []
 },
 {
  "length": 3627,
  "seq_id": "c00130_NODE_12..",
  "regions": []
 },
 {
  "length": 3627,
  "seq_id": "c00131_NODE_12..",
  "regions": []
 },
 {
  "length": 3623,
  "seq_id": "c00132_NODE_12..",
  "regions": []
 },
 {
  "length": 3615,
  "seq_id": "c00133_NODE_12..",
  "regions": []
 },
 {
  "length": 3591,
  "seq_id": "c00134_NODE_12..",
  "regions": []
 },
 {
  "length": 3565,
  "seq_id": "c00135_NODE_12..",
  "regions": []
 },
 {
  "length": 3553,
  "seq_id": "c00136_NODE_12..",
  "regions": []
 },
 {
  "length": 3550,
  "seq_id": "c00137_NODE_12..",
  "regions": []
 },
 {
  "length": 3512,
  "seq_id": "c00138_NODE_12..",
  "regions": []
 },
 {
  "length": 3478,
  "seq_id": "c00139_NODE_13..",
  "regions": []
 },
 {
  "length": 3477,
  "seq_id": "c00140_NODE_13..",
  "regions": []
 },
 {
  "length": 3467,
  "seq_id": "c00141_NODE_13..",
  "regions": []
 },
 {
  "length": 3456,
  "seq_id": "c00142_NODE_13..",
  "regions": []
 },
 {
  "length": 3454,
  "seq_id": "c00143_NODE_13..",
  "regions": []
 },
 {
  "length": 3446,
  "seq_id": "c00144_NODE_13..",
  "regions": []
 },
 {
  "length": 3439,
  "seq_id": "c00145_NODE_13..",
  "regions": []
 },
 {
  "length": 3434,
  "seq_id": "c00146_NODE_13..",
  "regions": []
 },
 {
  "length": 3397,
  "seq_id": "c00147_NODE_13..",
  "regions": []
 },
 {
  "length": 3389,
  "seq_id": "c00148_NODE_13..",
  "regions": []
 },
 {
  "length": 3369,
  "seq_id": "c00149_NODE_13..",
  "regions": []
 },
 {
  "length": 3353,
  "seq_id": "c00150_NODE_13..",
  "regions": []
 },
 {
  "length": 3350,
  "seq_id": "c00151_NODE_13..",
  "regions": []
 },
 {
  "length": 3343,
  "seq_id": "c00152_NODE_13..",
  "regions": []
 },
 {
  "length": 3340,
  "seq_id": "c00153_NODE_13..",
  "regions": []
 },
 {
  "length": 3302,
  "seq_id": "c00154_NODE_13..",
  "regions": []
 },
 {
  "length": 3296,
  "seq_id": "c00155_NODE_13..",
  "regions": []
 },
 {
  "length": 3292,
  "seq_id": "c00156_NODE_13..",
  "regions": []
 },
 {
  "length": 3285,
  "seq_id": "c00157_NODE_13..",
  "regions": []
 },
 {
  "length": 3272,
  "seq_id": "c00158_NODE_13..",
  "regions": []
 },
 {
  "length": 3263,
  "seq_id": "c00159_NODE_13..",
  "regions": []
 },
 {
  "length": 3245,
  "seq_id": "c00160_NODE_14..",
  "regions": []
 },
 {
  "length": 3205,
  "seq_id": "c00161_NODE_14..",
  "regions": []
 },
 {
  "length": 3199,
  "seq_id": "c00162_NODE_14..",
  "regions": []
 },
 {
  "length": 3194,
  "seq_id": "c00163_NODE_14..",
  "regions": []
 },
 {
  "length": 3177,
  "seq_id": "c00164_NODE_14..",
  "regions": []
 },
 {
  "length": 3138,
  "seq_id": "c00165_NODE_14..",
  "regions": []
 },
 {
  "length": 3134,
  "seq_id": "c00166_NODE_14..",
  "regions": []
 },
 {
  "length": 3130,
  "seq_id": "c00167_NODE_14..",
  "regions": []
 },
 {
  "length": 3101,
  "seq_id": "c00168_NODE_14..",
  "regions": []
 },
 {
  "length": 3085,
  "seq_id": "c00169_NODE_14..",
  "regions": []
 },
 {
  "length": 3082,
  "seq_id": "c00170_NODE_14..",
  "regions": []
 },
 {
  "length": 3082,
  "seq_id": "c00171_NODE_14..",
  "regions": []
 },
 {
  "length": 3077,
  "seq_id": "c00172_NODE_14..",
  "regions": []
 },
 {
  "length": 3062,
  "seq_id": "c00173_NODE_14..",
  "regions": []
 },
 {
  "length": 3058,
  "seq_id": "c00174_NODE_14..",
  "regions": []
 },
 {
  "length": 3050,
  "seq_id": "c00175_NODE_15..",
  "regions": []
 },
 {
  "length": 3044,
  "seq_id": "c00176_NODE_15..",
  "regions": []
 },
 {
  "length": 3035,
  "seq_id": "c00177_NODE_15..",
  "regions": []
 },
 {
  "length": 3023,
  "seq_id": "c00178_NODE_15..",
  "regions": []
 },
 {
  "length": 3015,
  "seq_id": "c00179_NODE_15..",
  "regions": []
 },
 {
  "length": 3008,
  "seq_id": "c00180_NODE_15..",
  "regions": []
 },
 {
  "length": 2997,
  "seq_id": "c00181_NODE_15..",
  "regions": []
 },
 {
  "length": 2991,
  "seq_id": "c00182_NODE_15..",
  "regions": []
 },
 {
  "length": 2968,
  "seq_id": "c00183_NODE_15..",
  "regions": []
 },
 {
  "length": 2962,
  "seq_id": "c00184_NODE_15..",
  "regions": []
 },
 {
  "length": 2936,
  "seq_id": "c00185_NODE_15..",
  "regions": []
 },
 {
  "length": 2918,
  "seq_id": "c00186_NODE_15..",
  "regions": []
 },
 {
  "length": 2905,
  "seq_id": "c00187_NODE_15..",
  "regions": []
 },
 {
  "length": 2897,
  "seq_id": "c00188_NODE_15..",
  "regions": []
 },
 {
  "length": 2894,
  "seq_id": "c00189_NODE_15..",
  "regions": []
 },
 {
  "length": 2880,
  "seq_id": "c00190_NODE_16..",
  "regions": []
 },
 {
  "length": 2868,
  "seq_id": "c00191_NODE_16..",
  "regions": []
 },
 {
  "length": 2860,
  "seq_id": "c00192_NODE_16..",
  "regions": []
 },
 {
  "length": 2836,
  "seq_id": "c00193_NODE_16..",
  "regions": []
 },
 {
  "length": 2830,
  "seq_id": "c00194_NODE_16..",
  "regions": []
 },
 {
  "length": 2819,
  "seq_id": "c00195_NODE_16..",
  "regions": []
 },
 {
  "length": 2793,
  "seq_id": "c00196_NODE_16..",
  "regions": []
 },
 {
  "length": 2787,
  "seq_id": "c00197_NODE_16..",
  "regions": []
 },
 {
  "length": 2785,
  "seq_id": "c00198_NODE_16..",
  "regions": []
 },
 {
  "length": 2775,
  "seq_id": "c00199_NODE_16..",
  "regions": []
 },
 {
  "length": 2753,
  "seq_id": "c00200_NODE_16..",
  "regions": []
 },
 {
  "length": 2744,
  "seq_id": "c00201_NODE_16..",
  "regions": []
 },
 {
  "length": 2732,
  "seq_id": "c00202_NODE_17..",
  "regions": []
 },
 {
  "length": 2723,
  "seq_id": "c00203_NODE_17..",
  "regions": []
 },
 {
  "length": 2690,
  "seq_id": "c00204_NODE_17..",
  "regions": []
 },
 {
  "length": 2688,
  "seq_id": "c00205_NODE_17..",
  "regions": []
 },
 {
  "length": 2684,
  "seq_id": "c00206_NODE_17..",
  "regions": []
 },
 {
  "length": 2672,
  "seq_id": "c00207_NODE_17..",
  "regions": []
 },
 {
  "length": 2659,
  "seq_id": "c00208_NODE_17..",
  "regions": []
 },
 {
  "length": 2653,
  "seq_id": "c00209_NODE_17..",
  "regions": []
 },
 {
  "length": 2650,
  "seq_id": "c00210_NODE_17..",
  "regions": [
   {
    "start": 1,
    "end": 2650,
    "idx": 1,
    "orfs": [
     {
      "start": 3,
      "end": 545,
      "strand": -1,
      "locus_tag": "ctg210_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg210_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg210_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 545,\n (total: 543 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRIYENPKSTSENRLNARSWYIPEGSCKQIMLNGEWRFAFFENGDRAGNIEEWETIEVPSCWQLKGYENPNYTNINYPFPCDPPYVPDINPTGVYERSFQIEDGSLETYFVFEGISSEAELYINGKYVGRTQGSRLTAEFDITEFVSSGTNTARVYVRKWCCGSYLEDQDAFRYNGIFRDV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00210_NODE_17..&amp;from=0&amp;to=2650\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRIYENPKSTSENRLNARSWYIPEGSCKQIMLNGEWRFAFFENGDRAGNIEEWETIEVPSCWQLKGYENPNYTNINYPFPCDPPYVPDINPTGVYERSFQIEDGSLETYFVFEGISSEAELYINGKYVGRTQGSRLTAEFDITEFVSSGTNTARVYVRKWCCGSYLEDQDAFRYNGIFRDV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCGAATATACGAAAACCCAAAAAGCACAAGTGAAAACAGGCTTAATGCCAGAAGCTGGTATATACCGGAAGGCAGCTGCAAGCAAATAATGCTTAACGGCGAATGGCGCTTTGCGTTTTTTGAAAACGGCGACCGTGCAGGTAATATAGAGGAATGGGAAACTATCGAGGTTCCGTCCTGCTGGCAGCTAAAGGGCTATGAAAACCCGAATTATACAAATATCAACTATCCGTTCCCGTGCGATCCGCCCTATGTGCCGGATATTAACCCCACGGGCGTTTACGAGCGCAGCTTTCAGATAGAGGACGGCAGCCTTGAGACTTATTTTGTGTTCGAGGGCATATCTTCGGAAGCAGAGCTTTACATAAACGGCAAATATGTCGGCAGAACGCAGGGCAGCCGTTTAACGGCGGAGTTTGATATAACCGAATTTGTAAGTTCGGGCACAAACACCGCGCGCGTGTATGTTCGCAAATGGTGCTGCGGCAGTTACCTTGAGGATCAGGACGCATTCCGTTATAACGGCATTTTCAGGGACGTA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 599,
      "end": 1069,
      "strand": -1,
      "locus_tag": "ctg210_2",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg210_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg210_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 599 - 1,069,\n (total: 471 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTAESNLKNAAEALSESEEISVLTAGISMRPMLREHKDIAVIRRKSGRLKRNDVPLYSRPGSEKFILHRILKVTPNGYVIRGDNLFKKEYDIKDENIVGVLRAFYRGGRYIDCEKSRGYKLYVFLNRASYPARYFWRGLIRPTLGKIKRLIIRKNY&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00210_NODE_17..&amp;from=0&amp;to=2650\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTAESNLKNAAEALSESEEISVLTAGISMRPMLREHKDIAVIRRKSGRLKRNDVPLYSRPGSEKFILHRILKVTPNGYVIRGDNLFKKEYDIKDENIVGVLRAFYRGGRYIDCEKSRGYKLYVFLNRASYPARYFWRGLIRPTLGKIKRLIIRKNY\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACAGCCGAAAGCAATCTTAAAAACGCAGCCGAGGCTTTAAGCGAAAGCGAGGAAATATCGGTTTTAACCGCAGGGATAAGTATGCGCCCTATGCTTCGCGAGCATAAGGATATAGCGGTTATAAGGCGAAAAAGCGGAAGACTTAAAAGAAACGACGTTCCGCTTTATTCAAGACCGGGCAGTGAAAAGTTTATTTTACACCGCATATTAAAGGTTACGCCTAACGGGTACGTTATACGGGGCGATAATCTTTTTAAAAAGGAATACGATATCAAGGACGAAAATATCGTAGGGGTGTTAAGGGCGTTTTACCGCGGCGGAAGGTATATAGACTGCGAAAAAAGCCGCGGCTATAAGCTATATGTGTTTTTAAACAGGGCAAGCTACCCCGCAAGATATTTTTGGCGCGGTCTTATCCGCCCGACGCTCGGAAAAATCAAGAGGCTCATTATAAGAAAAAATTATTGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 1066,
      "end": 1332,
      "strand": -1,
      "locus_tag": "ctg210_3",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg210_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg210_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,066 - 1,332,\n (total: 267 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKLKYNFVMNKVADKTVAVAVGDDLANFGGFIKMNDTGAFIFGLLKKDITKEEIINAVMNEYEGVTKPEAEASVSEFLDQLKQSDVIE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00210_NODE_17..&amp;from=0&amp;to=2650\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKLKYNFVMNKVADKTVAVAVGDDLANFGGFIKMNDTGAFIFGLLKKDITKEEIINAVMNEYEGVTKPEAEASVSEFLDQLKQSDVIE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGCTTAAATACAATTTTGTTATGAATAAGGTAGCGGACAAAACAGTTGCGGTTGCCGTGGGGGACGATCTTGCGAATTTCGGCGGCTTTATTAAAATGAACGATACCGGCGCGTTTATTTTCGGTCTTCTTAAAAAGGATATAACAAAGGAAGAAATTATAAACGCGGTTATGAACGAGTATGAAGGCGTAACAAAGCCCGAAGCCGAAGCGTCCGTTTCTGAATTTTTAGATCAACTGAAGCAGTCGGACGTGATAGAATGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 1322,
      "end": 2044,
      "strand": -1,
      "locus_tag": "ctg210_4",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg210_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg210_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,322 - 2,044,\n (total: 723 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNIMLADRVISVEYRDKRFADFFARWETERTDSELTVITDEEKIAAERVFNIKDDFYPESSAILRSIAEWLPLNNSFLLHSAVFEVNDSGVALAAHSGTGKTTHMLLWQKLLGDKLKIINGDKPIIRFFENEPETPYAYGTPWNGKEHFGNAERTPLRHLCFVERAGVNSCERVTAEEITNRVLSQVYMPYSAQAAANTLTLINRLVSSVKLWKIKCNTDISAAGTAYNAIFKGEEKNEA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00210_NODE_17..&amp;from=0&amp;to=2650\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNIMLADRVISVEYRDKRFADFFARWETERTDSELTVITDEEKIAAERVFNIKDDFYPESSAILRSIAEWLPLNNSFLLHSAVFEVNDSGVALAAHSGTGKTTHMLLWQKLLGDKLKIINGDKPIIRFFENEPETPYAYGTPWNGKEHFGNAERTPLRHLCFVERAGVNSCERVTAEEITNRVLSQVYMPYSAQAAANTLTLINRLVSSVKLWKIKCNTDISAAGTAYNAIFKGEEKNEA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAATATAATGTTGGCAGATCGGGTAATAAGCGTTGAATACCGCGATAAGCGTTTTGCGGATTTTTTTGCGCGCTGGGAAACCGAAAGAACCGATTCCGAGCTTACCGTTATAACCGATGAAGAAAAAATCGCCGCCGAGCGCGTTTTTAACATAAAGGACGATTTTTATCCCGAAAGCTCGGCGATACTTCGCAGTATTGCGGAATGGCTGCCGCTTAATAATTCCTTTTTGCTTCATTCGGCGGTTTTTGAGGTGAACGACAGCGGCGTTGCGCTTGCGGCGCACAGCGGAACGGGAAAAACCACGCATATGCTTTTGTGGCAAAAGCTTTTAGGCGATAAGCTTAAAATTATAAACGGCGATAAGCCGATAATCCGTTTTTTTGAAAACGAGCCCGAAACGCCCTATGCCTACGGCACGCCGTGGAACGGCAAGGAGCATTTCGGAAACGCGGAGCGTACGCCGCTTCGTCATTTATGCTTTGTGGAACGTGCGGGCGTTAATTCGTGCGAGCGGGTAACCGCAGAGGAAATTACAAACCGCGTGCTAAGTCAGGTGTATATGCCGTACTCCGCACAGGCCGCGGCGAACACGCTAACGCTTATAAACCGCCTTGTTTCATCGGTAAAGCTTTGGAAAATAAAATGCAATACCGATATATCCGCGGCAGGAACCGCATATAACGCCATATTTAAAGGAGAAGAAAAAAATGAAGCTTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 2260,
      "end": 2445,
      "strand": 1,
      "locus_tag": "ctg210_5",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg210_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg210_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,260 - 2,445,\n (total: 186 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTLSMLLRTLFEILLFAAVVWGFFNEDRLAAFEKRVICAVRRKKLRVLKGGVNSRCAEYMR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00210_NODE_17..&amp;from=0&amp;to=2650\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTLSMLLRTLFEILLFAAVVWGFFNEDRLAAFEKRVICAVRRKKLRVLKGGVNSRCAEYMR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACACTATCAATGCTTTTAAGAACTTTATTTGAAATTTTACTTTTTGCCGCCGTTGTTTGGGGATTTTTTAACGAGGACAGGCTTGCGGCGTTTGAAAAGCGCGTTATCTGCGCTGTAAGAAGAAAAAAGCTGCGCGTTTTAAAAGGCGGAGTTAACAGCCGCTGTGCCGAATATATGCGGTAA\">Copy to clipboard</span><br>\n</div>"
     }
    ],
    "clusters": [
     {
      "start": 1065,
      "end": 1332,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 2650,
      "product": "RRE-containing",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "ttaCodons": [],
    "type": "RRE-containing",
    "products": [
     "RRE-containing"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP RRE-containing",
    "anchor": "r210c1"
   }
  ]
 },
 {
  "length": 2638,
  "seq_id": "c00211_NODE_17..",
  "regions": []
 },
 {
  "length": 2632,
  "seq_id": "c00212_NODE_17..",
  "regions": []
 },
 {
  "length": 2624,
  "seq_id": "c00213_NODE_17..",
  "regions": []
 },
 {
  "length": 2620,
  "seq_id": "c00214_NODE_17..",
  "regions": []
 },
 {
  "length": 2607,
  "seq_id": "c00215_NODE_17..",
  "regions": []
 },
 {
  "length": 2607,
  "seq_id": "c00216_NODE_17..",
  "regions": []
 },
 {
  "length": 2605,
  "seq_id": "c00217_NODE_17..",
  "regions": []
 },
 {
  "length": 2592,
  "seq_id": "c00218_NODE_18..",
  "regions": []
 },
 {
  "length": 2583,
  "seq_id": "c00219_NODE_18..",
  "regions": []
 },
 {
  "length": 2577,
  "seq_id": "c00220_NODE_18..",
  "regions": []
 },
 {
  "length": 2575,
  "seq_id": "c00221_NODE_18..",
  "regions": []
 },
 {
  "length": 2574,
  "seq_id": "c00222_NODE_18..",
  "regions": []
 },
 {
  "length": 2571,
  "seq_id": "c00223_NODE_18..",
  "regions": []
 },
 {
  "length": 2564,
  "seq_id": "c00224_NODE_18..",
  "regions": []
 },
 {
  "length": 2554,
  "seq_id": "c00225_NODE_18..",
  "regions": []
 },
 {
  "length": 2552,
  "seq_id": "c00226_NODE_18..",
  "regions": []
 },
 {
  "length": 2548,
  "seq_id": "c00227_NODE_18..",
  "regions": []
 },
 {
  "length": 2517,
  "seq_id": "c00228_NODE_18..",
  "regions": []
 },
 {
  "length": 2511,
  "seq_id": "c00229_NODE_18..",
  "regions": []
 },
 {
  "length": 2505,
  "seq_id": "c00230_NODE_18..",
  "regions": []
 },
 {
  "length": 2502,
  "seq_id": "c00231_NODE_18..",
  "regions": []
 },
 {
  "length": 2502,
  "seq_id": "c00232_NODE_18..",
  "regions": []
 },
 {
  "length": 2492,
  "seq_id": "c00233_NODE_18..",
  "regions": []
 },
 {
  "length": 2480,
  "seq_id": "c00234_NODE_18..",
  "regions": []
 },
 {
  "length": 2470,
  "seq_id": "c00235_NODE_18..",
  "regions": []
 },
 {
  "length": 2468,
  "seq_id": "c00236_NODE_18..",
  "regions": []
 },
 {
  "length": 2467,
  "seq_id": "c00237_NODE_18..",
  "regions": []
 },
 {
  "length": 2467,
  "seq_id": "c00238_NODE_19..",
  "regions": []
 },
 {
  "length": 2461,
  "seq_id": "c00239_NODE_19..",
  "regions": []
 },
 {
  "length": 2460,
  "seq_id": "c00240_NODE_19..",
  "regions": []
 },
 {
  "length": 2460,
  "seq_id": "c00241_NODE_19..",
  "regions": []
 },
 {
  "length": 2457,
  "seq_id": "c00242_NODE_19..",
  "regions": []
 },
 {
  "length": 2450,
  "seq_id": "c00243_NODE_19..",
  "regions": []
 },
 {
  "length": 2450,
  "seq_id": "c00244_NODE_19..",
  "regions": []
 },
 {
  "length": 2443,
  "seq_id": "c00245_NODE_19..",
  "regions": []
 },
 {
  "length": 2430,
  "seq_id": "c00246_NODE_19..",
  "regions": []
 },
 {
  "length": 2417,
  "seq_id": "c00247_NODE_19..",
  "regions": []
 },
 {
  "length": 2413,
  "seq_id": "c00248_NODE_19..",
  "regions": []
 },
 {
  "length": 2412,
  "seq_id": "c00249_NODE_19..",
  "regions": []
 },
 {
  "length": 2400,
  "seq_id": "c00250_NODE_19..",
  "regions": []
 },
 {
  "length": 2397,
  "seq_id": "c00251_NODE_19..",
  "regions": []
 },
 {
  "length": 2387,
  "seq_id": "c00252_NODE_19..",
  "regions": []
 },
 {
  "length": 2379,
  "seq_id": "c00253_NODE_19..",
  "regions": []
 },
 {
  "length": 2377,
  "seq_id": "c00254_NODE_19..",
  "regions": []
 },
 {
  "length": 2376,
  "seq_id": "c00255_NODE_19..",
  "regions": []
 },
 {
  "length": 2370,
  "seq_id": "c00256_NODE_19..",
  "regions": []
 },
 {
  "length": 2361,
  "seq_id": "c00257_NODE_19..",
  "regions": []
 },
 {
  "length": 2354,
  "seq_id": "c00258_NODE_20..",
  "regions": []
 },
 {
  "length": 2354,
  "seq_id": "c00259_NODE_20..",
  "regions": []
 },
 {
  "length": 2349,
  "seq_id": "c00260_NODE_20..",
  "regions": []
 },
 {
  "length": 2336,
  "seq_id": "c00261_NODE_20..",
  "regions": []
 },
 {
  "length": 2322,
  "seq_id": "c00262_NODE_20..",
  "regions": []
 },
 {
  "length": 2318,
  "seq_id": "c00263_NODE_20..",
  "regions": []
 },
 {
  "length": 2316,
  "seq_id": "c00264_NODE_20..",
  "regions": []
 },
 {
  "length": 2307,
  "seq_id": "c00265_NODE_20..",
  "regions": []
 },
 {
  "length": 2305,
  "seq_id": "c00266_NODE_20..",
  "regions": []
 },
 {
  "length": 2297,
  "seq_id": "c00267_NODE_20..",
  "regions": []
 },
 {
  "length": 2292,
  "seq_id": "c00268_NODE_20..",
  "regions": []
 },
 {
  "length": 2291,
  "seq_id": "c00269_NODE_20..",
  "regions": []
 },
 {
  "length": 2263,
  "seq_id": "c00270_NODE_20..",
  "regions": []
 },
 {
  "length": 2263,
  "seq_id": "c00271_NODE_20..",
  "regions": []
 },
 {
  "length": 2260,
  "seq_id": "c00272_NODE_20..",
  "regions": []
 },
 {
  "length": 2258,
  "seq_id": "c00273_NODE_20..",
  "regions": []
 },
 {
  "length": 2255,
  "seq_id": "c00274_NODE_21..",
  "regions": []
 },
 {
  "length": 2252,
  "seq_id": "c00275_NODE_21..",
  "regions": []
 },
 {
  "length": 2251,
  "seq_id": "c00276_NODE_21..",
  "regions": []
 },
 {
  "length": 2241,
  "seq_id": "c00277_NODE_21..",
  "regions": []
 },
 {
  "length": 2239,
  "seq_id": "c00278_NODE_21..",
  "regions": []
 },
 {
  "length": 2222,
  "seq_id": "c00279_NODE_21..",
  "regions": []
 },
 {
  "length": 2190,
  "seq_id": "c00280_NODE_21..",
  "regions": []
 },
 {
  "length": 2189,
  "seq_id": "c00281_NODE_21..",
  "regions": []
 },
 {
  "length": 2187,
  "seq_id": "c00282_NODE_21..",
  "regions": []
 },
 {
  "length": 2186,
  "seq_id": "c00283_NODE_21..",
  "regions": []
 },
 {
  "length": 2178,
  "seq_id": "c00284_NODE_21..",
  "regions": []
 },
 {
  "length": 2174,
  "seq_id": "c00285_NODE_21..",
  "regions": []
 },
 {
  "length": 2170,
  "seq_id": "c00286_NODE_21..",
  "regions": []
 },
 {
  "length": 2156,
  "seq_id": "c00287_NODE_22..",
  "regions": []
 },
 {
  "length": 2155,
  "seq_id": "c00288_NODE_22..",
  "regions": []
 },
 {
  "length": 2153,
  "seq_id": "c00289_NODE_22..",
  "regions": []
 },
 {
  "length": 2150,
  "seq_id": "c00290_NODE_22..",
  "regions": []
 },
 {
  "length": 2145,
  "seq_id": "c00291_NODE_22..",
  "regions": []
 },
 {
  "length": 2145,
  "seq_id": "c00292_NODE_22..",
  "regions": []
 },
 {
  "length": 2139,
  "seq_id": "c00293_NODE_22..",
  "regions": []
 },
 {
  "length": 2136,
  "seq_id": "c00294_NODE_22..",
  "regions": []
 },
 {
  "length": 2135,
  "seq_id": "c00295_NODE_22..",
  "regions": []
 },
 {
  "length": 2135,
  "seq_id": "c00296_NODE_22..",
  "regions": []
 },
 {
  "length": 2134,
  "seq_id": "c00297_NODE_22..",
  "regions": []
 },
 {
  "length": 2119,
  "seq_id": "c00298_NODE_22..",
  "regions": []
 },
 {
  "length": 2116,
  "seq_id": "c00299_NODE_22..",
  "regions": []
 },
 {
  "length": 2113,
  "seq_id": "c00300_NODE_22..",
  "regions": []
 },
 {
  "length": 2108,
  "seq_id": "c00301_NODE_22..",
  "regions": []
 },
 {
  "length": 2095,
  "seq_id": "c00302_NODE_22..",
  "regions": []
 },
 {
  "length": 2086,
  "seq_id": "c00303_NODE_22..",
  "regions": []
 },
 {
  "length": 2072,
  "seq_id": "c00304_NODE_23..",
  "regions": []
 },
 {
  "length": 2072,
  "seq_id": "c00305_NODE_23..",
  "regions": []
 },
 {
  "length": 2053,
  "seq_id": "c00306_NODE_23..",
  "regions": []
 },
 {
  "length": 2053,
  "seq_id": "c00307_NODE_23..",
  "regions": []
 },
 {
  "length": 2051,
  "seq_id": "c00308_NODE_23..",
  "regions": []
 },
 {
  "length": 2044,
  "seq_id": "c00309_NODE_23..",
  "regions": []
 },
 {
  "length": 2042,
  "seq_id": "c00310_NODE_23..",
  "regions": []
 },
 {
  "length": 2040,
  "seq_id": "c00311_NODE_23..",
  "regions": []
 },
 {
  "length": 2036,
  "seq_id": "c00312_NODE_23..",
  "regions": []
 },
 {
  "length": 2018,
  "seq_id": "c00313_NODE_23..",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r75c1",
  "r210c1"
 ],
 "r75c1": {
  "start": 1,
  "end": 4519,
  "idx": 1,
  "orfs": [
   {
    "start": 2,
    "end": 1354,
    "strand": -1,
    "locus_tag": "ctg75_1",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg75_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg75_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2 - 1,354,\n (total: 1353 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: AMP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKLSFSTKGWHNKSFEEFCNIAKELKFGGIELHNINGELFKNKDGAFHGYAAAATVRRLYEMKLELPCIDVISDISEDTAIAETESCIKIAKDLHIPNIRIKSAECDNDTAKKFITAVLPKAEKAGVTLVIETSGAFCDTAALRELLDSFASDNLAALWDMYSTFFKAGEQPEETIKNLGAYVKQVHIKDFDGEGFCLIGEGKLPVGDMMSALRSVNYDGFISLEWDPAWCEGLDDSEIIFSHFVNFISQFGDTSKAESALYYNRARTGKYVWKKNLLIDETFSQVLDRMVEEFPDQYAFKYTTLDYTRTYSEFRDDVDEFCRSLIALGVKAGSHVAVWATNIPQWYIDSCKKIKYMFPRAHAAAYVMMSFRVAYYKVHYPLAFYAVYFTVRADKFDIEQCLGGAERVLGNLEELKAKDKLETKDEEQIVILEMVYEMNLRGIELLPIDIY&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00075_NODE_98..&amp;from=0&amp;to=4519\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKLSFSTKGWHNKSFEEFCNIAKELKFGGIELHNINGELFKNKDGAFHGYAAAATVRRLYEMKLELPCIDVISDISEDTAIAETESCIKIAKDLHIPNIRIKSAECDNDTAKKFITAVLPKAEKAGVTLVIETSGAFCDTAALRELLDSFASDNLAALWDMYSTFFKAGEQPEETIKNLGAYVKQVHIKDFDGEGFCLIGEGKLPVGDMMSALRSVNYDGFISLEWDPAWCEGLDDSEIIFSHFVNFISQFGDTSKAESALYYNRARTGKYVWKKNLLIDETFSQVLDRMVEEFPDQYAFKYTTLDYTRTYSEFRDDVDEFCRSLIALGVKAGSHVAVWATNIPQWYIDSCKKIKYMFPRAHAAAYVMMSFRVAYYKVHYPLAFYAVYFTVRADKFDIEQCLGGAERVLGNLEELKAKDKLETKDEEQIVILEMVYEMNLRGIELLPIDIY\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGTTATCGTTTTCTACAAAGGGCTGGCATAACAAAAGCTTTGAAGAATTTTGCAATATTGCAAAAGAGCTTAAATTCGGCGGCATTGAGCTGCACAACATAAACGGCGAGCTGTTTAAAAATAAGGACGGCGCGTTTCACGGCTACGCCGCCGCGGCGACGGTAAGGCGGCTTTACGAAATGAAACTGGAGTTACCGTGTATAGACGTAATTTCCGATATAAGCGAAGATACTGCTATAGCTGAAACCGAAAGCTGCATTAAAATTGCTAAAGATTTGCACATACCGAATATTCGCATAAAATCCGCCGAGTGTGATAATGATACCGCAAAGAAATTTATAACCGCGGTTCTGCCTAAGGCTGAAAAAGCGGGCGTTACGCTTGTTATTGAGACCTCCGGCGCGTTTTGCGATACCGCCGCGCTCAGAGAGCTGCTTGACAGCTTTGCAAGCGATAATTTAGCCGCCCTTTGGGATATGTATTCAACATTTTTCAAGGCGGGCGAGCAACCCGAAGAAACCATTAAAAATTTGGGCGCGTATGTAAAGCAAGTGCATATAAAGGACTTTGACGGCGAGGGCTTTTGCCTTATAGGCGAGGGCAAGCTGCCGGTCGGGGATATGATGTCCGCCCTGCGCTCTGTTAATTACGACGGCTTTATTTCGCTTGAATGGGACCCCGCGTGGTGCGAGGGGCTTGACGACAGCGAGATAATATTCTCCCACTTTGTAAACTTTATAAGCCAGTTTGGGGATACCTCAAAGGCGGAGTCTGCCCTTTATTACAACCGCGCCCGCACCGGAAAATATGTTTGGAAGAAAAACTTGCTTATTGACGAAACCTTTTCGCAGGTGCTTGACAGAATGGTTGAGGAATTTCCCGACCAATACGCCTTTAAATACACCACGCTTGATTATACGAGGACTTACAGCGAATTCCGCGACGATGTGGACGAATTTTGCCGCTCGCTTATAGCGCTGGGGGTAAAGGCAGGCTCGCACGTGGCGGTTTGGGCCACCAATATTCCGCAGTGGTATATCGACAGCTGCAAAAAAATCAAGTATATGTTCCCGCGCGCTCATGCAGCGGCGTATGTTATGATGTCTTTCCGCGTAGCATACTATAAGGTGCATTACCCGCTTGCGTTCTATGCGGTTTATTTCACGGTTCGTGCGGATAAATTTGATATTGAACAGTGCCTCGGCGGCGCGGAACGCGTACTCGGCAATCTTGAGGAGCTTAAGGCAAAGGATAAACTTGAAACAAAGGACGAGGAACAGATAGTTATCCTTGAAATGGTCTACGAGATGAATCTGCGCGGAATCGAGCTGCTCCCGATAGATATTTAC\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 1360,
    "end": 2736,
    "strand": -1,
    "locus_tag": "ctg75_2",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg75_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg75_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,360 - 2,736,\n (total: 1377 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: HMGL-like<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKNIKICDRTLCAAGAHFSFKEKIEISRQLERLNVTAVELPEIENAKTDTLLVRTVASFVKNSVLSVCGGKTRESIDLAADALRTAAKPRIRIELPLSTVGMEYICHKKAPKMGEFITELVSYAKEKCGDTEFCAMDATRADKAFLYEMIDTAIAAGAGVITVSDDAAEQMPDEFAAFIAEIAAHIGGKAEISVMCSDKNGLASAASVMAVKQGADSVKTAVSGDITALEGFAAMIKNCGDTCGFCSDIKNTELNRIIKQIVRITGGKTDTAAPIAAEQSGITLDGSDGKDAVVSAAAVLGYDLSDEDAQKVYEEFRRVAAKKKVGAKELEVIITSTAMQAPPTYTLVNYVINNGNVISASAQVTLERDGNRTTGISIGDGPIDAAFLALEQIIGSRYELEDFKIETVTEGKESIGSALVKLRFSGKLYSGNGISTDIIGASIRAYINAVNKIVYGEA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00075_NODE_98..&amp;from=0&amp;to=4519\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKNIKICDRTLCAAGAHFSFKEKIEISRQLERLNVTAVELPEIENAKTDTLLVRTVASFVKNSVLSVCGGKTRESIDLAADALRTAAKPRIRIELPLSTVGMEYICHKKAPKMGEFITELVSYAKEKCGDTEFCAMDATRADKAFLYEMIDTAIAAGAGVITVSDDAAEQMPDEFAAFIAEIAAHIGGKAEISVMCSDKNGLASAASVMAVKQGADSVKTAVSGDITALEGFAAMIKNCGDTCGFCSDIKNTELNRIIKQIVRITGGKTDTAAPIAAEQSGITLDGSDGKDAVVSAAAVLGYDLSDEDAQKVYEEFRRVAAKKKVGAKELEVIITSTAMQAPPTYTLVNYVINNGNVISASAQVTLERDGNRTTGISIGDGPIDAAFLALEQIIGSRYELEDFKIETVTEGKESIGSALVKLRFSGKLYSGNGISTDIIGASIRAYINAVNKIVYGEA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAAACATTAAAATCTGCGACAGAACGCTCTGCGCGGCAGGGGCGCATTTCAGCTTTAAGGAAAAAATAGAAATTTCACGTCAGCTTGAAAGGCTTAACGTCACCGCGGTCGAGCTGCCCGAAATTGAAAACGCAAAGACCGATACTTTACTTGTGCGCACGGTGGCGTCGTTTGTTAAAAACAGCGTGTTATCGGTTTGCGGCGGTAAAACGCGCGAGAGCATTGATTTAGCCGCCGACGCGCTGCGCACCGCCGCAAAACCGCGTATTCGCATTGAGCTGCCGCTTTCTACCGTGGGTATGGAATATATATGCCACAAAAAAGCGCCTAAAATGGGCGAGTTTATAACCGAACTTGTAAGCTATGCAAAGGAAAAGTGCGGCGATACCGAGTTTTGCGCTATGGACGCAACGCGTGCTGACAAGGCTTTTCTTTACGAAATGATCGATACCGCAATAGCGGCGGGCGCGGGCGTTATTACCGTAAGCGACGACGCAGCGGAGCAAATGCCCGATGAATTTGCCGCCTTTATTGCCGAAATCGCCGCACATATAGGCGGCAAAGCCGAAATTTCGGTTATGTGCAGCGATAAAAACGGGCTGGCTTCCGCCGCGTCGGTTATGGCGGTAAAGCAGGGGGCTGACAGCGTTAAAACCGCCGTTTCGGGCGATATTACCGCGCTTGAGGGCTTTGCCGCAATGATAAAAAACTGCGGCGATACCTGCGGCTTTTGTTCAGACATTAAAAATACCGAGCTTAACAGAATTATAAAGCAGATTGTAAGAATTACGGGCGGCAAAACAGATACCGCAGCCCCCATAGCAGCCGAGCAGAGCGGAATTACCCTTGACGGCAGCGACGGAAAGGACGCGGTCGTATCTGCCGCGGCGGTGCTTGGGTACGATTTATCGGACGAGGACGCGCAAAAGGTTTACGAGGAGTTTCGCCGCGTAGCGGCTAAAAAGAAAGTAGGCGCCAAGGAGCTTGAGGTTATTATTACAAGCACGGCTATGCAGGCGCCGCCCACATATACGCTTGTGAATTACGTTATAAACAACGGCAATGTAATTTCCGCCTCGGCTCAGGTAACGCTTGAGCGCGACGGTAATCGCACTACGGGCATAAGCATAGGCGACGGACCTATTGACGCGGCGTTTTTGGCGCTTGAGCAGATTATAGGCAGCCGCTATGAGCTTGAGGATTTTAAAATCGAGACCGTAACCGAGGGTAAGGAGTCGATAGGCAGCGCGCTTGTTAAGCTGCGCTTTTCGGGCAAGCTTTATTCGGGCAACGGTATTTCAACCGATATTATAGGTGCGAGCATAAGGGCGTACATAAACGCCGTTAATAAGATAGTTTACGGGGAGGCTTGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 3195,
    "end": 4517,
    "strand": 1,
    "locus_tag": "ctg75_3",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg75_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg75_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,195 - 4,517,\n (total: 1323 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKFYEKLNEYISALNCTAKDIARISGISAATLSRYRSGERAPETGSEVFSKLCSAIAEAAGERGITDITEKSVADAFLSCEDFKTADKNRLCRNFSALAAALDINLAELCRHTNYDASTVFRFKNGTRRPSEPEKFADDAAQYISGIINTKEIAAVLYEATGIKGGSRASLYADIKNWLLNSESPAESGRGVSVFLNKLDEFDLNKYIKAIHFDEVKVPSLPFQLPTSKYYYGISEMMQSELDFLKATVLSKSNGSVTLYSDMPMTEMAKDKEFPKKWMYGMALMLKKGLHLNNIHNIDRSFEEMMLGLESWIPMYMTGQISPYYLKRAPGGTFNHFLRVSGAAALSGEAIAGFHSNGRYYLSKTKEDIAYYQKRADDLLKNASPLMDIYREDSAQRLNAFLLTDSETAGNRRSVLSVPPVYTADNAYLEKLLAAHGISAE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00075_NODE_98..&amp;from=0&amp;to=4519\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKFYEKLNEYISALNCTAKDIARISGISAATLSRYRSGERAPETGSEVFSKLCSAIAEAAGERGITDITEKSVADAFLSCEDFKTADKNRLCRNFSALAAALDINLAELCRHTNYDASTVFRFKNGTRRPSEPEKFADDAAQYISGIINTKEIAAVLYEATGIKGGSRASLYADIKNWLLNSESPAESGRGVSVFLNKLDEFDLNKYIKAIHFDEVKVPSLPFQLPTSKYYYGISEMMQSELDFLKATVLSKSNGSVTLYSDMPMTEMAKDKEFPKKWMYGMALMLKKGLHLNNIHNIDRSFEEMMLGLESWIPMYMTGQISPYYLKRAPGGTFNHFLRVSGAAALSGEAIAGFHSNGRYYLSKTKEDIAYYQKRADDLLKNASPLMDIYREDSAQRLNAFLLTDSETAGNRRSVLSVPPVYTADNAYLEKLLAAHGISAE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAATTTTACGAAAAATTAAACGAATATATAAGCGCCCTAAACTGTACCGCAAAGGATATAGCCCGTATATCGGGAATTTCCGCAGCAACGCTCAGCCGTTACCGTTCGGGCGAAAGGGCCCCCGAAACAGGATCGGAGGTATTTTCAAAGCTTTGCTCCGCTATTGCCGAAGCCGCAGGAGAACGCGGTATAACCGATATAACCGAAAAAAGCGTTGCAGACGCCTTTCTTTCCTGCGAAGACTTTAAAACGGCTGATAAAAACAGGCTTTGCCGCAATTTCAGCGCGCTTGCAGCCGCTCTTGACATTAACCTTGCCGAACTTTGCAGGCATACCAATTACGACGCTTCAACCGTTTTCCGCTTTAAAAACGGCACGCGCAGACCGTCCGAACCCGAAAAATTTGCAGACGACGCCGCACAGTATATTTCCGGCATAATAAATACAAAGGAAATTGCCGCCGTGCTTTACGAGGCAACGGGCATTAAGGGCGGCAGCAGGGCTTCGCTTTACGCCGATATTAAGAATTGGCTGCTCAACAGCGAAAGCCCTGCGGAAAGCGGGCGCGGCGTTTCGGTTTTTTTGAATAAGCTTGATGAATTTGACCTAAACAAATACATAAAGGCAATACATTTTGATGAGGTGAAGGTGCCGTCGCTCCCGTTTCAGCTGCCCACCTCTAAATACTATTACGGGATTTCGGAAATGATGCAAAGCGAGCTTGATTTTCTTAAAGCTACCGTGCTTTCAAAATCAAACGGCAGCGTTACGCTTTACAGCGATATGCCGATGACCGAAATGGCAAAGGATAAGGAATTTCCTAAAAAATGGATGTACGGTATGGCGCTTATGCTTAAAAAGGGTCTGCATCTTAATAATATACATAATATAGACCGCTCCTTTGAGGAAATGATGTTGGGCCTTGAAAGCTGGATTCCGATGTATATGACCGGTCAGATCTCCCCGTATTACCTTAAACGGGCGCCCGGCGGCACATTTAACCATTTTTTGCGTGTTTCGGGCGCGGCGGCGCTTTCCGGCGAGGCAATAGCCGGCTTTCACTCAAACGGAAGATACTACCTTTCAAAAACAAAGGAGGATATAGCCTATTACCAGAAACGGGCGGACGATCTTTTGAAAAACGCGTCCCCCTTAATGGATATTTACCGGGAAGACAGCGCGCAGCGGCTTAACGCGTTTTTACTTACAGACTCTGAAACCGCGGGAAACCGAAGAAGCGTTTTATCCGTGCCGCCTGTTTACACGGCGGATAACGCTTACCTTGAAAAGCTTTTGGCGGCGCACGGTATTTCGGCGGAG\">Copy to clipboard</span><br>\n</div>"
   }
  ],
  "clusters": [
   {
    "start": 1,
    "end": 2736,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 4519,
    "product": "betalactone",
    "category": "other",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "ttaCodons": [],
  "type": "betalactone",
  "products": [
   "betalactone"
  ],
  "product_categories": [
   "other"
  ],
  "cssClass": "other betalactone",
  "anchor": "r75c1"
 },
 "r210c1": {
  "start": 1,
  "end": 2650,
  "idx": 1,
  "orfs": [
   {
    "start": 3,
    "end": 545,
    "strand": -1,
    "locus_tag": "ctg210_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg210_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg210_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 545,\n (total: 543 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRIYENPKSTSENRLNARSWYIPEGSCKQIMLNGEWRFAFFENGDRAGNIEEWETIEVPSCWQLKGYENPNYTNINYPFPCDPPYVPDINPTGVYERSFQIEDGSLETYFVFEGISSEAELYINGKYVGRTQGSRLTAEFDITEFVSSGTNTARVYVRKWCCGSYLEDQDAFRYNGIFRDV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00210_NODE_17..&amp;from=0&amp;to=2650\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRIYENPKSTSENRLNARSWYIPEGSCKQIMLNGEWRFAFFENGDRAGNIEEWETIEVPSCWQLKGYENPNYTNINYPFPCDPPYVPDINPTGVYERSFQIEDGSLETYFVFEGISSEAELYINGKYVGRTQGSRLTAEFDITEFVSSGTNTARVYVRKWCCGSYLEDQDAFRYNGIFRDV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCGAATATACGAAAACCCAAAAAGCACAAGTGAAAACAGGCTTAATGCCAGAAGCTGGTATATACCGGAAGGCAGCTGCAAGCAAATAATGCTTAACGGCGAATGGCGCTTTGCGTTTTTTGAAAACGGCGACCGTGCAGGTAATATAGAGGAATGGGAAACTATCGAGGTTCCGTCCTGCTGGCAGCTAAAGGGCTATGAAAACCCGAATTATACAAATATCAACTATCCGTTCCCGTGCGATCCGCCCTATGTGCCGGATATTAACCCCACGGGCGTTTACGAGCGCAGCTTTCAGATAGAGGACGGCAGCCTTGAGACTTATTTTGTGTTCGAGGGCATATCTTCGGAAGCAGAGCTTTACATAAACGGCAAATATGTCGGCAGAACGCAGGGCAGCCGTTTAACGGCGGAGTTTGATATAACCGAATTTGTAAGTTCGGGCACAAACACCGCGCGCGTGTATGTTCGCAAATGGTGCTGCGGCAGTTACCTTGAGGATCAGGACGCATTCCGTTATAACGGCATTTTCAGGGACGTA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 599,
    "end": 1069,
    "strand": -1,
    "locus_tag": "ctg210_2",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg210_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg210_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 599 - 1,069,\n (total: 471 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTAESNLKNAAEALSESEEISVLTAGISMRPMLREHKDIAVIRRKSGRLKRNDVPLYSRPGSEKFILHRILKVTPNGYVIRGDNLFKKEYDIKDENIVGVLRAFYRGGRYIDCEKSRGYKLYVFLNRASYPARYFWRGLIRPTLGKIKRLIIRKNY&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00210_NODE_17..&amp;from=0&amp;to=2650\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTAESNLKNAAEALSESEEISVLTAGISMRPMLREHKDIAVIRRKSGRLKRNDVPLYSRPGSEKFILHRILKVTPNGYVIRGDNLFKKEYDIKDENIVGVLRAFYRGGRYIDCEKSRGYKLYVFLNRASYPARYFWRGLIRPTLGKIKRLIIRKNY\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACAGCCGAAAGCAATCTTAAAAACGCAGCCGAGGCTTTAAGCGAAAGCGAGGAAATATCGGTTTTAACCGCAGGGATAAGTATGCGCCCTATGCTTCGCGAGCATAAGGATATAGCGGTTATAAGGCGAAAAAGCGGAAGACTTAAAAGAAACGACGTTCCGCTTTATTCAAGACCGGGCAGTGAAAAGTTTATTTTACACCGCATATTAAAGGTTACGCCTAACGGGTACGTTATACGGGGCGATAATCTTTTTAAAAAGGAATACGATATCAAGGACGAAAATATCGTAGGGGTGTTAAGGGCGTTTTACCGCGGCGGAAGGTATATAGACTGCGAAAAAAGCCGCGGCTATAAGCTATATGTGTTTTTAAACAGGGCAAGCTACCCCGCAAGATATTTTTGGCGCGGTCTTATCCGCCCGACGCTCGGAAAAATCAAGAGGCTCATTATAAGAAAAAATTATTGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 1066,
    "end": 1332,
    "strand": -1,
    "locus_tag": "ctg210_3",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg210_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg210_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,066 - 1,332,\n (total: 267 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKLKYNFVMNKVADKTVAVAVGDDLANFGGFIKMNDTGAFIFGLLKKDITKEEIINAVMNEYEGVTKPEAEASVSEFLDQLKQSDVIE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00210_NODE_17..&amp;from=0&amp;to=2650\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKLKYNFVMNKVADKTVAVAVGDDLANFGGFIKMNDTGAFIFGLLKKDITKEEIINAVMNEYEGVTKPEAEASVSEFLDQLKQSDVIE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGCTTAAATACAATTTTGTTATGAATAAGGTAGCGGACAAAACAGTTGCGGTTGCCGTGGGGGACGATCTTGCGAATTTCGGCGGCTTTATTAAAATGAACGATACCGGCGCGTTTATTTTCGGTCTTCTTAAAAAGGATATAACAAAGGAAGAAATTATAAACGCGGTTATGAACGAGTATGAAGGCGTAACAAAGCCCGAAGCCGAAGCGTCCGTTTCTGAATTTTTAGATCAACTGAAGCAGTCGGACGTGATAGAATGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 1322,
    "end": 2044,
    "strand": -1,
    "locus_tag": "ctg210_4",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg210_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg210_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,322 - 2,044,\n (total: 723 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNIMLADRVISVEYRDKRFADFFARWETERTDSELTVITDEEKIAAERVFNIKDDFYPESSAILRSIAEWLPLNNSFLLHSAVFEVNDSGVALAAHSGTGKTTHMLLWQKLLGDKLKIINGDKPIIRFFENEPETPYAYGTPWNGKEHFGNAERTPLRHLCFVERAGVNSCERVTAEEITNRVLSQVYMPYSAQAAANTLTLINRLVSSVKLWKIKCNTDISAAGTAYNAIFKGEEKNEA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00210_NODE_17..&amp;from=0&amp;to=2650\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNIMLADRVISVEYRDKRFADFFARWETERTDSELTVITDEEKIAAERVFNIKDDFYPESSAILRSIAEWLPLNNSFLLHSAVFEVNDSGVALAAHSGTGKTTHMLLWQKLLGDKLKIINGDKPIIRFFENEPETPYAYGTPWNGKEHFGNAERTPLRHLCFVERAGVNSCERVTAEEITNRVLSQVYMPYSAQAAANTLTLINRLVSSVKLWKIKCNTDISAAGTAYNAIFKGEEKNEA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAATATAATGTTGGCAGATCGGGTAATAAGCGTTGAATACCGCGATAAGCGTTTTGCGGATTTTTTTGCGCGCTGGGAAACCGAAAGAACCGATTCCGAGCTTACCGTTATAACCGATGAAGAAAAAATCGCCGCCGAGCGCGTTTTTAACATAAAGGACGATTTTTATCCCGAAAGCTCGGCGATACTTCGCAGTATTGCGGAATGGCTGCCGCTTAATAATTCCTTTTTGCTTCATTCGGCGGTTTTTGAGGTGAACGACAGCGGCGTTGCGCTTGCGGCGCACAGCGGAACGGGAAAAACCACGCATATGCTTTTGTGGCAAAAGCTTTTAGGCGATAAGCTTAAAATTATAAACGGCGATAAGCCGATAATCCGTTTTTTTGAAAACGAGCCCGAAACGCCCTATGCCTACGGCACGCCGTGGAACGGCAAGGAGCATTTCGGAAACGCGGAGCGTACGCCGCTTCGTCATTTATGCTTTGTGGAACGTGCGGGCGTTAATTCGTGCGAGCGGGTAACCGCAGAGGAAATTACAAACCGCGTGCTAAGTCAGGTGTATATGCCGTACTCCGCACAGGCCGCGGCGAACACGCTAACGCTTATAAACCGCCTTGTTTCATCGGTAAAGCTTTGGAAAATAAAATGCAATACCGATATATCCGCGGCAGGAACCGCATATAACGCCATATTTAAAGGAGAAGAAAAAAATGAAGCTTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 2260,
    "end": 2445,
    "strand": 1,
    "locus_tag": "ctg210_5",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg210_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg210_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,260 - 2,445,\n (total: 186 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTLSMLLRTLFEILLFAAVVWGFFNEDRLAAFEKRVICAVRRKKLRVLKGGVNSRCAEYMR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00210_NODE_17..&amp;from=0&amp;to=2650\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTLSMLLRTLFEILLFAAVVWGFFNEDRLAAFEKRVICAVRRKKLRVLKGGVNSRCAEYMR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACACTATCAATGCTTTTAAGAACTTTATTTGAAATTTTACTTTTTGCCGCCGTTGTTTGGGGATTTTTTAACGAGGACAGGCTTGCGGCGTTTGAAAAGCGCGTTATCTGCGCTGTAAGAAGAAAAAAGCTGCGCGTTTTAAAAGGCGGAGTTAACAGCCGCTGTGCCGAATATATGCGGTAA\">Copy to clipboard</span><br>\n</div>"
   }
  ],
  "clusters": [
   {
    "start": 1065,
    "end": 1332,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 2650,
    "product": "RRE-containing",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "ttaCodons": [],
  "type": "RRE-containing",
  "products": [
   "RRE-containing"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP RRE-containing",
  "anchor": "r210c1"
 }
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
