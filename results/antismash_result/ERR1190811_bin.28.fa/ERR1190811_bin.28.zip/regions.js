var recordData = [
 {
  "length": 164594,
  "seq_id": "c00001_NODE_16..",
  "regions": []
 },
 {
  "length": 110266,
  "seq_id": "c00002_NODE_70..",
  "regions": []
 },
 {
  "length": 109491,
  "seq_id": "c00003_NODE_72..",
  "regions": []
 },
 {
  "length": 105936,
  "seq_id": "c00004_NODE_77..",
  "regions": []
 },
 {
  "length": 93949,
  "seq_id": "c00005_NODE_96..",
  "regions": []
 },
 {
  "length": 93894,
  "seq_id": "c00006_NODE_97..",
  "regions": []
 },
 {
  "length": 82160,
  "seq_id": "c00007_NODE_13..",
  "regions": []
 },
 {
  "length": 80345,
  "seq_id": "c00008_NODE_14..",
  "regions": []
 },
 {
  "length": 79481,
  "seq_id": "c00009_NODE_14..",
  "regions": []
 },
 {
  "length": 78348,
  "seq_id": "c00010_NODE_15..",
  "regions": []
 },
 {
  "length": 78348,
  "seq_id": "c00011_NODE_15..",
  "regions": []
 },
 {
  "length": 71835,
  "seq_id": "c00012_NODE_20..",
  "regions": []
 },
 {
  "length": 68591,
  "seq_id": "c00013_NODE_22..",
  "regions": []
 },
 {
  "length": 66855,
  "seq_id": "c00014_NODE_24..",
  "regions": []
 },
 {
  "length": 63970,
  "seq_id": "c00015_NODE_26..",
  "regions": []
 },
 {
  "length": 61575,
  "seq_id": "c00016_NODE_29..",
  "regions": []
 },
 {
  "length": 59761,
  "seq_id": "c00017_NODE_31..",
  "regions": []
 },
 {
  "length": 57931,
  "seq_id": "c00018_NODE_34..",
  "regions": []
 },
 {
  "length": 53410,
  "seq_id": "c00019_NODE_40..",
  "regions": []
 },
 {
  "length": 52757,
  "seq_id": "c00020_NODE_41..",
  "regions": []
 },
 {
  "length": 52529,
  "seq_id": "c00021_NODE_41..",
  "regions": []
 },
 {
  "length": 51181,
  "seq_id": "c00022_NODE_43..",
  "regions": []
 },
 {
  "length": 50859,
  "seq_id": "c00023_NODE_43..",
  "regions": []
 },
 {
  "length": 50641,
  "seq_id": "c00024_NODE_43..",
  "regions": []
 },
 {
  "length": 49886,
  "seq_id": "c00025_NODE_45..",
  "regions": []
 },
 {
  "length": 48775,
  "seq_id": "c00026_NODE_47..",
  "regions": []
 },
 {
  "length": 47369,
  "seq_id": "c00027_NODE_49..",
  "regions": []
 },
 {
  "length": 47004,
  "seq_id": "c00028_NODE_50..",
  "regions": []
 },
 {
  "length": 44890,
  "seq_id": "c00029_NODE_54..",
  "regions": []
 },
 {
  "length": 44186,
  "seq_id": "c00030_NODE_55..",
  "regions": []
 },
 {
  "length": 43821,
  "seq_id": "c00031_NODE_56..",
  "regions": []
 },
 {
  "length": 43164,
  "seq_id": "c00032_NODE_58..",
  "regions": []
 },
 {
  "length": 42608,
  "seq_id": "c00033_NODE_60..",
  "regions": []
 },
 {
  "length": 42401,
  "seq_id": "c00034_NODE_60..",
  "regions": []
 },
 {
  "length": 38282,
  "seq_id": "c00035_NODE_71..",
  "regions": []
 },
 {
  "length": 38193,
  "seq_id": "c00036_NODE_71..",
  "regions": []
 },
 {
  "length": 38121,
  "seq_id": "c00037_NODE_72..",
  "regions": []
 },
 {
  "length": 36374,
  "seq_id": "c00038_NODE_77..",
  "regions": []
 },
 {
  "length": 35608,
  "seq_id": "c00039_NODE_80..",
  "regions": []
 },
 {
  "length": 35500,
  "seq_id": "c00040_NODE_80..",
  "regions": []
 },
 {
  "length": 34969,
  "seq_id": "c00041_NODE_81..",
  "regions": []
 },
 {
  "length": 34692,
  "seq_id": "c00042_NODE_83..",
  "regions": []
 },
 {
  "length": 34196,
  "seq_id": "c00043_NODE_84..",
  "regions": []
 },
 {
  "length": 33800,
  "seq_id": "c00044_NODE_86..",
  "regions": []
 },
 {
  "length": 33738,
  "seq_id": "c00045_NODE_87..",
  "regions": []
 },
 {
  "length": 33124,
  "seq_id": "c00046_NODE_90..",
  "regions": []
 },
 {
  "length": 33059,
  "seq_id": "c00047_NODE_90..",
  "regions": []
 },
 {
  "length": 32832,
  "seq_id": "c00048_NODE_91..",
  "regions": []
 },
 {
  "length": 32775,
  "seq_id": "c00049_NODE_91..",
  "regions": []
 },
 {
  "length": 32372,
  "seq_id": "c00050_NODE_93..",
  "regions": []
 },
 {
  "length": 30923,
  "seq_id": "c00051_NODE_10..",
  "regions": []
 },
 {
  "length": 30211,
  "seq_id": "c00052_NODE_10..",
  "regions": []
 },
 {
  "length": 29303,
  "seq_id": "c00053_NODE_10..",
  "regions": []
 },
 {
  "length": 28669,
  "seq_id": "c00054_NODE_11..",
  "regions": []
 },
 {
  "length": 28535,
  "seq_id": "c00055_NODE_11..",
  "regions": []
 },
 {
  "length": 28111,
  "seq_id": "c00056_NODE_11..",
  "regions": []
 },
 {
  "length": 27796,
  "seq_id": "c00057_NODE_11..",
  "regions": []
 },
 {
  "length": 27631,
  "seq_id": "c00058_NODE_11..",
  "regions": []
 },
 {
  "length": 27604,
  "seq_id": "c00059_NODE_11..",
  "regions": []
 },
 {
  "length": 26061,
  "seq_id": "c00060_NODE_13..",
  "regions": []
 },
 {
  "length": 25352,
  "seq_id": "c00061_NODE_13..",
  "regions": []
 },
 {
  "length": 24391,
  "seq_id": "c00062_NODE_14..",
  "regions": []
 },
 {
  "length": 24240,
  "seq_id": "c00063_NODE_14..",
  "regions": []
 },
 {
  "length": 24154,
  "seq_id": "c00064_NODE_14..",
  "regions": []
 },
 {
  "length": 23803,
  "seq_id": "c00065_NODE_14..",
  "regions": []
 },
 {
  "length": 23308,
  "seq_id": "c00066_NODE_15..",
  "regions": []
 },
 {
  "length": 23254,
  "seq_id": "c00067_NODE_15..",
  "regions": []
 },
 {
  "length": 22315,
  "seq_id": "c00068_NODE_16..",
  "regions": []
 },
 {
  "length": 22309,
  "seq_id": "c00069_NODE_16..",
  "regions": []
 },
 {
  "length": 22051,
  "seq_id": "c00070_NODE_16..",
  "regions": []
 },
 {
  "length": 22010,
  "seq_id": "c00071_NODE_16..",
  "regions": []
 },
 {
  "length": 21806,
  "seq_id": "c00072_NODE_16..",
  "regions": []
 },
 {
  "length": 21752,
  "seq_id": "c00073_NODE_16..",
  "regions": []
 },
 {
  "length": 21712,
  "seq_id": "c00074_NODE_16..",
  "regions": []
 },
 {
  "length": 21412,
  "seq_id": "c00075_NODE_16..",
  "regions": []
 },
 {
  "length": 21330,
  "seq_id": "c00076_NODE_17..",
  "regions": []
 },
 {
  "length": 21130,
  "seq_id": "c00077_NODE_17..",
  "regions": []
 },
 {
  "length": 21049,
  "seq_id": "c00078_NODE_17..",
  "regions": []
 },
 {
  "length": 20857,
  "seq_id": "c00079_NODE_17..",
  "regions": []
 },
 {
  "length": 20022,
  "seq_id": "c00080_NODE_18..",
  "regions": []
 },
 {
  "length": 20001,
  "seq_id": "c00081_NODE_18..",
  "regions": []
 },
 {
  "length": 19901,
  "seq_id": "c00082_NODE_18..",
  "regions": []
 },
 {
  "length": 19558,
  "seq_id": "c00083_NODE_19..",
  "regions": []
 },
 {
  "length": 19406,
  "seq_id": "c00084_NODE_19..",
  "regions": []
 },
 {
  "length": 19348,
  "seq_id": "c00085_NODE_19..",
  "regions": []
 },
 {
  "length": 19338,
  "seq_id": "c00086_NODE_19..",
  "regions": []
 },
 {
  "length": 19247,
  "seq_id": "c00087_NODE_19..",
  "regions": []
 },
 {
  "length": 18682,
  "seq_id": "c00088_NODE_20..",
  "regions": []
 },
 {
  "length": 18585,
  "seq_id": "c00089_NODE_20..",
  "regions": []
 },
 {
  "length": 18541,
  "seq_id": "c00090_NODE_20..",
  "regions": []
 },
 {
  "length": 18500,
  "seq_id": "c00091_NODE_20..",
  "regions": []
 },
 {
  "length": 18425,
  "seq_id": "c00092_NODE_20..",
  "regions": []
 },
 {
  "length": 18211,
  "seq_id": "c00093_NODE_21..",
  "regions": []
 },
 {
  "length": 17940,
  "seq_id": "c00094_NODE_21..",
  "regions": []
 },
 {
  "length": 17623,
  "seq_id": "c00095_NODE_21..",
  "regions": []
 },
 {
  "length": 17396,
  "seq_id": "c00096_NODE_22..",
  "regions": []
 },
 {
  "length": 17058,
  "seq_id": "c00097_NODE_22..",
  "regions": []
 },
 {
  "length": 17055,
  "seq_id": "c00098_NODE_22..",
  "regions": []
 },
 {
  "length": 17051,
  "seq_id": "c00099_NODE_22..",
  "regions": []
 },
 {
  "length": 17040,
  "seq_id": "c00100_NODE_22..",
  "regions": []
 },
 {
  "length": 16969,
  "seq_id": "c00101_NODE_23..",
  "regions": []
 },
 {
  "length": 16781,
  "seq_id": "c00102_NODE_23..",
  "regions": []
 },
 {
  "length": 16590,
  "seq_id": "c00103_NODE_23..",
  "regions": []
 },
 {
  "length": 16382,
  "seq_id": "c00104_NODE_24..",
  "regions": []
 },
 {
  "length": 15741,
  "seq_id": "c00105_NODE_25..",
  "regions": []
 },
 {
  "length": 15385,
  "seq_id": "c00106_NODE_25..",
  "regions": []
 },
 {
  "length": 15365,
  "seq_id": "c00107_NODE_26..",
  "regions": []
 },
 {
  "length": 15334,
  "seq_id": "c00108_NODE_26..",
  "regions": []
 },
 {
  "length": 15277,
  "seq_id": "c00109_NODE_26..",
  "regions": []
 },
 {
  "length": 15229,
  "seq_id": "c00110_NODE_26..",
  "regions": []
 },
 {
  "length": 15141,
  "seq_id": "c00111_NODE_26..",
  "regions": []
 },
 {
  "length": 15138,
  "seq_id": "c00112_NODE_26..",
  "regions": []
 },
 {
  "length": 14657,
  "seq_id": "c00113_NODE_27..",
  "regions": []
 },
 {
  "length": 14509,
  "seq_id": "c00114_NODE_27..",
  "regions": []
 },
 {
  "length": 14411,
  "seq_id": "c00115_NODE_27..",
  "regions": []
 },
 {
  "length": 14124,
  "seq_id": "c00116_NODE_28..",
  "regions": []
 },
 {
  "length": 13929,
  "seq_id": "c00117_NODE_28..",
  "regions": []
 },
 {
  "length": 13848,
  "seq_id": "c00118_NODE_29..",
  "regions": []
 },
 {
  "length": 13704,
  "seq_id": "c00119_NODE_29..",
  "regions": []
 },
 {
  "length": 13134,
  "seq_id": "c00120_NODE_31..",
  "regions": []
 },
 {
  "length": 13115,
  "seq_id": "c00121_NODE_31..",
  "regions": []
 },
 {
  "length": 13050,
  "seq_id": "c00122_NODE_31..",
  "regions": []
 },
 {
  "length": 12970,
  "seq_id": "c00123_NODE_31..",
  "regions": []
 },
 {
  "length": 12858,
  "seq_id": "c00124_NODE_31..",
  "regions": []
 },
 {
  "length": 12576,
  "seq_id": "c00125_NODE_32..",
  "regions": []
 },
 {
  "length": 12316,
  "seq_id": "c00126_NODE_33..",
  "regions": []
 },
 {
  "length": 12195,
  "seq_id": "c00127_NODE_33..",
  "regions": []
 },
 {
  "length": 12009,
  "seq_id": "c00128_NODE_34..",
  "regions": []
 },
 {
  "length": 11944,
  "seq_id": "c00129_NODE_34..",
  "regions": []
 },
 {
  "length": 11893,
  "seq_id": "c00130_NODE_34..",
  "regions": []
 },
 {
  "length": 11871,
  "seq_id": "c00131_NODE_35..",
  "regions": []
 },
 {
  "length": 11615,
  "seq_id": "c00132_NODE_35..",
  "regions": []
 },
 {
  "length": 11603,
  "seq_id": "c00133_NODE_35..",
  "regions": []
 },
 {
  "length": 11431,
  "seq_id": "c00134_NODE_36..",
  "regions": []
 },
 {
  "length": 11347,
  "seq_id": "c00135_NODE_36..",
  "regions": []
 },
 {
  "length": 11246,
  "seq_id": "c00136_NODE_37..",
  "regions": []
 },
 {
  "length": 11170,
  "seq_id": "c00137_NODE_37..",
  "regions": []
 },
 {
  "length": 11160,
  "seq_id": "c00138_NODE_37..",
  "regions": []
 },
 {
  "length": 11127,
  "seq_id": "c00139_NODE_37..",
  "regions": []
 },
 {
  "length": 11061,
  "seq_id": "c00140_NODE_37..",
  "regions": []
 },
 {
  "length": 10898,
  "seq_id": "c00141_NODE_38..",
  "regions": []
 },
 {
  "length": 10772,
  "seq_id": "c00142_NODE_38..",
  "regions": []
 },
 {
  "length": 10696,
  "seq_id": "c00143_NODE_39..",
  "regions": []
 },
 {
  "length": 10580,
  "seq_id": "c00144_NODE_39..",
  "regions": []
 },
 {
  "length": 10371,
  "seq_id": "c00145_NODE_40..",
  "regions": []
 },
 {
  "length": 10362,
  "seq_id": "c00146_NODE_40..",
  "regions": []
 },
 {
  "length": 10227,
  "seq_id": "c00147_NODE_40..",
  "regions": []
 },
 {
  "length": 10105,
  "seq_id": "c00148_NODE_41..",
  "regions": []
 },
 {
  "length": 10072,
  "seq_id": "c00149_NODE_41..",
  "regions": []
 },
 {
  "length": 10049,
  "seq_id": "c00150_NODE_41..",
  "regions": []
 },
 {
  "length": 9998,
  "seq_id": "c00151_NODE_41..",
  "regions": []
 },
 {
  "length": 9728,
  "seq_id": "c00152_NODE_43..",
  "regions": []
 },
 {
  "length": 9660,
  "seq_id": "c00153_NODE_43..",
  "regions": []
 },
 {
  "length": 9524,
  "seq_id": "c00154_NODE_44..",
  "regions": []
 },
 {
  "length": 9490,
  "seq_id": "c00155_NODE_44..",
  "regions": []
 },
 {
  "length": 9445,
  "seq_id": "c00156_NODE_44..",
  "regions": []
 },
 {
  "length": 9441,
  "seq_id": "c00157_NODE_44..",
  "regions": []
 },
 {
  "length": 9293,
  "seq_id": "c00158_NODE_45..",
  "regions": []
 },
 {
  "length": 9240,
  "seq_id": "c00159_NODE_45..",
  "regions": []
 },
 {
  "length": 9179,
  "seq_id": "c00160_NODE_45..",
  "regions": []
 },
 {
  "length": 9141,
  "seq_id": "c00161_NODE_46..",
  "regions": []
 },
 {
  "length": 8940,
  "seq_id": "c00162_NODE_47..",
  "regions": []
 },
 {
  "length": 8661,
  "seq_id": "c00163_NODE_49..",
  "regions": []
 },
 {
  "length": 8573,
  "seq_id": "c00164_NODE_49..",
  "regions": []
 },
 {
  "length": 8453,
  "seq_id": "c00165_NODE_50..",
  "regions": []
 },
 {
  "length": 8375,
  "seq_id": "c00166_NODE_50..",
  "regions": []
 },
 {
  "length": 7982,
  "seq_id": "c00167_NODE_53..",
  "regions": []
 },
 {
  "length": 7666,
  "seq_id": "c00168_NODE_56..",
  "regions": []
 },
 {
  "length": 7639,
  "seq_id": "c00169_NODE_56..",
  "regions": []
 },
 {
  "length": 7500,
  "seq_id": "c00170_NODE_57..",
  "regions": []
 },
 {
  "length": 7354,
  "seq_id": "c00171_NODE_58..",
  "regions": []
 },
 {
  "length": 7341,
  "seq_id": "c00172_NODE_58..",
  "regions": []
 },
 {
  "length": 7266,
  "seq_id": "c00173_NODE_59..",
  "regions": []
 },
 {
  "length": 7135,
  "seq_id": "c00174_NODE_60..",
  "regions": []
 },
 {
  "length": 7108,
  "seq_id": "c00175_NODE_60..",
  "regions": []
 },
 {
  "length": 7084,
  "seq_id": "c00176_NODE_60..",
  "regions": []
 },
 {
  "length": 6905,
  "seq_id": "c00177_NODE_62..",
  "regions": []
 },
 {
  "length": 6848,
  "seq_id": "c00178_NODE_62..",
  "regions": []
 },
 {
  "length": 6806,
  "seq_id": "c00179_NODE_63..",
  "regions": []
 },
 {
  "length": 6780,
  "seq_id": "c00180_NODE_63..",
  "regions": []
 },
 {
  "length": 6755,
  "seq_id": "c00181_NODE_63..",
  "regions": []
 },
 {
  "length": 6705,
  "seq_id": "c00182_NODE_64..",
  "regions": []
 },
 {
  "length": 6689,
  "seq_id": "c00183_NODE_64..",
  "regions": []
 },
 {
  "length": 6666,
  "seq_id": "c00184_NODE_64..",
  "regions": []
 },
 {
  "length": 6592,
  "seq_id": "c00185_NODE_65..",
  "regions": []
 },
 {
  "length": 6483,
  "seq_id": "c00186_NODE_66..",
  "regions": []
 },
 {
  "length": 6389,
  "seq_id": "c00187_NODE_67..",
  "regions": []
 },
 {
  "length": 6331,
  "seq_id": "c00188_NODE_68..",
  "regions": []
 },
 {
  "length": 6277,
  "seq_id": "c00189_NODE_68..",
  "regions": []
 },
 {
  "length": 6165,
  "seq_id": "c00190_NODE_70..",
  "regions": []
 },
 {
  "length": 6043,
  "seq_id": "c00191_NODE_71..",
  "regions": []
 },
 {
  "length": 6037,
  "seq_id": "c00192_NODE_72..",
  "regions": []
 },
 {
  "length": 5846,
  "seq_id": "c00193_NODE_74..",
  "regions": []
 },
 {
  "length": 5816,
  "seq_id": "c00194_NODE_75..",
  "regions": []
 },
 {
  "length": 5688,
  "seq_id": "c00195_NODE_77..",
  "regions": []
 },
 {
  "length": 5616,
  "seq_id": "c00196_NODE_78..",
  "regions": []
 },
 {
  "length": 5431,
  "seq_id": "c00197_NODE_81..",
  "regions": []
 },
 {
  "length": 5383,
  "seq_id": "c00198_NODE_81..",
  "regions": []
 },
 {
  "length": 5365,
  "seq_id": "c00199_NODE_82..",
  "regions": []
 },
 {
  "length": 4956,
  "seq_id": "c00200_NODE_89..",
  "regions": []
 },
 {
  "length": 4844,
  "seq_id": "c00201_NODE_91..",
  "regions": []
 },
 {
  "length": 4737,
  "seq_id": "c00202_NODE_93..",
  "regions": []
 },
 {
  "length": 4382,
  "seq_id": "c00203_NODE_10..",
  "regions": []
 },
 {
  "length": 4331,
  "seq_id": "c00204_NODE_10..",
  "regions": []
 },
 {
  "length": 4319,
  "seq_id": "c00205_NODE_10..",
  "regions": []
 },
 {
  "length": 4173,
  "seq_id": "c00206_NODE_10..",
  "regions": []
 },
 {
  "length": 4094,
  "seq_id": "c00207_NODE_10..",
  "regions": []
 },
 {
  "length": 4053,
  "seq_id": "c00208_NODE_11..",
  "regions": []
 },
 {
  "length": 3913,
  "seq_id": "c00209_NODE_11..",
  "regions": []
 },
 {
  "length": 3898,
  "seq_id": "c00210_NODE_11..",
  "regions": []
 },
 {
  "length": 3849,
  "seq_id": "c00211_NODE_11..",
  "regions": []
 },
 {
  "length": 3730,
  "seq_id": "c00212_NODE_12..",
  "regions": []
 },
 {
  "length": 3701,
  "seq_id": "c00213_NODE_12..",
  "regions": []
 },
 {
  "length": 3658,
  "seq_id": "c00214_NODE_12..",
  "regions": []
 },
 {
  "length": 3657,
  "seq_id": "c00215_NODE_12..",
  "regions": []
 },
 {
  "length": 3635,
  "seq_id": "c00216_NODE_12..",
  "regions": []
 },
 {
  "length": 3599,
  "seq_id": "c00217_NODE_12..",
  "regions": []
 },
 {
  "length": 3489,
  "seq_id": "c00218_NODE_13..",
  "regions": []
 },
 {
  "length": 3452,
  "seq_id": "c00219_NODE_13..",
  "regions": []
 },
 {
  "length": 3366,
  "seq_id": "c00220_NODE_13..",
  "regions": []
 },
 {
  "length": 3144,
  "seq_id": "c00221_NODE_14..",
  "regions": []
 },
 {
  "length": 3096,
  "seq_id": "c00222_NODE_14..",
  "regions": []
 },
 {
  "length": 3057,
  "seq_id": "c00223_NODE_14..",
  "regions": []
 },
 {
  "length": 3052,
  "seq_id": "c00224_NODE_15..",
  "regions": []
 },
 {
  "length": 3005,
  "seq_id": "c00225_NODE_15..",
  "regions": []
 },
 {
  "length": 2885,
  "seq_id": "c00226_NODE_15..",
  "regions": []
 },
 {
  "length": 2655,
  "seq_id": "c00227_NODE_17..",
  "regions": []
 },
 {
  "length": 2650,
  "seq_id": "c00228_NODE_17..",
  "regions": []
 },
 {
  "length": 2558,
  "seq_id": "c00229_NODE_18..",
  "regions": []
 },
 {
  "length": 2548,
  "seq_id": "c00230_NODE_18..",
  "regions": []
 },
 {
  "length": 2355,
  "seq_id": "c00231_NODE_20..",
  "regions": []
 },
 {
  "length": 2343,
  "seq_id": "c00232_NODE_20..",
  "regions": []
 },
 {
  "length": 2306,
  "seq_id": "c00233_NODE_20..",
  "regions": []
 },
 {
  "length": 2034,
  "seq_id": "c00234_NODE_23..",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
