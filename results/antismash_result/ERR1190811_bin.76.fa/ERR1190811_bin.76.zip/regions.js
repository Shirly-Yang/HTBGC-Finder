var recordData = [
 {
  "length": 76273,
  "seq_id": "c00001_NODE_16..",
  "regions": []
 },
 {
  "length": 54472,
  "seq_id": "c00002_NODE_38..",
  "regions": []
 },
 {
  "length": 45296,
  "seq_id": "c00003_NODE_53..",
  "regions": []
 },
 {
  "length": 45110,
  "seq_id": "c00004_NODE_54..",
  "regions": []
 },
 {
  "length": 43205,
  "seq_id": "c00005_NODE_58..",
  "regions": []
 },
 {
  "length": 41721,
  "seq_id": "c00006_NODE_62..",
  "regions": []
 },
 {
  "length": 37867,
  "seq_id": "c00007_NODE_72..",
  "regions": []
 },
 {
  "length": 36890,
  "seq_id": "c00008_NODE_75..",
  "regions": []
 },
 {
  "length": 36867,
  "seq_id": "c00009_NODE_75..",
  "regions": []
 },
 {
  "length": 35228,
  "seq_id": "c00010_NODE_81..",
  "regions": []
 },
 {
  "length": 33023,
  "seq_id": "c00011_NODE_90..",
  "regions": []
 },
 {
  "length": 30362,
  "seq_id": "c00012_NODE_10..",
  "regions": []
 },
 {
  "length": 29455,
  "seq_id": "c00013_NODE_10..",
  "regions": []
 },
 {
  "length": 29030,
  "seq_id": "c00014_NODE_11..",
  "regions": []
 },
 {
  "length": 28896,
  "seq_id": "c00015_NODE_11..",
  "regions": []
 },
 {
  "length": 28553,
  "seq_id": "c00016_NODE_11..",
  "regions": []
 },
 {
  "length": 27540,
  "seq_id": "c00017_NODE_12..",
  "regions": []
 },
 {
  "length": 27480,
  "seq_id": "c00018_NODE_12..",
  "regions": []
 },
 {
  "length": 26491,
  "seq_id": "c00019_NODE_12..",
  "regions": []
 },
 {
  "length": 25484,
  "seq_id": "c00020_NODE_13..",
  "regions": []
 },
 {
  "length": 25138,
  "seq_id": "c00021_NODE_13..",
  "regions": []
 },
 {
  "length": 24984,
  "seq_id": "c00022_NODE_13..",
  "regions": []
 },
 {
  "length": 24899,
  "seq_id": "c00023_NODE_13..",
  "regions": []
 },
 {
  "length": 23920,
  "seq_id": "c00024_NODE_14..",
  "regions": []
 },
 {
  "length": 23328,
  "seq_id": "c00025_NODE_15..",
  "regions": []
 },
 {
  "length": 21682,
  "seq_id": "c00026_NODE_16..",
  "regions": []
 },
 {
  "length": 21003,
  "seq_id": "c00027_NODE_17..",
  "regions": []
 },
 {
  "length": 20559,
  "seq_id": "c00028_NODE_17..",
  "regions": []
 },
 {
  "length": 20297,
  "seq_id": "c00029_NODE_18..",
  "regions": []
 },
 {
  "length": 19536,
  "seq_id": "c00030_NODE_19..",
  "regions": []
 },
 {
  "length": 19288,
  "seq_id": "c00031_NODE_19..",
  "regions": []
 },
 {
  "length": 18297,
  "seq_id": "c00032_NODE_21..",
  "regions": []
 },
 {
  "length": 18040,
  "seq_id": "c00033_NODE_21..",
  "regions": []
 },
 {
  "length": 17503,
  "seq_id": "c00034_NODE_22..",
  "regions": []
 },
 {
  "length": 17425,
  "seq_id": "c00035_NODE_22..",
  "regions": []
 },
 {
  "length": 17222,
  "seq_id": "c00036_NODE_22..",
  "regions": []
 },
 {
  "length": 17219,
  "seq_id": "c00037_NODE_22..",
  "regions": []
 },
 {
  "length": 16552,
  "seq_id": "c00038_NODE_23..",
  "regions": []
 },
 {
  "length": 16535,
  "seq_id": "c00039_NODE_23..",
  "regions": []
 },
 {
  "length": 16243,
  "seq_id": "c00040_NODE_24..",
  "regions": []
 },
 {
  "length": 16034,
  "seq_id": "c00041_NODE_24..",
  "regions": []
 },
 {
  "length": 15911,
  "seq_id": "c00042_NODE_25..",
  "regions": []
 },
 {
  "length": 15833,
  "seq_id": "c00043_NODE_25..",
  "regions": []
 },
 {
  "length": 15479,
  "seq_id": "c00044_NODE_25..",
  "regions": []
 },
 {
  "length": 15348,
  "seq_id": "c00045_NODE_26..",
  "regions": []
 },
 {
  "length": 15233,
  "seq_id": "c00046_NODE_26..",
  "regions": []
 },
 {
  "length": 15078,
  "seq_id": "c00047_NODE_26..",
  "regions": []
 },
 {
  "length": 14921,
  "seq_id": "c00048_NODE_26..",
  "regions": []
 },
 {
  "length": 14870,
  "seq_id": "c00049_NODE_26..",
  "regions": []
 },
 {
  "length": 14784,
  "seq_id": "c00050_NODE_27..",
  "regions": []
 },
 {
  "length": 14569,
  "seq_id": "c00051_NODE_27..",
  "regions": []
 },
 {
  "length": 14565,
  "seq_id": "c00052_NODE_27..",
  "regions": []
 },
 {
  "length": 14518,
  "seq_id": "c00053_NODE_27..",
  "regions": []
 },
 {
  "length": 14514,
  "seq_id": "c00054_NODE_27..",
  "regions": []
 },
 {
  "length": 14410,
  "seq_id": "c00055_NODE_27..",
  "regions": []
 },
 {
  "length": 14341,
  "seq_id": "c00056_NODE_28..",
  "regions": []
 },
 {
  "length": 14334,
  "seq_id": "c00057_NODE_28..",
  "regions": []
 },
 {
  "length": 14218,
  "seq_id": "c00058_NODE_28..",
  "regions": []
 },
 {
  "length": 14133,
  "seq_id": "c00059_NODE_28..",
  "regions": []
 },
 {
  "length": 13802,
  "seq_id": "c00060_NODE_29..",
  "regions": []
 },
 {
  "length": 13756,
  "seq_id": "c00061_NODE_29..",
  "regions": []
 },
 {
  "length": 13661,
  "seq_id": "c00062_NODE_29..",
  "regions": []
 },
 {
  "length": 13586,
  "seq_id": "c00063_NODE_29..",
  "regions": []
 },
 {
  "length": 13414,
  "seq_id": "c00064_NODE_30..",
  "regions": []
 },
 {
  "length": 13152,
  "seq_id": "c00065_NODE_31..",
  "regions": []
 },
 {
  "length": 13007,
  "seq_id": "c00066_NODE_31..",
  "regions": []
 },
 {
  "length": 12612,
  "seq_id": "c00067_NODE_32..",
  "regions": []
 },
 {
  "length": 12350,
  "seq_id": "c00068_NODE_33..",
  "regions": []
 },
 {
  "length": 12171,
  "seq_id": "c00069_NODE_33..",
  "regions": []
 },
 {
  "length": 11469,
  "seq_id": "c00070_NODE_36..",
  "regions": []
 },
 {
  "length": 11184,
  "seq_id": "c00071_NODE_37..",
  "regions": []
 },
 {
  "length": 11164,
  "seq_id": "c00072_NODE_37..",
  "regions": []
 },
 {
  "length": 10941,
  "seq_id": "c00073_NODE_38..",
  "regions": []
 },
 {
  "length": 10726,
  "seq_id": "c00074_NODE_38..",
  "regions": []
 },
 {
  "length": 10602,
  "seq_id": "c00075_NODE_39..",
  "regions": []
 },
 {
  "length": 10329,
  "seq_id": "c00076_NODE_40..",
  "regions": []
 },
 {
  "length": 10071,
  "seq_id": "c00077_NODE_41..",
  "regions": []
 },
 {
  "length": 10070,
  "seq_id": "c00078_NODE_41..",
  "regions": []
 },
 {
  "length": 9938,
  "seq_id": "c00079_NODE_42..",
  "regions": []
 },
 {
  "length": 9787,
  "seq_id": "c00080_NODE_42..",
  "regions": []
 },
 {
  "length": 9727,
  "seq_id": "c00081_NODE_43..",
  "regions": []
 },
 {
  "length": 9579,
  "seq_id": "c00082_NODE_43..",
  "regions": []
 },
 {
  "length": 9487,
  "seq_id": "c00083_NODE_44..",
  "regions": []
 },
 {
  "length": 9324,
  "seq_id": "c00084_NODE_45..",
  "regions": []
 },
 {
  "length": 9180,
  "seq_id": "c00085_NODE_45..",
  "regions": []
 },
 {
  "length": 9142,
  "seq_id": "c00086_NODE_46..",
  "regions": []
 },
 {
  "length": 8976,
  "seq_id": "c00087_NODE_46..",
  "regions": []
 },
 {
  "length": 8878,
  "seq_id": "c00088_NODE_47..",
  "regions": []
 },
 {
  "length": 8861,
  "seq_id": "c00089_NODE_47..",
  "regions": []
 },
 {
  "length": 8817,
  "seq_id": "c00090_NODE_48..",
  "regions": []
 },
 {
  "length": 8629,
  "seq_id": "c00091_NODE_49..",
  "regions": []
 },
 {
  "length": 8620,
  "seq_id": "c00092_NODE_49..",
  "regions": []
 },
 {
  "length": 8615,
  "seq_id": "c00093_NODE_49..",
  "regions": []
 },
 {
  "length": 8539,
  "seq_id": "c00094_NODE_49..",
  "regions": []
 },
 {
  "length": 8159,
  "seq_id": "c00095_NODE_52..",
  "regions": []
 },
 {
  "length": 8137,
  "seq_id": "c00096_NODE_52..",
  "regions": []
 },
 {
  "length": 8088,
  "seq_id": "c00097_NODE_53..",
  "regions": []
 },
 {
  "length": 8033,
  "seq_id": "c00098_NODE_53..",
  "regions": []
 },
 {
  "length": 8021,
  "seq_id": "c00099_NODE_53..",
  "regions": []
 },
 {
  "length": 7962,
  "seq_id": "c00100_NODE_54..",
  "regions": []
 },
 {
  "length": 7898,
  "seq_id": "c00101_NODE_54..",
  "regions": []
 },
 {
  "length": 7865,
  "seq_id": "c00102_NODE_54..",
  "regions": []
 },
 {
  "length": 7581,
  "seq_id": "c00103_NODE_56..",
  "regions": []
 },
 {
  "length": 7574,
  "seq_id": "c00104_NODE_56..",
  "regions": []
 },
 {
  "length": 7487,
  "seq_id": "c00105_NODE_57..",
  "regions": []
 },
 {
  "length": 7302,
  "seq_id": "c00106_NODE_58..",
  "regions": []
 },
 {
  "length": 7166,
  "seq_id": "c00107_NODE_59..",
  "regions": []
 },
 {
  "length": 6820,
  "seq_id": "c00108_NODE_63..",
  "regions": []
 },
 {
  "length": 6494,
  "seq_id": "c00109_NODE_66..",
  "regions": []
 },
 {
  "length": 6471,
  "seq_id": "c00110_NODE_66..",
  "regions": []
 },
 {
  "length": 6453,
  "seq_id": "c00111_NODE_66..",
  "regions": []
 },
 {
  "length": 6449,
  "seq_id": "c00112_NODE_66..",
  "regions": []
 },
 {
  "length": 6422,
  "seq_id": "c00113_NODE_67..",
  "regions": []
 },
 {
  "length": 6270,
  "seq_id": "c00114_NODE_69..",
  "regions": []
 },
 {
  "length": 6025,
  "seq_id": "c00115_NODE_72..",
  "regions": []
 },
 {
  "length": 5998,
  "seq_id": "c00116_NODE_72..",
  "regions": []
 },
 {
  "length": 5840,
  "seq_id": "c00117_NODE_74..",
  "regions": []
 },
 {
  "length": 5791,
  "seq_id": "c00118_NODE_75..",
  "regions": []
 },
 {
  "length": 5747,
  "seq_id": "c00119_NODE_76..",
  "regions": []
 },
 {
  "length": 5574,
  "seq_id": "c00120_NODE_78..",
  "regions": []
 },
 {
  "length": 5499,
  "seq_id": "c00121_NODE_80..",
  "regions": []
 },
 {
  "length": 5394,
  "seq_id": "c00122_NODE_81..",
  "regions": []
 },
 {
  "length": 5306,
  "seq_id": "c00123_NODE_83..",
  "regions": []
 },
 {
  "length": 5263,
  "seq_id": "c00124_NODE_83..",
  "regions": []
 },
 {
  "length": 5236,
  "seq_id": "c00125_NODE_84..",
  "regions": []
 },
 {
  "length": 5099,
  "seq_id": "c00126_NODE_86..",
  "regions": []
 },
 {
  "length": 5090,
  "seq_id": "c00127_NODE_86..",
  "regions": []
 },
 {
  "length": 5005,
  "seq_id": "c00128_NODE_88..",
  "regions": []
 },
 {
  "length": 4995,
  "seq_id": "c00129_NODE_88..",
  "regions": []
 },
 {
  "length": 4970,
  "seq_id": "c00130_NODE_89..",
  "regions": []
 },
 {
  "length": 4967,
  "seq_id": "c00131_NODE_89..",
  "regions": []
 },
 {
  "length": 4928,
  "seq_id": "c00132_NODE_90..",
  "regions": []
 },
 {
  "length": 4911,
  "seq_id": "c00133_NODE_90..",
  "regions": []
 },
 {
  "length": 4852,
  "seq_id": "c00134_NODE_91..",
  "regions": []
 },
 {
  "length": 4851,
  "seq_id": "c00135_NODE_91..",
  "regions": []
 },
 {
  "length": 4753,
  "seq_id": "c00136_NODE_93..",
  "regions": []
 },
 {
  "length": 4669,
  "seq_id": "c00137_NODE_95..",
  "regions": []
 },
 {
  "length": 4539,
  "seq_id": "c00138_NODE_98..",
  "regions": []
 },
 {
  "length": 4499,
  "seq_id": "c00139_NODE_99..",
  "regions": []
 },
 {
  "length": 4426,
  "seq_id": "c00140_NODE_10..",
  "regions": []
 },
 {
  "length": 4377,
  "seq_id": "c00141_NODE_10..",
  "regions": []
 },
 {
  "length": 4276,
  "seq_id": "c00142_NODE_10..",
  "regions": []
 },
 {
  "length": 4246,
  "seq_id": "c00143_NODE_10..",
  "regions": []
 },
 {
  "length": 4197,
  "seq_id": "c00144_NODE_10..",
  "regions": []
 },
 {
  "length": 4046,
  "seq_id": "c00145_NODE_11..",
  "regions": []
 },
 {
  "length": 4025,
  "seq_id": "c00146_NODE_11..",
  "regions": []
 },
 {
  "length": 4011,
  "seq_id": "c00147_NODE_11..",
  "regions": []
 },
 {
  "length": 3997,
  "seq_id": "c00148_NODE_11..",
  "regions": []
 },
 {
  "length": 3968,
  "seq_id": "c00149_NODE_11..",
  "regions": []
 },
 {
  "length": 3925,
  "seq_id": "c00150_NODE_11..",
  "regions": []
 },
 {
  "length": 3905,
  "seq_id": "c00151_NODE_11..",
  "regions": []
 },
 {
  "length": 3904,
  "seq_id": "c00152_NODE_11..",
  "regions": []
 },
 {
  "length": 3856,
  "seq_id": "c00153_NODE_11..",
  "regions": []
 },
 {
  "length": 3812,
  "seq_id": "c00154_NODE_11..",
  "regions": []
 },
 {
  "length": 3785,
  "seq_id": "c00155_NODE_11..",
  "regions": []
 },
 {
  "length": 3757,
  "seq_id": "c00156_NODE_12..",
  "regions": []
 },
 {
  "length": 3489,
  "seq_id": "c00157_NODE_13..",
  "regions": []
 },
 {
  "length": 3416,
  "seq_id": "c00158_NODE_13..",
  "regions": []
 },
 {
  "length": 3402,
  "seq_id": "c00159_NODE_13..",
  "regions": []
 },
 {
  "length": 3340,
  "seq_id": "c00160_NODE_13..",
  "regions": []
 },
 {
  "length": 3285,
  "seq_id": "c00161_NODE_13..",
  "regions": []
 },
 {
  "length": 3240,
  "seq_id": "c00162_NODE_14..",
  "regions": []
 },
 {
  "length": 3228,
  "seq_id": "c00163_NODE_14..",
  "regions": []
 },
 {
  "length": 3118,
  "seq_id": "c00164_NODE_14..",
  "regions": []
 },
 {
  "length": 3059,
  "seq_id": "c00165_NODE_14..",
  "regions": []
 },
 {
  "length": 2947,
  "seq_id": "c00166_NODE_15..",
  "regions": []
 },
 {
  "length": 2913,
  "seq_id": "c00167_NODE_15..",
  "regions": []
 },
 {
  "length": 2742,
  "seq_id": "c00168_NODE_16..",
  "regions": []
 },
 {
  "length": 2652,
  "seq_id": "c00169_NODE_17..",
  "regions": []
 },
 {
  "length": 2611,
  "seq_id": "c00170_NODE_17..",
  "regions": []
 },
 {
  "length": 2607,
  "seq_id": "c00171_NODE_17..",
  "regions": []
 },
 {
  "length": 2570,
  "seq_id": "c00172_NODE_18..",
  "regions": []
 },
 {
  "length": 2461,
  "seq_id": "c00173_NODE_19..",
  "regions": []
 },
 {
  "length": 2305,
  "seq_id": "c00174_NODE_20..",
  "regions": []
 },
 {
  "length": 2272,
  "seq_id": "c00175_NODE_20..",
  "regions": []
 },
 {
  "length": 2082,
  "seq_id": "c00176_NODE_23..",
  "regions": []
 },
 {
  "length": 2023,
  "seq_id": "c00177_NODE_23..",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
