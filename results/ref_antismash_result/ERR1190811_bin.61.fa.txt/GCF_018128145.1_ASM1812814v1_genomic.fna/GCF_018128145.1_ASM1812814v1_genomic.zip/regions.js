var recordData = [
 {
  "length": 1828273,
  "seq_id": "NZ_CP072370.1",
  "regions": []
 },
 {
  "length": 1433515,
  "seq_id": "NZ_CP072369.1",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
