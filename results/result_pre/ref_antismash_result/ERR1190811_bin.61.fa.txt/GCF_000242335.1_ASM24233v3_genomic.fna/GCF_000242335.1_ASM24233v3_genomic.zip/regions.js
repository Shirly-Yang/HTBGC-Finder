var recordData = [
 {
  "length": 1890695,
  "seq_id": "NC_019960.1",
  "regions": []
 },
 {
  "length": 1450390,
  "seq_id": "NC_019968.1",
  "regions": []
 },
 {
  "length": 4946,
  "seq_id": "NC_019961.1",
  "regions": []
 },
 {
  "length": 4175,
  "seq_id": "NC_019969.1",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
