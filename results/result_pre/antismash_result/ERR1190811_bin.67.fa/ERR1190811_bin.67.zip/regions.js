var recordData = [
 {
  "length": 33238,
  "seq_id": "c00001_NODE_89..",
  "regions": []
 },
 {
  "length": 31314,
  "seq_id": "c00002_NODE_99..",
  "regions": []
 },
 {
  "length": 24290,
  "seq_id": "c00003_NODE_14..",
  "regions": []
 },
 {
  "length": 24126,
  "seq_id": "c00004_NODE_14..",
  "regions": []
 },
 {
  "length": 20927,
  "seq_id": "c00005_NODE_17..",
  "regions": []
 },
 {
  "length": 20535,
  "seq_id": "c00006_NODE_18..",
  "regions": []
 },
 {
  "length": 18564,
  "seq_id": "c00007_NODE_20..",
  "regions": []
 },
 {
  "length": 18129,
  "seq_id": "c00008_NODE_21..",
  "regions": []
 },
 {
  "length": 17639,
  "seq_id": "c00009_NODE_21..",
  "regions": []
 },
 {
  "length": 16360,
  "seq_id": "c00010_NODE_24..",
  "regions": []
 },
 {
  "length": 16135,
  "seq_id": "c00011_NODE_24..",
  "regions": []
 },
 {
  "length": 15582,
  "seq_id": "c00012_NODE_25..",
  "regions": []
 },
 {
  "length": 15251,
  "seq_id": "c00013_NODE_26..",
  "regions": []
 },
 {
  "length": 15083,
  "seq_id": "c00014_NODE_26..",
  "regions": []
 },
 {
  "length": 14233,
  "seq_id": "c00015_NODE_28..",
  "regions": []
 },
 {
  "length": 13778,
  "seq_id": "c00016_NODE_29..",
  "regions": []
 },
 {
  "length": 13260,
  "seq_id": "c00017_NODE_30..",
  "regions": []
 },
 {
  "length": 13083,
  "seq_id": "c00018_NODE_31..",
  "regions": []
 },
 {
  "length": 12747,
  "seq_id": "c00019_NODE_32..",
  "regions": []
 },
 {
  "length": 12721,
  "seq_id": "c00020_NODE_32..",
  "regions": []
 },
 {
  "length": 12535,
  "seq_id": "c00021_NODE_32..",
  "regions": []
 },
 {
  "length": 12170,
  "seq_id": "c00022_NODE_33..",
  "regions": []
 },
 {
  "length": 12156,
  "seq_id": "c00023_NODE_34..",
  "regions": []
 },
 {
  "length": 12114,
  "seq_id": "c00024_NODE_34..",
  "regions": []
 },
 {
  "length": 12075,
  "seq_id": "c00025_NODE_34..",
  "regions": []
 },
 {
  "length": 11847,
  "seq_id": "c00026_NODE_35..",
  "regions": []
 },
 {
  "length": 11738,
  "seq_id": "c00027_NODE_35..",
  "regions": []
 },
 {
  "length": 11528,
  "seq_id": "c00028_NODE_36..",
  "regions": []
 },
 {
  "length": 11425,
  "seq_id": "c00029_NODE_36..",
  "regions": []
 },
 {
  "length": 11401,
  "seq_id": "c00030_NODE_36..",
  "regions": []
 },
 {
  "length": 11400,
  "seq_id": "c00031_NODE_36..",
  "regions": []
 },
 {
  "length": 11387,
  "seq_id": "c00032_NODE_36..",
  "regions": []
 },
 {
  "length": 11310,
  "seq_id": "c00033_NODE_36..",
  "regions": []
 },
 {
  "length": 11284,
  "seq_id": "c00034_NODE_36..",
  "regions": []
 },
 {
  "length": 11079,
  "seq_id": "c00035_NODE_37..",
  "regions": []
 },
 {
  "length": 11036,
  "seq_id": "c00036_NODE_37..",
  "regions": []
 },
 {
  "length": 10916,
  "seq_id": "c00037_NODE_38..",
  "regions": []
 },
 {
  "length": 10906,
  "seq_id": "c00038_NODE_38..",
  "regions": []
 },
 {
  "length": 10878,
  "seq_id": "c00039_NODE_38..",
  "regions": []
 },
 {
  "length": 10337,
  "seq_id": "c00040_NODE_40..",
  "regions": []
 },
 {
  "length": 9463,
  "seq_id": "c00041_NODE_44..",
  "regions": []
 },
 {
  "length": 9445,
  "seq_id": "c00042_NODE_44..",
  "regions": []
 },
 {
  "length": 9333,
  "seq_id": "c00043_NODE_45..",
  "regions": []
 },
 {
  "length": 9258,
  "seq_id": "c00044_NODE_45..",
  "regions": []
 },
 {
  "length": 9239,
  "seq_id": "c00045_NODE_45..",
  "regions": []
 },
 {
  "length": 9188,
  "seq_id": "c00046_NODE_45..",
  "regions": []
 },
 {
  "length": 9164,
  "seq_id": "c00047_NODE_46..",
  "regions": []
 },
 {
  "length": 8970,
  "seq_id": "c00048_NODE_46..",
  "regions": []
 },
 {
  "length": 8959,
  "seq_id": "c00049_NODE_46..",
  "regions": []
 },
 {
  "length": 8929,
  "seq_id": "c00050_NODE_47..",
  "regions": []
 },
 {
  "length": 8880,
  "seq_id": "c00051_NODE_47..",
  "regions": []
 },
 {
  "length": 8821,
  "seq_id": "c00052_NODE_47..",
  "regions": []
 },
 {
  "length": 8717,
  "seq_id": "c00053_NODE_48..",
  "regions": []
 },
 {
  "length": 8489,
  "seq_id": "c00054_NODE_50..",
  "regions": []
 },
 {
  "length": 8309,
  "seq_id": "c00055_NODE_51..",
  "regions": []
 },
 {
  "length": 8306,
  "seq_id": "c00056_NODE_51..",
  "regions": []
 },
 {
  "length": 8238,
  "seq_id": "c00057_NODE_52..",
  "regions": []
 },
 {
  "length": 8144,
  "seq_id": "c00058_NODE_52..",
  "regions": []
 },
 {
  "length": 8138,
  "seq_id": "c00059_NODE_52..",
  "regions": []
 },
 {
  "length": 8096,
  "seq_id": "c00060_NODE_52..",
  "regions": []
 },
 {
  "length": 8082,
  "seq_id": "c00061_NODE_53..",
  "regions": []
 },
 {
  "length": 7999,
  "seq_id": "c00062_NODE_53..",
  "regions": []
 },
 {
  "length": 7963,
  "seq_id": "c00063_NODE_54..",
  "regions": []
 },
 {
  "length": 7894,
  "seq_id": "c00064_NODE_54..",
  "regions": []
 },
 {
  "length": 7881,
  "seq_id": "c00065_NODE_54..",
  "regions": []
 },
 {
  "length": 7734,
  "seq_id": "c00066_NODE_55..",
  "regions": []
 },
 {
  "length": 7729,
  "seq_id": "c00067_NODE_55..",
  "regions": []
 },
 {
  "length": 7723,
  "seq_id": "c00068_NODE_55..",
  "regions": []
 },
 {
  "length": 7676,
  "seq_id": "c00069_NODE_56..",
  "regions": []
 },
 {
  "length": 7672,
  "seq_id": "c00070_NODE_56..",
  "regions": []
 },
 {
  "length": 7668,
  "seq_id": "c00071_NODE_56..",
  "regions": []
 },
 {
  "length": 7608,
  "seq_id": "c00072_NODE_56..",
  "regions": []
 },
 {
  "length": 7584,
  "seq_id": "c00073_NODE_56..",
  "regions": []
 },
 {
  "length": 7517,
  "seq_id": "c00074_NODE_57..",
  "regions": []
 },
 {
  "length": 7449,
  "seq_id": "c00075_NODE_57..",
  "regions": []
 },
 {
  "length": 7350,
  "seq_id": "c00076_NODE_58..",
  "regions": []
 },
 {
  "length": 7284,
  "seq_id": "c00077_NODE_59..",
  "regions": []
 },
 {
  "length": 7184,
  "seq_id": "c00078_NODE_59..",
  "regions": []
 },
 {
  "length": 7133,
  "seq_id": "c00079_NODE_60..",
  "regions": []
 },
 {
  "length": 7064,
  "seq_id": "c00080_NODE_60..",
  "regions": []
 },
 {
  "length": 7020,
  "seq_id": "c00081_NODE_61..",
  "regions": []
 },
 {
  "length": 6976,
  "seq_id": "c00082_NODE_61..",
  "regions": []
 },
 {
  "length": 6954,
  "seq_id": "c00083_NODE_61..",
  "regions": []
 },
 {
  "length": 6885,
  "seq_id": "c00084_NODE_62..",
  "regions": []
 },
 {
  "length": 6830,
  "seq_id": "c00085_NODE_63..",
  "regions": []
 },
 {
  "length": 6830,
  "seq_id": "c00086_NODE_63..",
  "regions": []
 },
 {
  "length": 6808,
  "seq_id": "c00087_NODE_63..",
  "regions": []
 },
 {
  "length": 6726,
  "seq_id": "c00088_NODE_63..",
  "regions": []
 },
 {
  "length": 6587,
  "seq_id": "c00089_NODE_65..",
  "regions": []
 },
 {
  "length": 6516,
  "seq_id": "c00090_NODE_66..",
  "regions": []
 },
 {
  "length": 6410,
  "seq_id": "c00091_NODE_67..",
  "regions": []
 },
 {
  "length": 6405,
  "seq_id": "c00092_NODE_67..",
  "regions": []
 },
 {
  "length": 6398,
  "seq_id": "c00093_NODE_67..",
  "regions": []
 },
 {
  "length": 6335,
  "seq_id": "c00094_NODE_68..",
  "regions": []
 },
 {
  "length": 6262,
  "seq_id": "c00095_NODE_69..",
  "regions": []
 },
 {
  "length": 6198,
  "seq_id": "c00096_NODE_69..",
  "regions": []
 },
 {
  "length": 6187,
  "seq_id": "c00097_NODE_70..",
  "regions": []
 },
 {
  "length": 6180,
  "seq_id": "c00098_NODE_70..",
  "regions": []
 },
 {
  "length": 6160,
  "seq_id": "c00099_NODE_70..",
  "regions": []
 },
 {
  "length": 6113,
  "seq_id": "c00100_NODE_71..",
  "regions": []
 },
 {
  "length": 6091,
  "seq_id": "c00101_NODE_71..",
  "regions": []
 },
 {
  "length": 6076,
  "seq_id": "c00102_NODE_71..",
  "regions": []
 },
 {
  "length": 6039,
  "seq_id": "c00103_NODE_72..",
  "regions": []
 },
 {
  "length": 6034,
  "seq_id": "c00104_NODE_72..",
  "regions": []
 },
 {
  "length": 5997,
  "seq_id": "c00105_NODE_72..",
  "regions": []
 },
 {
  "length": 5981,
  "seq_id": "c00106_NODE_72..",
  "regions": []
 },
 {
  "length": 5960,
  "seq_id": "c00107_NODE_73..",
  "regions": []
 },
 {
  "length": 5956,
  "seq_id": "c00108_NODE_73..",
  "regions": []
 },
 {
  "length": 5905,
  "seq_id": "c00109_NODE_74..",
  "regions": []
 },
 {
  "length": 5888,
  "seq_id": "c00110_NODE_74..",
  "regions": []
 },
 {
  "length": 5868,
  "seq_id": "c00111_NODE_74..",
  "regions": []
 },
 {
  "length": 5845,
  "seq_id": "c00112_NODE_74..",
  "regions": []
 },
 {
  "length": 5840,
  "seq_id": "c00113_NODE_74..",
  "regions": []
 },
 {
  "length": 5785,
  "seq_id": "c00114_NODE_75..",
  "regions": []
 },
 {
  "length": 5726,
  "seq_id": "c00115_NODE_76..",
  "regions": []
 },
 {
  "length": 5649,
  "seq_id": "c00116_NODE_77..",
  "regions": []
 },
 {
  "length": 5620,
  "seq_id": "c00117_NODE_78..",
  "regions": []
 },
 {
  "length": 5608,
  "seq_id": "c00118_NODE_78..",
  "regions": []
 },
 {
  "length": 5574,
  "seq_id": "c00119_NODE_78..",
  "regions": []
 },
 {
  "length": 5560,
  "seq_id": "c00120_NODE_79..",
  "regions": []
 },
 {
  "length": 5488,
  "seq_id": "c00121_NODE_80..",
  "regions": []
 },
 {
  "length": 5487,
  "seq_id": "c00122_NODE_80..",
  "regions": []
 },
 {
  "length": 5478,
  "seq_id": "c00123_NODE_80..",
  "regions": []
 },
 {
  "length": 5467,
  "seq_id": "c00124_NODE_80..",
  "regions": []
 },
 {
  "length": 5444,
  "seq_id": "c00125_NODE_80..",
  "regions": []
 },
 {
  "length": 5391,
  "seq_id": "c00126_NODE_81..",
  "regions": []
 },
 {
  "length": 5380,
  "seq_id": "c00127_NODE_81..",
  "regions": []
 },
 {
  "length": 5375,
  "seq_id": "c00128_NODE_81..",
  "regions": []
 },
 {
  "length": 5356,
  "seq_id": "c00129_NODE_82..",
  "regions": []
 },
 {
  "length": 5340,
  "seq_id": "c00130_NODE_82..",
  "regions": []
 },
 {
  "length": 5254,
  "seq_id": "c00131_NODE_83..",
  "regions": []
 },
 {
  "length": 5160,
  "seq_id": "c00132_NODE_85..",
  "regions": []
 },
 {
  "length": 5133,
  "seq_id": "c00133_NODE_86..",
  "regions": []
 },
 {
  "length": 5118,
  "seq_id": "c00134_NODE_86..",
  "regions": []
 },
 {
  "length": 5107,
  "seq_id": "c00135_NODE_86..",
  "regions": []
 },
 {
  "length": 5070,
  "seq_id": "c00136_NODE_87..",
  "regions": []
 },
 {
  "length": 5003,
  "seq_id": "c00137_NODE_88..",
  "regions": []
 },
 {
  "length": 4987,
  "seq_id": "c00138_NODE_89..",
  "regions": []
 },
 {
  "length": 4927,
  "seq_id": "c00139_NODE_90..",
  "regions": []
 },
 {
  "length": 4899,
  "seq_id": "c00140_NODE_90..",
  "regions": []
 },
 {
  "length": 4867,
  "seq_id": "c00141_NODE_91..",
  "regions": []
 },
 {
  "length": 4838,
  "seq_id": "c00142_NODE_91..",
  "regions": []
 },
 {
  "length": 4803,
  "seq_id": "c00143_NODE_92..",
  "regions": []
 },
 {
  "length": 4757,
  "seq_id": "c00144_NODE_93..",
  "regions": []
 },
 {
  "length": 4746,
  "seq_id": "c00145_NODE_93..",
  "regions": []
 },
 {
  "length": 4704,
  "seq_id": "c00146_NODE_94..",
  "regions": []
 },
 {
  "length": 4691,
  "seq_id": "c00147_NODE_94..",
  "regions": []
 },
 {
  "length": 4679,
  "seq_id": "c00148_NODE_95..",
  "regions": []
 },
 {
  "length": 4595,
  "seq_id": "c00149_NODE_96..",
  "regions": []
 },
 {
  "length": 4592,
  "seq_id": "c00150_NODE_96..",
  "regions": []
 },
 {
  "length": 4577,
  "seq_id": "c00151_NODE_97..",
  "regions": []
 },
 {
  "length": 4542,
  "seq_id": "c00152_NODE_98..",
  "regions": []
 },
 {
  "length": 4522,
  "seq_id": "c00153_NODE_98..",
  "regions": []
 },
 {
  "length": 4510,
  "seq_id": "c00154_NODE_98..",
  "regions": []
 },
 {
  "length": 4480,
  "seq_id": "c00155_NODE_99..",
  "regions": []
 },
 {
  "length": 4479,
  "seq_id": "c00156_NODE_99..",
  "regions": []
 },
 {
  "length": 4461,
  "seq_id": "c00157_NODE_99..",
  "regions": []
 },
 {
  "length": 4399,
  "seq_id": "c00158_NODE_10..",
  "regions": []
 },
 {
  "length": 4380,
  "seq_id": "c00159_NODE_10..",
  "regions": []
 },
 {
  "length": 4378,
  "seq_id": "c00160_NODE_10..",
  "regions": []
 },
 {
  "length": 4343,
  "seq_id": "c00161_NODE_10..",
  "regions": []
 },
 {
  "length": 4324,
  "seq_id": "c00162_NODE_10..",
  "regions": []
 },
 {
  "length": 4291,
  "seq_id": "c00163_NODE_10..",
  "regions": []
 },
 {
  "length": 4258,
  "seq_id": "c00164_NODE_10..",
  "regions": []
 },
 {
  "length": 4256,
  "seq_id": "c00165_NODE_10..",
  "regions": []
 },
 {
  "length": 4197,
  "seq_id": "c00166_NODE_10..",
  "regions": []
 },
 {
  "length": 4196,
  "seq_id": "c00167_NODE_10..",
  "regions": []
 },
 {
  "length": 4188,
  "seq_id": "c00168_NODE_10..",
  "regions": []
 },
 {
  "length": 4185,
  "seq_id": "c00169_NODE_10..",
  "regions": []
 },
 {
  "length": 4182,
  "seq_id": "c00170_NODE_10..",
  "regions": []
 },
 {
  "length": 4181,
  "seq_id": "c00171_NODE_10..",
  "regions": []
 },
 {
  "length": 4172,
  "seq_id": "c00172_NODE_10..",
  "regions": []
 },
 {
  "length": 4129,
  "seq_id": "c00173_NODE_10..",
  "regions": []
 },
 {
  "length": 4127,
  "seq_id": "c00174_NODE_10..",
  "regions": []
 },
 {
  "length": 4048,
  "seq_id": "c00175_NODE_11..",
  "regions": []
 },
 {
  "length": 4030,
  "seq_id": "c00176_NODE_11..",
  "regions": []
 },
 {
  "length": 4010,
  "seq_id": "c00177_NODE_11..",
  "regions": []
 },
 {
  "length": 3986,
  "seq_id": "c00178_NODE_11..",
  "regions": []
 },
 {
  "length": 3982,
  "seq_id": "c00179_NODE_11..",
  "regions": []
 },
 {
  "length": 3958,
  "seq_id": "c00180_NODE_11..",
  "regions": []
 },
 {
  "length": 3937,
  "seq_id": "c00181_NODE_11..",
  "regions": []
 },
 {
  "length": 3886,
  "seq_id": "c00182_NODE_11..",
  "regions": []
 },
 {
  "length": 3876,
  "seq_id": "c00183_NODE_11..",
  "regions": []
 },
 {
  "length": 3849,
  "seq_id": "c00184_NODE_11..",
  "regions": []
 },
 {
  "length": 3838,
  "seq_id": "c00185_NODE_11..",
  "regions": []
 },
 {
  "length": 3827,
  "seq_id": "c00186_NODE_11..",
  "regions": []
 },
 {
  "length": 3815,
  "seq_id": "c00187_NODE_11..",
  "regions": []
 },
 {
  "length": 3813,
  "seq_id": "c00188_NODE_11..",
  "regions": []
 },
 {
  "length": 3767,
  "seq_id": "c00189_NODE_11..",
  "regions": []
 },
 {
  "length": 3730,
  "seq_id": "c00190_NODE_12..",
  "regions": []
 },
 {
  "length": 3723,
  "seq_id": "c00191_NODE_12..",
  "regions": []
 },
 {
  "length": 3711,
  "seq_id": "c00192_NODE_12..",
  "regions": []
 },
 {
  "length": 3709,
  "seq_id": "c00193_NODE_12..",
  "regions": []
 },
 {
  "length": 3708,
  "seq_id": "c00194_NODE_12..",
  "regions": []
 },
 {
  "length": 3691,
  "seq_id": "c00195_NODE_12..",
  "regions": []
 },
 {
  "length": 3661,
  "seq_id": "c00196_NODE_12..",
  "regions": []
 },
 {
  "length": 3651,
  "seq_id": "c00197_NODE_12..",
  "regions": []
 },
 {
  "length": 3650,
  "seq_id": "c00198_NODE_12..",
  "regions": []
 },
 {
  "length": 3644,
  "seq_id": "c00199_NODE_12..",
  "regions": []
 },
 {
  "length": 3643,
  "seq_id": "c00200_NODE_12..",
  "regions": []
 },
 {
  "length": 3618,
  "seq_id": "c00201_NODE_12..",
  "regions": []
 },
 {
  "length": 3616,
  "seq_id": "c00202_NODE_12..",
  "regions": []
 },
 {
  "length": 3600,
  "seq_id": "c00203_NODE_12..",
  "regions": []
 },
 {
  "length": 3579,
  "seq_id": "c00204_NODE_12..",
  "regions": []
 },
 {
  "length": 3576,
  "seq_id": "c00205_NODE_12..",
  "regions": []
 },
 {
  "length": 3556,
  "seq_id": "c00206_NODE_12..",
  "regions": []
 },
 {
  "length": 3548,
  "seq_id": "c00207_NODE_12..",
  "regions": []
 },
 {
  "length": 3539,
  "seq_id": "c00208_NODE_12..",
  "regions": []
 },
 {
  "length": 3525,
  "seq_id": "c00209_NODE_12..",
  "regions": []
 },
 {
  "length": 3502,
  "seq_id": "c00210_NODE_12..",
  "regions": []
 },
 {
  "length": 3456,
  "seq_id": "c00211_NODE_13..",
  "regions": []
 },
 {
  "length": 3423,
  "seq_id": "c00212_NODE_13..",
  "regions": []
 },
 {
  "length": 3359,
  "seq_id": "c00213_NODE_13..",
  "regions": []
 },
 {
  "length": 3334,
  "seq_id": "c00214_NODE_13..",
  "regions": []
 },
 {
  "length": 3207,
  "seq_id": "c00215_NODE_14..",
  "regions": []
 },
 {
  "length": 3206,
  "seq_id": "c00216_NODE_14..",
  "regions": []
 },
 {
  "length": 3181,
  "seq_id": "c00217_NODE_14..",
  "regions": []
 },
 {
  "length": 3177,
  "seq_id": "c00218_NODE_14..",
  "regions": []
 },
 {
  "length": 3168,
  "seq_id": "c00219_NODE_14..",
  "regions": []
 },
 {
  "length": 3162,
  "seq_id": "c00220_NODE_14..",
  "regions": []
 },
 {
  "length": 3116,
  "seq_id": "c00221_NODE_14..",
  "regions": []
 },
 {
  "length": 3111,
  "seq_id": "c00222_NODE_14..",
  "regions": []
 },
 {
  "length": 3104,
  "seq_id": "c00223_NODE_14..",
  "regions": []
 },
 {
  "length": 3087,
  "seq_id": "c00224_NODE_14..",
  "regions": []
 },
 {
  "length": 3065,
  "seq_id": "c00225_NODE_14..",
  "regions": []
 },
 {
  "length": 3059,
  "seq_id": "c00226_NODE_14..",
  "regions": []
 },
 {
  "length": 3036,
  "seq_id": "c00227_NODE_15..",
  "regions": []
 },
 {
  "length": 3031,
  "seq_id": "c00228_NODE_15..",
  "regions": []
 },
 {
  "length": 3026,
  "seq_id": "c00229_NODE_15..",
  "regions": []
 },
 {
  "length": 3010,
  "seq_id": "c00230_NODE_15..",
  "regions": []
 },
 {
  "length": 2997,
  "seq_id": "c00231_NODE_15..",
  "regions": []
 },
 {
  "length": 2985,
  "seq_id": "c00232_NODE_15..",
  "regions": []
 },
 {
  "length": 2949,
  "seq_id": "c00233_NODE_15..",
  "regions": []
 },
 {
  "length": 2942,
  "seq_id": "c00234_NODE_15..",
  "regions": []
 },
 {
  "length": 2928,
  "seq_id": "c00235_NODE_15..",
  "regions": []
 },
 {
  "length": 2897,
  "seq_id": "c00236_NODE_15..",
  "regions": []
 },
 {
  "length": 2853,
  "seq_id": "c00237_NODE_16..",
  "regions": []
 },
 {
  "length": 2809,
  "seq_id": "c00238_NODE_16..",
  "regions": []
 },
 {
  "length": 2795,
  "seq_id": "c00239_NODE_16..",
  "regions": []
 },
 {
  "length": 2776,
  "seq_id": "c00240_NODE_16..",
  "regions": []
 },
 {
  "length": 2765,
  "seq_id": "c00241_NODE_16..",
  "regions": []
 },
 {
  "length": 2724,
  "seq_id": "c00242_NODE_17..",
  "regions": []
 },
 {
  "length": 2707,
  "seq_id": "c00243_NODE_17..",
  "regions": []
 },
 {
  "length": 2693,
  "seq_id": "c00244_NODE_17..",
  "regions": []
 },
 {
  "length": 2690,
  "seq_id": "c00245_NODE_17..",
  "regions": []
 },
 {
  "length": 2680,
  "seq_id": "c00246_NODE_17..",
  "regions": []
 },
 {
  "length": 2667,
  "seq_id": "c00247_NODE_17..",
  "regions": []
 },
 {
  "length": 2629,
  "seq_id": "c00248_NODE_17..",
  "regions": []
 },
 {
  "length": 2592,
  "seq_id": "c00249_NODE_18..",
  "regions": []
 },
 {
  "length": 2584,
  "seq_id": "c00250_NODE_18..",
  "regions": []
 },
 {
  "length": 2552,
  "seq_id": "c00251_NODE_18..",
  "regions": []
 },
 {
  "length": 2536,
  "seq_id": "c00252_NODE_18..",
  "regions": []
 },
 {
  "length": 2515,
  "seq_id": "c00253_NODE_18..",
  "regions": []
 },
 {
  "length": 2503,
  "seq_id": "c00254_NODE_18..",
  "regions": []
 },
 {
  "length": 2503,
  "seq_id": "c00255_NODE_18..",
  "regions": []
 },
 {
  "length": 2499,
  "seq_id": "c00256_NODE_18..",
  "regions": []
 },
 {
  "length": 2483,
  "seq_id": "c00257_NODE_18..",
  "regions": []
 },
 {
  "length": 2457,
  "seq_id": "c00258_NODE_19..",
  "regions": []
 },
 {
  "length": 2447,
  "seq_id": "c00259_NODE_19..",
  "regions": []
 },
 {
  "length": 2424,
  "seq_id": "c00260_NODE_19..",
  "regions": []
 },
 {
  "length": 2405,
  "seq_id": "c00261_NODE_19..",
  "regions": []
 },
 {
  "length": 2401,
  "seq_id": "c00262_NODE_19..",
  "regions": []
 },
 {
  "length": 2401,
  "seq_id": "c00263_NODE_19..",
  "regions": []
 },
 {
  "length": 2387,
  "seq_id": "c00264_NODE_19..",
  "regions": []
 },
 {
  "length": 2372,
  "seq_id": "c00265_NODE_19..",
  "regions": []
 },
 {
  "length": 2354,
  "seq_id": "c00266_NODE_20..",
  "regions": []
 },
 {
  "length": 2349,
  "seq_id": "c00267_NODE_20..",
  "regions": []
 },
 {
  "length": 2328,
  "seq_id": "c00268_NODE_20..",
  "regions": []
 },
 {
  "length": 2313,
  "seq_id": "c00269_NODE_20..",
  "regions": []
 },
 {
  "length": 2262,
  "seq_id": "c00270_NODE_20..",
  "regions": []
 },
 {
  "length": 2260,
  "seq_id": "c00271_NODE_20..",
  "regions": []
 },
 {
  "length": 2252,
  "seq_id": "c00272_NODE_21..",
  "regions": []
 },
 {
  "length": 2230,
  "seq_id": "c00273_NODE_21..",
  "regions": []
 },
 {
  "length": 2214,
  "seq_id": "c00274_NODE_21..",
  "regions": []
 },
 {
  "length": 2207,
  "seq_id": "c00275_NODE_21..",
  "regions": []
 },
 {
  "length": 2206,
  "seq_id": "c00276_NODE_21..",
  "regions": []
 },
 {
  "length": 2153,
  "seq_id": "c00277_NODE_22..",
  "regions": []
 },
 {
  "length": 2140,
  "seq_id": "c00278_NODE_22..",
  "regions": []
 },
 {
  "length": 2121,
  "seq_id": "c00279_NODE_22..",
  "regions": []
 },
 {
  "length": 2049,
  "seq_id": "c00280_NODE_23..",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
