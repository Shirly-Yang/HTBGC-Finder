var recordData = [
 {
  "length": 37278,
  "seq_id": "c00001_NODE_74..",
  "regions": []
 },
 {
  "length": 36319,
  "seq_id": "c00002_NODE_77..",
  "regions": []
 },
 {
  "length": 34377,
  "seq_id": "c00003_NODE_84..",
  "regions": []
 },
 {
  "length": 33328,
  "seq_id": "c00004_NODE_89..",
  "regions": []
 },
 {
  "length": 31719,
  "seq_id": "c00005_NODE_96..",
  "regions": []
 },
 {
  "length": 26490,
  "seq_id": "c00006_NODE_12..",
  "regions": []
 },
 {
  "length": 25071,
  "seq_id": "c00007_NODE_13..",
  "regions": []
 },
 {
  "length": 24911,
  "seq_id": "c00008_NODE_13..",
  "regions": []
 },
 {
  "length": 23295,
  "seq_id": "c00009_NODE_15..",
  "regions": []
 },
 {
  "length": 22502,
  "seq_id": "c00010_NODE_15..",
  "regions": []
 },
 {
  "length": 21667,
  "seq_id": "c00011_NODE_16..",
  "regions": []
 },
 {
  "length": 20739,
  "seq_id": "c00012_NODE_17..",
  "regions": []
 },
 {
  "length": 19936,
  "seq_id": "c00013_NODE_18..",
  "regions": []
 },
 {
  "length": 19918,
  "seq_id": "c00014_NODE_18..",
  "regions": []
 },
 {
  "length": 19566,
  "seq_id": "c00015_NODE_19..",
  "regions": []
 },
 {
  "length": 19169,
  "seq_id": "c00016_NODE_19..",
  "regions": []
 },
 {
  "length": 18812,
  "seq_id": "c00017_NODE_20..",
  "regions": []
 },
 {
  "length": 18661,
  "seq_id": "c00018_NODE_20..",
  "regions": []
 },
 {
  "length": 18603,
  "seq_id": "c00019_NODE_20..",
  "regions": []
 },
 {
  "length": 17941,
  "seq_id": "c00020_NODE_21..",
  "regions": []
 },
 {
  "length": 17126,
  "seq_id": "c00021_NODE_22..",
  "regions": []
 },
 {
  "length": 16712,
  "seq_id": "c00022_NODE_23..",
  "regions": []
 },
 {
  "length": 16357,
  "seq_id": "c00023_NODE_24..",
  "regions": []
 },
 {
  "length": 16177,
  "seq_id": "c00024_NODE_24..",
  "regions": []
 },
 {
  "length": 16154,
  "seq_id": "c00025_NODE_24..",
  "regions": []
 },
 {
  "length": 15702,
  "seq_id": "c00026_NODE_25..",
  "regions": []
 },
 {
  "length": 15577,
  "seq_id": "c00027_NODE_25..",
  "regions": []
 },
 {
  "length": 15105,
  "seq_id": "c00028_NODE_26..",
  "regions": []
 },
 {
  "length": 14888,
  "seq_id": "c00029_NODE_26..",
  "regions": []
 },
 {
  "length": 14828,
  "seq_id": "c00030_NODE_27..",
  "regions": []
 },
 {
  "length": 14800,
  "seq_id": "c00031_NODE_27..",
  "regions": []
 },
 {
  "length": 14476,
  "seq_id": "c00032_NODE_27..",
  "regions": []
 },
 {
  "length": 14441,
  "seq_id": "c00033_NODE_27..",
  "regions": []
 },
 {
  "length": 14204,
  "seq_id": "c00034_NODE_28..",
  "regions": []
 },
 {
  "length": 14174,
  "seq_id": "c00035_NODE_28..",
  "regions": []
 },
 {
  "length": 14091,
  "seq_id": "c00036_NODE_28..",
  "regions": []
 },
 {
  "length": 13524,
  "seq_id": "c00037_NODE_30..",
  "regions": []
 },
 {
  "length": 13451,
  "seq_id": "c00038_NODE_30..",
  "regions": []
 },
 {
  "length": 13265,
  "seq_id": "c00039_NODE_30..",
  "regions": []
 },
 {
  "length": 12989,
  "seq_id": "c00040_NODE_31..",
  "regions": []
 },
 {
  "length": 12973,
  "seq_id": "c00041_NODE_31..",
  "regions": []
 },
 {
  "length": 12633,
  "seq_id": "c00042_NODE_32..",
  "regions": []
 },
 {
  "length": 12360,
  "seq_id": "c00043_NODE_33..",
  "regions": []
 },
 {
  "length": 12350,
  "seq_id": "c00044_NODE_33..",
  "regions": []
 },
 {
  "length": 12205,
  "seq_id": "c00045_NODE_33..",
  "regions": []
 },
 {
  "length": 12175,
  "seq_id": "c00046_NODE_33..",
  "regions": []
 },
 {
  "length": 12164,
  "seq_id": "c00047_NODE_34..",
  "regions": []
 },
 {
  "length": 12042,
  "seq_id": "c00048_NODE_34..",
  "regions": []
 },
 {
  "length": 12011,
  "seq_id": "c00049_NODE_34..",
  "regions": []
 },
 {
  "length": 11975,
  "seq_id": "c00050_NODE_34..",
  "regions": []
 },
 {
  "length": 11965,
  "seq_id": "c00051_NODE_34..",
  "regions": []
 },
 {
  "length": 11504,
  "seq_id": "c00052_NODE_36..",
  "regions": []
 },
 {
  "length": 11439,
  "seq_id": "c00053_NODE_36..",
  "regions": []
 },
 {
  "length": 11421,
  "seq_id": "c00054_NODE_36..",
  "regions": []
 },
 {
  "length": 11188,
  "seq_id": "c00055_NODE_37..",
  "regions": []
 },
 {
  "length": 11092,
  "seq_id": "c00056_NODE_37..",
  "regions": []
 },
 {
  "length": 11053,
  "seq_id": "c00057_NODE_37..",
  "regions": []
 },
 {
  "length": 10789,
  "seq_id": "c00058_NODE_38..",
  "regions": []
 },
 {
  "length": 10749,
  "seq_id": "c00059_NODE_38..",
  "regions": []
 },
 {
  "length": 10626,
  "seq_id": "c00060_NODE_39..",
  "regions": []
 },
 {
  "length": 10553,
  "seq_id": "c00061_NODE_39..",
  "regions": []
 },
 {
  "length": 10402,
  "seq_id": "c00062_NODE_40..",
  "regions": []
 },
 {
  "length": 10391,
  "seq_id": "c00063_NODE_40..",
  "regions": []
 },
 {
  "length": 10106,
  "seq_id": "c00064_NODE_41..",
  "regions": []
 },
 {
  "length": 10002,
  "seq_id": "c00065_NODE_41..",
  "regions": []
 },
 {
  "length": 9917,
  "seq_id": "c00066_NODE_42..",
  "regions": []
 },
 {
  "length": 9775,
  "seq_id": "c00067_NODE_42..",
  "regions": []
 },
 {
  "length": 9687,
  "seq_id": "c00068_NODE_43..",
  "regions": []
 },
 {
  "length": 9672,
  "seq_id": "c00069_NODE_43..",
  "regions": []
 },
 {
  "length": 9640,
  "seq_id": "c00070_NODE_43..",
  "regions": []
 },
 {
  "length": 9412,
  "seq_id": "c00071_NODE_44..",
  "regions": []
 },
 {
  "length": 9290,
  "seq_id": "c00072_NODE_45..",
  "regions": []
 },
 {
  "length": 9196,
  "seq_id": "c00073_NODE_45..",
  "regions": []
 },
 {
  "length": 9107,
  "seq_id": "c00074_NODE_46..",
  "regions": []
 },
 {
  "length": 9011,
  "seq_id": "c00075_NODE_46..",
  "regions": []
 },
 {
  "length": 8949,
  "seq_id": "c00076_NODE_47..",
  "regions": []
 },
 {
  "length": 8935,
  "seq_id": "c00077_NODE_47..",
  "regions": []
 },
 {
  "length": 8908,
  "seq_id": "c00078_NODE_47..",
  "regions": []
 },
 {
  "length": 8892,
  "seq_id": "c00079_NODE_47..",
  "regions": []
 },
 {
  "length": 8845,
  "seq_id": "c00080_NODE_47..",
  "regions": []
 },
 {
  "length": 8706,
  "seq_id": "c00081_NODE_48..",
  "regions": []
 },
 {
  "length": 8652,
  "seq_id": "c00082_NODE_49..",
  "regions": []
 },
 {
  "length": 8601,
  "seq_id": "c00083_NODE_49..",
  "regions": []
 },
 {
  "length": 8592,
  "seq_id": "c00084_NODE_49..",
  "regions": []
 },
 {
  "length": 8534,
  "seq_id": "c00085_NODE_49..",
  "regions": []
 },
 {
  "length": 8454,
  "seq_id": "c00086_NODE_50..",
  "regions": []
 },
 {
  "length": 8393,
  "seq_id": "c00087_NODE_50..",
  "regions": [
   {
    "start": 1,
    "end": 8393,
    "idx": 1,
    "orfs": [
     {
      "start": 3,
      "end": 866,
      "strand": 1,
      "locus_tag": "ctg87_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 866,\n (total: 864 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MINTSPLMQSEKSSLLLAAVPIMTFVCLIMVYPLNIDKRIFTSVCIIAITLNVVTFSVNEFMLAKNRRIRILEKENYQNRVELEEYKTIGEKYEHSRIMNHDFREHLNVLKTLISEDIQKAQEYVGKIEKECEDSKIEKYSDNNILNILLIRKKKECEENGIKLNITSTNPKLDFIDGMDTVAIFSNLINNAIEACSSSARKDIFIDLYTVNNAFSVIKVENYADKEPIVVEGMLRSGKDDGNSHGIGIKSINNSLSKYDGKMSWSYDKAKGMFRTVISINNSQINI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MINTSPLMQSEKSSLLLAAVPIMTFVCLIMVYPLNIDKRIFTSVCIIAITLNVVTFSVNEFMLAKNRRIRILEKENYQNRVELEEYKTIGEKYEHSRIMNHDFREHLNVLKTLISEDIQKAQEYVGKIEKECEDSKIEKYSDNNILNILLIRKKKECEENGIKLNITSTNPKLDFIDGMDTVAIFSNLINNAIEACSSSARKDIFIDLYTVNNAFSVIKVENYADKEPIVVEGMLRSGKDDGNSHGIGIKSINNSLSKYDGKMSWSYDKAKGMFRTVISINNSQINI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATCAATACTTCTCCTTTGATGCAATCAGAAAAATCTTCTCTGTTGTTAGCTGCAGTTCCTATAATGACTTTTGTGTGTTTAATTATGGTTTATCCGCTGAATATTGACAAGCGTATATTTACTTCGGTTTGTATTATCGCAATAACCTTAAATGTTGTTACTTTTTCGGTAAACGAATTTATGCTTGCGAAAAACAGAAGGATAAGAATACTCGAGAAAGAAAATTATCAAAATCGTGTTGAATTAGAGGAATATAAAACCATAGGTGAAAAGTATGAACATAGCAGAATAATGAATCATGATTTCAGAGAACATCTAAATGTTTTGAAAACTTTAATTTCGGAAGATATCCAAAAAGCTCAAGAATATGTGGGAAAGATTGAAAAAGAGTGTGAGGATTCAAAAATAGAAAAATACAGTGACAATAATATTCTTAATATATTACTTATTCGCAAGAAAAAAGAATGTGAAGAAAACGGGATTAAGCTAAACATAACTTCAACCAATCCGAAACTTGATTTTATCGACGGAATGGACACTGTTGCTATATTTTCTAATTTGATTAACAATGCAATAGAGGCTTGCTCAAGCTCGGCAAGAAAAGATATATTTATTGATTTATACACAGTTAATAACGCATTTAGTGTTATTAAAGTTGAAAATTATGCCGATAAAGAGCCGATAGTTGTAGAAGGTATGCTTAGAAGCGGAAAAGATGACGGTAATTCTCACGGAATCGGTATTAAGAGTATAAATAATTCATTAAGCAAATATGATGGGAAAATGAGTTGGTCGTATGACAAAGCTAAAGGGATGTTTAGAACCGTTATTTCTATAAATAATTCACAAATTAACATTTGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 954,
      "end": 1109,
      "strand": 1,
      "locus_tag": "ctg87_2",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 954 - 1,109,\n (total: 156 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) cyclic-lactone-autoinducer: TIGR04223<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKKFLNKVVPTLIKFVPVCAALMLVINSNSTSTIVNGQPEAPKGLKKYRKF&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKKFLNKVVPTLIKFVPVCAALMLVINSNSTSTIVNGQPEAPKGLKKYRKF\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAAAGTTCCTAAACAAAGTAGTTCCAACATTAATCAAGTTTGTACCTGTTTGTGCAGCGTTGATGCTTGTGATTAACAGTAATTCAACATCAACCATTGTAAACGGTCAACCTGAAGCACCAAAAGGACTTAAGAAGTATCGTAAGTTCTGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 1112,
      "end": 1708,
      "strand": 1,
      "locus_tag": "ctg87_3",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,112 - 1,708,\n (total: 597 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) cyclic-lactone-autoinducer: AgrB<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MFRKFSEWAVAYAIRLGYIKEEEQEEYTYGLDLVMSVIASDLTMLIIGIIMKMIPQVIVFVFMYKFIRKYTGGFHCETALTCYLSSSTMCICVLLAIKYLPYNLGVYIVATVLSIGVLFAISPIEAINKPLEEIEVKVFGKRARIVLCITLVIFGVICAFGLTEMVKTMAISVVDILLFAVMGKIKLLNYKRKKIEQN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MFRKFSEWAVAYAIRLGYIKEEEQEEYTYGLDLVMSVIASDLTMLIIGIIMKMIPQVIVFVFMYKFIRKYTGGFHCETALTCYLSSSTMCICVLLAIKYLPYNLGVYIVATVLSIGVLFAISPIEAINKPLEEIEVKVFGKRARIVLCITLVIFGVICAFGLTEMVKTMAISVVDILLFAVMGKIKLLNYKRKKIEQN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTTTCGTAAATTTTCGGAATGGGCTGTGGCATATGCCATAAGATTAGGTTACATAAAAGAAGAGGAGCAGGAAGAATATACTTACGGACTTGACCTTGTAATGAGCGTTATTGCAAGTGATTTGACAATGCTTATAATAGGTATAATAATGAAAATGATACCGCAGGTGATTGTTTTTGTATTTATGTACAAGTTCATTCGCAAGTATACGGGCGGATTTCATTGCGAAACAGCCTTGACGTGCTATCTGTCGTCAAGCACGATGTGTATATGCGTTTTGCTTGCTATTAAATATCTTCCGTATAACCTTGGCGTATACATAGTCGCAACCGTTTTATCTATTGGGGTACTCTTTGCAATTTCGCCAATCGAGGCTATAAACAAACCTTTGGAAGAAATTGAAGTTAAAGTTTTCGGAAAAAGGGCGAGAATTGTACTTTGTATTACACTTGTAATATTTGGTGTAATTTGTGCGTTTGGTTTGACGGAAATGGTAAAAACAATGGCAATAAGCGTCGTTGATATTTTGCTTTTTGCGGTTATGGGTAAGATAAAATTGTTGAACTACAAAAGGAAAAAAATTGAACAGAATTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 2022,
      "end": 2576,
      "strand": 1,
      "locus_tag": "ctg87_4",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,022 - 2,576,\n (total: 555 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSYIRNVELSDAEVLVEIYRPYVENTTISFECETPSVDEFRSRIENISKKYPYIVMVEDDEIVGYAYAGRFKGRKAYDWCVETTIYVREDKKGGGYGKKLYLELEKRLKKQNILNMYACIAYTDNEDEHLTNNSMQFHGHMGFRLIGTFKKCGYKFDKWYDMIWMEKFIGEHKVNPDAVTRPEI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSYIRNVELSDAEVLVEIYRPYVENTTISFECETPSVDEFRSRIENISKKYPYIVMVEDDEIVGYAYAGRFKGRKAYDWCVETTIYVREDKKGGGYGKKLYLELEKRLKKQNILNMYACIAYTDNEDEHLTNNSMQFHGHMGFRLIGTFKKCGYKFDKWYDMIWMEKFIGEHKVNPDAVTRPEI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGTTATATAAGAAATGTTGAATTATCCGACGCGGAAGTGTTGGTTGAAATATACCGTCCGTATGTCGAAAACACAACAATATCATTTGAATGTGAAACGCCGTCTGTAGACGAGTTTAGAAGTCGTATTGAAAATATTTCAAAAAAGTATCCTTACATTGTTATGGTGGAAGACGATGAAATTGTCGGTTATGCATATGCGGGAAGATTTAAAGGACGTAAAGCGTATGATTGGTGCGTTGAAACGACTATATATGTAAGAGAGGACAAAAAAGGCGGCGGATACGGTAAAAAGTTGTATCTTGAACTTGAAAAAAGATTGAAGAAACAAAACATTCTTAATATGTATGCTTGTATTGCGTATACGGACAATGAAGATGAGCATTTGACAAACAACAGTATGCAGTTCCACGGGCATATGGGGTTTAGGCTTATCGGTACATTTAAAAAGTGCGGTTACAAGTTCGACAAGTGGTATGATATGATTTGGATGGAGAAATTTATCGGTGAACATAAGGTTAATCCCGACGCGGTGACAAGACCGGAAATTTAG\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 2647,
      "end": 3573,
      "strand": 1,
      "locus_tag": "ctg87_5",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,647 - 3,573,\n (total: 927 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MANKVEDLVNVILDSYNECDITARIDEENMLNKDILIEIIDEIRKVLFPGFFDNNKVRSEYLKFLVGERLEFIQYHLKKQVSNAFANQDVCRECSKAQAEEKAEEVVFEFLKKIPKIREYLNTDIQAAYDGDPAAYSTDEIIFCYPGVFAITVYRIAHELWLLGVPMIPRIMTEYAHSTTGIDIHPGATVGKYFFIDHGTGIVIGETTEIGDNVKIYQGVTLGALSTRKGQQLKGVKRHPTISDNVTIYSGTTILGGETVVGKGTTIGGNAFIVNSVSEGMKVSVKNPELEYSVGNASMKDGYWDWCI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MANKVEDLVNVILDSYNECDITARIDEENMLNKDILIEIIDEIRKVLFPGFFDNNKVRSEYLKFLVGERLEFIQYHLKKQVSNAFANQDVCRECSKAQAEEKAEEVVFEFLKKIPKIREYLNTDIQAAYDGDPAAYSTDEIIFCYPGVFAITVYRIAHELWLLGVPMIPRIMTEYAHSTTGIDIHPGATVGKYFFIDHGTGIVIGETTEIGDNVKIYQGVTLGALSTRKGQQLKGVKRHPTISDNVTIYSGTTILGGETVVGKGTTIGGNAFIVNSVSEGMKVSVKNPELEYSVGNASMKDGYWDWCI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCGAATAAAGTAGAAGATTTAGTCAATGTGATTTTAGACAGCTACAATGAATGTGACATTACAGCGAGAATTGACGAAGAGAATATGCTTAACAAGGATATTCTTATAGAAATTATAGATGAAATAAGAAAAGTGCTTTTTCCGGGCTTTTTTGACAACAACAAGGTCAGAAGTGAATACTTAAAGTTTCTTGTCGGTGAAAGACTGGAATTTATACAGTATCATTTGAAGAAACAGGTGTCAAACGCGTTTGCAAATCAAGATGTATGCAGAGAGTGCAGTAAGGCACAGGCAGAGGAAAAAGCGGAAGAAGTTGTTTTTGAATTTTTAAAGAAAATACCGAAAATAAGAGAATACTTAAATACAGACATTCAAGCTGCGTATGACGGTGACCCTGCGGCATACAGCACAGATGAAATAATTTTCTGTTATCCGGGAGTGTTTGCAATCACTGTTTACAGAATTGCTCACGAATTGTGGCTTTTGGGCGTGCCTATGATTCCGAGAATAATGACGGAATATGCTCACAGCACAACAGGTATAGATATTCACCCGGGTGCGACTGTCGGCAAATATTTCTTTATAGACCACGGTACAGGTATTGTTATAGGTGAAACTACCGAAATCGGCGATAATGTAAAAATATATCAAGGCGTTACTTTAGGCGCACTTTCGACAAGAAAAGGTCAGCAGTTAAAGGGCGTTAAACGTCATCCGACTATCAGTGACAACGTTACGATATATTCGGGTACGACTATTCTCGGCGGTGAAACGGTTGTCGGTAAGGGTACGACTATCGGCGGTAATGCGTTTATCGTTAATTCCGTTTCGGAGGGTATGAAAGTCAGCGTGAAAAATCCCGAACTTGAGTACAGTGTCGGAAATGCGTCTATGAAGGACGGTTATTGGGATTGGTGTATATAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 4112,
      "end": 5401,
      "strand": 1,
      "locus_tag": "ctg87_6",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,112 - 5,401,\n (total: 1290 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) DegT_DnrJ_EryC1<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSNKNWRFETKQLHVGQEQADPVTDSRAVPIYASTSFVFHNSQHAADRFGLRDAGNIYGRLTNPTEDIFEQRIAALEGGVAALAVASGAAALAYTFQTLAKQGDHIVAAKTIYGGTYNYLEHTFPEFGVTTTFVDPEVDGAFEAAIQDNTKAIFIETLGNPNSNLIDIEEIAKIAHAHNIPLVVDSTFATPYLVRPIEYGADIVVHSATKFIGGHGTAIGGVIVDSGNFDWAKSGKFPHLVEPNASYHGISFANDVGAAAFVTYIRAILLRDTGATLSPFHAFIFLQGLETLSLRVERHVENALKIVDYLNKHPKVEAVHHPSLPTEPSHELYKKYLPNGGGSIFTFEIKGGVEEAHKFIDNLEIFSLLANVADSKSLVIHPATTTHSQCNEQELAEQGIKPNTIRLSIGTENIDDLIAALDDAFNAVD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSNKNWRFETKQLHVGQEQADPVTDSRAVPIYASTSFVFHNSQHAADRFGLRDAGNIYGRLTNPTEDIFEQRIAALEGGVAALAVASGAAALAYTFQTLAKQGDHIVAAKTIYGGTYNYLEHTFPEFGVTTTFVDPEVDGAFEAAIQDNTKAIFIETLGNPNSNLIDIEEIAKIAHAHNIPLVVDSTFATPYLVRPIEYGADIVVHSATKFIGGHGTAIGGVIVDSGNFDWAKSGKFPHLVEPNASYHGISFANDVGAAAFVTYIRAILLRDTGATLSPFHAFIFLQGLETLSLRVERHVENALKIVDYLNKHPKVEAVHHPSLPTEPSHELYKKYLPNGGGSIFTFEIKGGVEEAHKFIDNLEIFSLLANVADSKSLVIHPATTTHSQCNEQELAEQGIKPNTIRLSIGTENIDDLIAALDDAFNAVD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCAAATAAGAATTGGAGATTTGAAACAAAGCAATTACACGTTGGTCAGGAACAAGCAGATCCTGTTACAGATTCAAGAGCTGTTCCGATTTATGCATCAACATCATTCGTATTCCACAACTCACAGCACGCAGCTGACCGTTTCGGTTTGAGAGATGCAGGTAACATCTACGGCAGACTTACAAACCCTACAGAAGATATTTTTGAACAGAGAATAGCAGCCCTTGAAGGCGGTGTTGCTGCATTGGCAGTTGCATCGGGTGCGGCAGCTCTTGCTTATACATTCCAAACACTTGCTAAGCAAGGCGATCACATCGTAGCCGCAAAGACAATTTACGGCGGAACATACAACTATCTTGAACATACATTCCCTGAATTCGGTGTTACAACAACATTCGTTGACCCTGAAGTTGACGGTGCATTTGAAGCAGCTATTCAGGATAACACAAAGGCAATCTTCATTGAAACACTTGGTAACCCAAATTCAAACCTAATTGATATTGAAGAAATTGCAAAGATTGCTCACGCACATAACATTCCGCTTGTAGTTGACTCAACATTCGCTACACCTTATCTTGTAAGACCAATCGAATACGGTGCAGACATCGTTGTTCACAGTGCAACTAAGTTTATCGGGGGTCACGGTACTGCAATCGGCGGTGTAATCGTTGACAGCGGTAACTTTGACTGGGCTAAGTCGGGTAAGTTCCCTCACCTTGTAGAGCCTAACGCATCATATCACGGTATCAGCTTTGCAAATGATGTAGGAGCTGCCGCATTTGTAACATATATCAGAGCTATCCTGCTTCGTGACACAGGTGCTACACTTTCACCGTTCCACGCATTCATCTTCTTACAGGGTCTTGAAACTCTATCACTAAGAGTTGAACGTCACGTTGAAAACGCTCTAAAGATTGTTGATTACCTAAACAAGCATCCAAAGGTAGAGGCTGTTCATCATCCGTCACTACCTACAGAGCCAAGCCACGAACTATACAAGAAGTATCTTCCAAACGGCGGCGGAAGTATCTTTACATTTGAAATCAAGGGCGGAGTTGAAGAGGCTCACAAGTTTATCGATAACCTTGAAATTTTCTCGCTTCTTGCAAATGTTGCAGACTCTAAGTCACTTGTAATTCACCCGGCTACAACTACTCATTCACAGTGCAATGAACAGGAACTTGCAGAACAGGGTATTAAGCCAAATACAATAAGACTATCAATCGGTACAGAAAATATTGATGACCTTATTGCAGCTCTTGACGACGCATTCAACGCCGTTGACTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 5444,
      "end": 6376,
      "strand": 1,
      "locus_tag": "ctg87_7",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,444 - 6,376,\n (total: 933 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSKIYQKITDLIGGTPLLELANYEKKNNLEATVLGKLEYFNPAGSVKDRIAKAMVDEAEQEGKLKEGSVIIEPTSGNTGIGLASVAAARGYKIIITMPETMSIERRNLLKAYGAELVLTDGAKGMKGAIEKAKELAETTENSFIPSQFTNPANPAYHRATTGPEIWADTDGKVDIFVAGVGTGGTVTGVGQYLKSQNPDVKVVAVEPAGSPVLSQGKAGAHKIQGIGAGFVPETLDTKVYDEIITVENEDAFKTGRDIARSEGVLVGISSGAAVWAATELAKRPENKGKTIVALLPDTGERYLSTPMFAE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSKIYQKITDLIGGTPLLELANYEKKNNLEATVLGKLEYFNPAGSVKDRIAKAMVDEAEQEGKLKEGSVIIEPTSGNTGIGLASVAAARGYKIIITMPETMSIERRNLLKAYGAELVLTDGAKGMKGAIEKAKELAETTENSFIPSQFTNPANPAYHRATTGPEIWADTDGKVDIFVAGVGTGGTVTGVGQYLKSQNPDVKVVAVEPAGSPVLSQGKAGAHKIQGIGAGFVPETLDTKVYDEIITVENEDAFKTGRDIARSEGVLVGISSGAAVWAATELAKRPENKGKTIVALLPDTGERYLSTPMFAE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCAAAGATATATCAGAAAATTACAGATCTTATCGGTGGTACACCGCTATTGGAACTTGCAAACTATGAAAAGAAGAATAACCTTGAAGCAACAGTTCTTGGTAAGCTTGAATACTTTAACCCTGCCGGTTCGGTAAAAGACAGAATCGCAAAGGCAATGGTTGATGAGGCTGAACAAGAGGGTAAGTTAAAGGAAGGTTCTGTTATCATCGAGCCAACATCAGGTAATACAGGTATCGGTCTTGCGTCGGTTGCCGCCGCAAGAGGTTATAAAATTATAATCACAATGCCTGAAACAATGAGTATTGAAAGACGTAATCTATTAAAAGCATATGGCGCCGAACTTGTTTTGACAGACGGTGCAAAGGGTATGAAAGGTGCTATCGAAAAGGCTAAGGAACTTGCTGAAACAACAGAAAACAGCTTTATCCCAAGCCAGTTCACAAACCCTGCAAACCCTGCTTATCACAGAGCAACAACAGGCCCTGAAATCTGGGCAGATACAGACGGTAAAGTTGATATATTTGTTGCCGGCGTAGGTACAGGCGGTACAGTTACCGGTGTAGGTCAGTATCTAAAGTCACAAAACCCTGACGTTAAGGTTGTTGCAGTTGAGCCTGCAGGCTCACCGGTATTGTCACAAGGCAAAGCAGGTGCGCACAAAATTCAAGGTATCGGTGCAGGTTTCGTTCCTGAAACTCTTGATACAAAGGTTTATGACGAAATCATTACTGTTGAAAACGAGGACGCATTCAAGACAGGCAGAGATATTGCCCGCAGTGAAGGTGTACTTGTAGGTATTTCATCAGGTGCGGCTGTTTGGGCGGCTACAGAGCTTGCCAAACGCCCTGAAAACAAGGGTAAAACAATCGTAGCTCTTTTGCCTGATACAGGTGAAAGATATTTGTCAACTCCTATGTTTGCTGAATAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 6415,
      "end": 6654,
      "strand": 1,
      "locus_tag": "ctg87_8",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,415 - 6,654,\n (total: 240 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKMPSFCVRFFGHCSCYNIIIIKLNCQSEVGVLRVKNEKFSKITLTKTEVNIMVIVGTILISVGASILFVLKVNSVKDI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKMPSFCVRFFGHCSCYNIIIIKLNCQSEVGVLRVKNEKFSKITLTKTEVNIMVIVGTILISVGASILFVLKVNSVKDI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAATGCCATCTTTTTGTGTACGGTTTTTTGGACATTGTAGTTGTTATAATATAATCATAATAAAGCTAAATTGTCAAAGTGAAGTTGGGGTTTTGAGGGTAAAAAACGAGAAATTTTCTAAGATCACCTTGACAAAAACGGAGGTAAATATTATGGTTATAGTGGGAACAATACTTATAAGTGTAGGAGCGTCAATACTTTTTGTATTAAAGGTTAATTCGGTAAAGGATATATAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 6695,
      "end": 7453,
      "strand": 1,
      "locus_tag": "ctg87_9",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,695 - 7,453,\n (total: 759 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MQINELVTFAADVGRGLLESGAETSRVEDTVERIIRHFYDGKSEVLVVMTGLFVTVGDVTKTVRVRRRTINLDKVSKINMMSRDIADDKIDFEEALKRFEYIMAQKPYSLWVKTVAVAFCCGFFTLLFGGNAFDGLNSLVVGAVINVFIWFLRKRHTAEFIITFSGGVVIALLILLFYAIGLGKNINPMITGAIMPLVPGLAITNAIRDIIAGDYLSGGARLFDAVVVAIALATGAGSVMYIFGHMTGGVMG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MQINELVTFAADVGRGLLESGAETSRVEDTVERIIRHFYDGKSEVLVVMTGLFVTVGDVTKTVRVRRRTINLDKVSKINMMSRDIADDKIDFEEALKRFEYIMAQKPYSLWVKTVAVAFCCGFFTLLFGGNAFDGLNSLVVGAVINVFIWFLRKRHTAEFIITFSGGVVIALLILLFYAIGLGKNINPMITGAIMPLVPGLAITNAIRDIIAGDYLSGGARLFDAVVVAIALATGAGSVMYIFGHMTGGVMG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCAGATAAATGAACTTGTGACATTTGCGGCGGATGTCGGCAGAGGTTTGCTTGAAAGCGGTGCGGAAACGAGTCGTGTCGAAGATACGGTTGAGAGGATAATACGGCACTTTTATGACGGTAAAAGTGAGGTTTTGGTCGTAATGACAGGACTGTTTGTCACTGTCGGCGATGTTACAAAAACGGTCAGAGTTCGCAGACGGACTATAAACCTTGATAAAGTATCGAAAATTAATATGATGTCACGAGATATTGCTGATGATAAAATCGACTTTGAAGAAGCTTTAAAACGCTTTGAATATATAATGGCACAGAAACCTTATTCGTTATGGGTGAAAACTGTTGCGGTAGCGTTTTGCTGTGGATTTTTTACGTTGTTGTTTGGCGGTAATGCGTTTGACGGACTTAATTCGCTTGTGGTCGGCGCGGTTATCAATGTTTTTATATGGTTTTTGAGAAAACGTCACACGGCGGAGTTTATTATAACATTTTCAGGCGGAGTTGTTATTGCGTTGCTGATATTACTTTTTTATGCAATAGGTTTGGGAAAAAATATTAATCCTATGATAACGGGAGCTATTATGCCGCTTGTACCAGGTTTGGCAATAACTAATGCAATTCGTGATATTATTGCCGGAGATTACCTTTCGGGCGGTGCGAGATTGTTTGATGCGGTAGTCGTGGCGATTGCACTTGCCACAGGTGCGGGCAGTGTTATGTACATTTTCGGTCATATGACGGGAGGTGTTATGGGATGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 7450,
      "end": 7878,
      "strand": 1,
      "locus_tag": "ctg87_10",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,450 - 7,878,\n (total: 429 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIFLEMFVAFAATMAFAVTFNVSRSELIFCGIAGLVAEGVYLFTLRISDETALAIFVASIAVTVLSRILANVRRMPVTVYLISGIISLVPGAGMYNTVYNIISSDYIKAIYTGVDTIKVAVAIAVGIVLVFALPNKMFFKRK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIFLEMFVAFAATMAFAVTFNVSRSELIFCGIAGLVAEGVYLFTLRISDETALAIFVASIAVTVLSRILANVRRMPVTVYLISGIISLVPGAGMYNTVYNIISSDYIKAIYTGVDTIKVAVAIAVGIVLVFALPNKMFFKRK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATTTTTCTTGAAATGTTTGTCGCTTTTGCGGCGACAATGGCTTTTGCAGTGACATTTAACGTGAGCCGAAGTGAATTGATATTTTGCGGAATCGCAGGTTTAGTCGCAGAGGGGGTGTATTTGTTTACACTTAGAATAAGCGACGAAACGGCACTTGCTATATTTGTTGCGTCGATTGCCGTGACGGTATTGTCGCGAATTTTGGCGAATGTAAGACGTATGCCCGTTACGGTTTATTTGATTTCGGGAATAATATCGCTTGTACCCGGTGCGGGTATGTATAACACTGTTTATAACATAATATCGTCGGACTATATAAAAGCAATATACACAGGCGTTGATACAATAAAAGTTGCCGTAGCGATTGCGGTGGGGATTGTACTTGTGTTTGCATTGCCTAATAAAATGTTTTTCAAGAGAAAATAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 8077,
      "end": 8391,
      "strand": 1,
      "locus_tag": "ctg87_11",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,077 - 8,391,\n (total: 315 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKKIIAVMAVLITLFSMGNVSASAAAKVAALMYHSVTTDSSRWNDYTISPEQLDADIQYFKSCGYIPMTATELATANMADIDNRKILLLTFDDGYSNFYTEVFPI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKKIIAVMAVLITLFSMGNVSASAAAKVAALMYHSVTTDSSRWNDYTISPEQLDADIQYFKSCGYIPMTATELATANMADIDNRKILLLTFDDGYSNFYTEVFPI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAAAGATAATTGCCGTTATGGCGGTGCTTATAACGCTTTTTTCAATGGGTAATGTGTCGGCAAGTGCGGCGGCAAAGGTTGCGGCACTGATGTATCACAGTGTGACAACTGATTCGTCACGTTGGAATGACTATACAATATCACCCGAACAGCTTGACGCAGATATACAATACTTTAAAAGCTGCGGATATATACCGATGACTGCGACAGAACTCGCAACGGCGAATATGGCTGATATTGACAACAGAAAAATATTGCTTTTGACATTTGATGACGGATACTCAAACTTCTATACGGAGGTATTTCCGATA\">Copy to clipboard</span><br>\n</div>"
     }
    ],
    "clusters": [
     {
      "start": 953,
      "end": 1708,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 8393,
      "product": "cyclic-lactone-autoinducer",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "ttaCodons": [],
    "type": "cyclic-lactone-autoinducer",
    "products": [
     "cyclic-lactone-autoinducer"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP cyclic-lactone-autoinducer",
    "anchor": "r87c1"
   }
  ]
 },
 {
  "length": 8315,
  "seq_id": "c00088_NODE_51..",
  "regions": []
 },
 {
  "length": 8303,
  "seq_id": "c00089_NODE_51..",
  "regions": []
 },
 {
  "length": 8168,
  "seq_id": "c00090_NODE_52..",
  "regions": []
 },
 {
  "length": 8082,
  "seq_id": "c00091_NODE_53..",
  "regions": []
 },
 {
  "length": 7964,
  "seq_id": "c00092_NODE_54..",
  "regions": []
 },
 {
  "length": 7881,
  "seq_id": "c00093_NODE_54..",
  "regions": []
 },
 {
  "length": 7858,
  "seq_id": "c00094_NODE_54..",
  "regions": []
 },
 {
  "length": 7793,
  "seq_id": "c00095_NODE_55..",
  "regions": []
 },
 {
  "length": 7692,
  "seq_id": "c00096_NODE_56..",
  "regions": []
 },
 {
  "length": 7678,
  "seq_id": "c00097_NODE_56..",
  "regions": []
 },
 {
  "length": 7650,
  "seq_id": "c00098_NODE_56..",
  "regions": []
 },
 {
  "length": 7644,
  "seq_id": "c00099_NODE_56..",
  "regions": []
 },
 {
  "length": 7642,
  "seq_id": "c00100_NODE_56..",
  "regions": []
 },
 {
  "length": 7583,
  "seq_id": "c00101_NODE_56..",
  "regions": []
 },
 {
  "length": 7568,
  "seq_id": "c00102_NODE_56..",
  "regions": []
 },
 {
  "length": 7543,
  "seq_id": "c00103_NODE_57..",
  "regions": []
 },
 {
  "length": 7535,
  "seq_id": "c00104_NODE_57..",
  "regions": []
 },
 {
  "length": 7511,
  "seq_id": "c00105_NODE_57..",
  "regions": []
 },
 {
  "length": 7288,
  "seq_id": "c00106_NODE_58..",
  "regions": []
 },
 {
  "length": 7275,
  "seq_id": "c00107_NODE_59..",
  "regions": []
 },
 {
  "length": 7246,
  "seq_id": "c00108_NODE_59..",
  "regions": []
 },
 {
  "length": 7220,
  "seq_id": "c00109_NODE_59..",
  "regions": []
 },
 {
  "length": 7218,
  "seq_id": "c00110_NODE_59..",
  "regions": []
 },
 {
  "length": 7205,
  "seq_id": "c00111_NODE_59..",
  "regions": []
 },
 {
  "length": 7142,
  "seq_id": "c00112_NODE_60..",
  "regions": []
 },
 {
  "length": 7100,
  "seq_id": "c00113_NODE_60..",
  "regions": []
 },
 {
  "length": 7098,
  "seq_id": "c00114_NODE_60..",
  "regions": []
 },
 {
  "length": 6879,
  "seq_id": "c00115_NODE_62..",
  "regions": []
 },
 {
  "length": 6837,
  "seq_id": "c00116_NODE_62..",
  "regions": []
 },
 {
  "length": 6827,
  "seq_id": "c00117_NODE_63..",
  "regions": []
 },
 {
  "length": 6655,
  "seq_id": "c00118_NODE_64..",
  "regions": []
 },
 {
  "length": 6583,
  "seq_id": "c00119_NODE_65..",
  "regions": []
 },
 {
  "length": 6535,
  "seq_id": "c00120_NODE_65..",
  "regions": []
 },
 {
  "length": 6518,
  "seq_id": "c00121_NODE_66..",
  "regions": []
 },
 {
  "length": 6515,
  "seq_id": "c00122_NODE_66..",
  "regions": []
 },
 {
  "length": 6383,
  "seq_id": "c00123_NODE_67..",
  "regions": []
 },
 {
  "length": 6335,
  "seq_id": "c00124_NODE_68..",
  "regions": []
 },
 {
  "length": 6315,
  "seq_id": "c00125_NODE_68..",
  "regions": []
 },
 {
  "length": 6311,
  "seq_id": "c00126_NODE_68..",
  "regions": []
 },
 {
  "length": 6222,
  "seq_id": "c00127_NODE_69..",
  "regions": []
 },
 {
  "length": 6165,
  "seq_id": "c00128_NODE_70..",
  "regions": []
 },
 {
  "length": 6095,
  "seq_id": "c00129_NODE_71..",
  "regions": []
 },
 {
  "length": 6091,
  "seq_id": "c00130_NODE_71..",
  "regions": []
 },
 {
  "length": 6077,
  "seq_id": "c00131_NODE_71..",
  "regions": []
 },
 {
  "length": 6046,
  "seq_id": "c00132_NODE_71..",
  "regions": []
 },
 {
  "length": 6040,
  "seq_id": "c00133_NODE_72..",
  "regions": []
 },
 {
  "length": 5987,
  "seq_id": "c00134_NODE_72..",
  "regions": []
 },
 {
  "length": 5851,
  "seq_id": "c00135_NODE_74..",
  "regions": []
 },
 {
  "length": 5833,
  "seq_id": "c00136_NODE_75..",
  "regions": []
 },
 {
  "length": 5794,
  "seq_id": "c00137_NODE_75..",
  "regions": []
 },
 {
  "length": 5786,
  "seq_id": "c00138_NODE_75..",
  "regions": []
 },
 {
  "length": 5719,
  "seq_id": "c00139_NODE_76..",
  "regions": []
 },
 {
  "length": 5686,
  "seq_id": "c00140_NODE_77..",
  "regions": []
 },
 {
  "length": 5685,
  "seq_id": "c00141_NODE_77..",
  "regions": []
 },
 {
  "length": 5667,
  "seq_id": "c00142_NODE_77..",
  "regions": []
 },
 {
  "length": 5663,
  "seq_id": "c00143_NODE_77..",
  "regions": []
 },
 {
  "length": 5509,
  "seq_id": "c00144_NODE_79..",
  "regions": []
 },
 {
  "length": 5503,
  "seq_id": "c00145_NODE_79..",
  "regions": []
 },
 {
  "length": 5497,
  "seq_id": "c00146_NODE_80..",
  "regions": []
 },
 {
  "length": 5480,
  "seq_id": "c00147_NODE_80..",
  "regions": []
 },
 {
  "length": 5446,
  "seq_id": "c00148_NODE_80..",
  "regions": [
   {
    "start": 1,
    "end": 5446,
    "idx": 1,
    "orfs": [
     {
      "start": 3,
      "end": 479,
      "strand": 1,
      "locus_tag": "ctg148_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 479,\n (total: 477 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=IIMLTGDHEGAAKRTADMLGIDNFRAQVLPEDKATIIEELKNEGRTVIMVGDGINDSPALALSDVSIAMKDSADLAREVADVTLLSGDLRDLALLRKLSSRLFRRIKRNYTFIMAFNSLLILLGLKGTITPSASSLLHNSSTMLISANSMRPLLNDKN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"IIMLTGDHEGAAKRTADMLGIDNFRAQVLPEDKATIIEELKNEGRTVIMVGDGINDSPALALSDVSIAMKDSADLAREVADVTLLSGDLRDLALLRKLSSRLFRRIKRNYTFIMAFNSLLILLGLKGTITPSASSLLHNSSTMLISANSMRPLLNDKN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATTATTATGCTTACAGGTGACCATGAAGGTGCTGCAAAACGCACTGCCGATATGCTCGGTATAGACAATTTCCGTGCACAGGTATTACCTGAGGATAAGGCGACAATTATTGAAGAATTGAAGAACGAGGGAAGAACGGTTATAATGGTCGGTGACGGTATCAATGACTCTCCTGCATTGGCACTTAGCGACGTTTCAATTGCTATGAAAGATTCTGCCGATTTGGCAAGAGAAGTGGCTGATGTCACATTGCTTTCGGGCGATTTGAGAGATTTAGCGCTTCTTCGCAAGTTAAGCAGCAGACTGTTCAGACGAATTAAACGTAATTATACGTTTATTATGGCATTTAATTCATTGCTTATTTTGCTTGGATTGAAAGGTACTATAACTCCGTCTGCATCATCACTTTTGCATAATTCGTCAACTATGCTTATAAGTGCGAACAGTATGCGTCCATTATTGAATGACAAGAATTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 631,
      "end": 1233,
      "strand": 1,
      "locus_tag": "ctg148_2",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 631 - 1,233,\n (total: 603 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VRIEKLNKDKIKVTLTTAELINLDIDVKRLSPDSKELHTFLFHIMETIREETGFNPYNGQVVVEATPSQDGISILVKRLNKGIKKITEEQFKKVVSVKPKKKEPGTECVFYFETFNDMCGAISEMDKSILSKASLFKLNKTYCILIRNDNENMRGINVIREFTERMSIYPLQNEYIKEHALLVAKGQKLVEMAENVKRLM&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VRIEKLNKDKIKVTLTTAELINLDIDVKRLSPDSKELHTFLFHIMETIREETGFNPYNGQVVVEATPSQDGISILVKRLNKGIKKITEEQFKKVVSVKPKKKEPGTECVFYFETFNDMCGAISEMDKSILSKASLFKLNKTYCILIRNDNENMRGINVIREFTERMSIYPLQNEYIKEHALLVAKGQKLVEMAENVKRLM\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGAGAATTGAAAAGCTAAACAAAGACAAAATAAAGGTAACGCTTACAACTGCGGAATTAATTAATCTTGATATAGACGTGAAAAGGCTTTCGCCCGATTCAAAAGAATTACATACATTTTTATTTCATATTATGGAAACGATAAGGGAAGAAACAGGTTTTAATCCGTATAACGGTCAAGTGGTCGTTGAGGCTACTCCGTCACAGGACGGTATAAGTATTTTGGTTAAACGTTTAAACAAGGGTATAAAAAAAATTACCGAGGAGCAGTTTAAAAAAGTTGTTTCGGTCAAGCCTAAAAAGAAAGAACCGGGTACGGAATGTGTATTTTATTTTGAAACTTTTAATGATATGTGCGGCGCTATAAGCGAAATGGATAAAAGTATTCTTTCAAAAGCAAGCCTTTTTAAGCTGAATAAAACATATTGTATTCTCATAAGAAACGATAATGAGAATATGAGAGGCATTAATGTAATAAGAGAGTTTACGGAAAGAATGTCGATATACCCGTTGCAGAATGAGTACATAAAAGAACATGCTCTTCTTGTCGCAAAAGGTCAAAAACTTGTTGAAATGGCTGAAAACGTCAAACGATTGATGTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 1333,
      "end": 1734,
      "strand": 1,
      "locus_tag": "ctg148_3",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,333 - 1,734,\n (total: 402 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MANILETVVFADGETANTQQATGTQTAADPNATQQVNPVMSTIVSILPLVLIIVLLYFMMIRPQRKKEKETKAMINAMKVGDKVVTIGGICGKVAKIKDEYVFIETGNIGTPDQKSVVKMERDAIRTVETAKN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MANILETVVFADGETANTQQATGTQTAADPNATQQVNPVMSTIVSILPLVLIIVLLYFMMIRPQRKKEKETKAMINAMKVGDKVVTIGGICGKVAKIKDEYVFIETGNIGTPDQKSVVKMERDAIRTVETAKN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCAAACATTTTAGAAACAGTCGTTTTCGCAGACGGCGAAACAGCAAATACACAACAGGCGACAGGTACTCAAACAGCGGCAGACCCTAATGCTACACAACAGGTTAATCCTGTAATGAGTACAATAGTAAGTATTCTTCCGCTTGTTCTTATTATCGTATTGTTATACTTTATGATGATAAGACCGCAAAGAAAGAAAGAAAAAGAAACAAAGGCAATGATTAACGCAATGAAAGTCGGCGATAAGGTTGTAACAATCGGCGGTATCTGCGGTAAGGTTGCTAAAATTAAAGACGAATATGTTTTTATTGAAACAGGTAACATCGGTACACCGGATCAAAAGTCTGTTGTAAAGATGGAAAGAGACGCTATCAGAACTGTTGAAACAGCTAAAAACTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 1796,
      "end": 2152,
      "strand": 1,
      "locus_tag": "ctg148_4",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,796 - 2,152,\n (total: 357 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MGINFKGVIKGTIFAILVTFVIILILALLSYFTGIDETIITTGVYASVIIGVILGTIAVSKAANSRAFVHAMLVCALYLIVLIGISLIVNNGIMFNTHFLAVIGGTFASGILGCIIGK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MGINFKGVIKGTIFAILVTFVIILILALLSYFTGIDETIITTGVYASVIIGVILGTIAVSKAANSRAFVHAMLVCALYLIVLIGISLIVNNGIMFNTHFLAVIGGTFASGILGCIIGK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGGTATTAATTTTAAGGGTGTGATAAAAGGGACGATATTTGCAATTCTTGTTACTTTTGTTATAATTCTGATATTGGCACTGCTTTCGTATTTTACAGGCATAGACGAAACTATTATCACAACCGGAGTGTATGCCTCGGTTATTATCGGCGTGATACTCGGAACGATTGCGGTATCAAAAGCGGCAAACAGCAGAGCATTTGTTCACGCAATGCTTGTATGTGCGCTGTATTTGATCGTACTTATCGGAATATCGTTGATTGTAAACAATGGAATAATGTTTAACACGCATTTTCTTGCTGTAATAGGCGGTACATTTGCATCGGGAATATTGGGGTGCATCATAGGAAAATAG\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 2268,
      "end": 2411,
      "strand": 1,
      "locus_tag": "ctg148_5",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,268 - 2,411,\n (total: 144 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR03973<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SCIFF<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKHVQTLNKANLKDSAKHGGCGECQTSCQSACKTSCTVANQKCEQAN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKHVQTLNKANLKDSAKHGGCGECQTSCQSACKTSCTVANQKCEQAN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAACACGTACAGACTTTAAACAAGGCTAATTTAAAGGATTCAGCAAAGCACGGTGGTTGCGGAGAATGTCAAACATCATGTCAATCAGCTTGTAAGACATCTTGCACAGTTGCAAATCAAAAATGTGAACAAGCAAACTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 2500,
      "end": 3870,
      "strand": 1,
      "locus_tag": "ctg148_6",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,500 - 3,870,\n (total: 1371 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SPASM<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VIHKYKQLGLNIVMDVYSGAVHVVDDVMYDMLDYTLEPFMAEAKCPDYIKEGLKDKYSEEELEESYAEICALVNAGQLFTDDCYDEIAKNWNKQSVVKALCIHVAHDCNLRCKYCFADTGEFHGGRSLMSAEVGKKAIDFVINNSGNRKNIEIDYFGGEPLMNFGVVKEITEYAKEEAKKHGKNFRFTVTTNGVLLNDDIKQYINENMSNVVLSIDGTKETNDRMRYRVDGSGSYDTIVPKFQDLAESRNQNNYYVRGTFTAYNVDFAKDVIHLADLGFKQTSVEPVVAPETEDYALTSEHIEKVCAEYDKLTEEYVKRYDEGRGFNFFHFMVDLDQGPCAIKRLSGCGAGHEYLAVAPNGDIYPCHQFVGNKDFLMGNVNENKIDENIEKMFERSNVYTKEKCKNCFAKFYCSGGCSANAYNFNGDINKPYELACEFEKKRLECSIAIEAHKKLS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VIHKYKQLGLNIVMDVYSGAVHVVDDVMYDMLDYTLEPFMAEAKCPDYIKEGLKDKYSEEELEESYAEICALVNAGQLFTDDCYDEIAKNWNKQSVVKALCIHVAHDCNLRCKYCFADTGEFHGGRSLMSAEVGKKAIDFVINNSGNRKNIEIDYFGGEPLMNFGVVKEITEYAKEEAKKHGKNFRFTVTTNGVLLNDDIKQYINENMSNVVLSIDGTKETNDRMRYRVDGSGSYDTIVPKFQDLAESRNQNNYYVRGTFTAYNVDFAKDVIHLADLGFKQTSVEPVVAPETEDYALTSEHIEKVCAEYDKLTEEYVKRYDEGRGFNFFHFMVDLDQGPCAIKRLSGCGAGHEYLAVAPNGDIYPCHQFVGNKDFLMGNVNENKIDENIEKMFERSNVYTKEKCKNCFAKFYCSGGCSANAYNFNGDINKPYELACEFEKKRLECSIAIEAHKKLS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGATACATAAGTATAAACAGTTGGGACTTAATATTGTAATGGATGTATATTCAGGTGCGGTACACGTTGTTGATGATGTAATGTACGATATGCTTGATTATACTCTTGAGCCGTTTATGGCAGAGGCAAAATGTCCCGATTATATTAAAGAAGGTTTAAAAGATAAGTATAGTGAAGAAGAATTGGAAGAAAGCTATGCTGAAATATGTGCACTTGTAAATGCAGGTCAGTTGTTTACAGATGATTGCTATGACGAAATCGCGAAGAATTGGAATAAGCAATCTGTTGTAAAGGCTCTTTGTATTCACGTTGCACATGACTGTAATTTGAGATGTAAGTATTGTTTTGCCGATACAGGTGAATTTCACGGTGGCAGAAGTCTTATGAGTGCGGAAGTAGGTAAGAAAGCTATTGATTTTGTTATCAATAACAGCGGTAACAGAAAAAATATAGAAATCGACTACTTCGGCGGTGAACCACTTATGAATTTCGGCGTTGTTAAGGAAATTACAGAATACGCAAAAGAAGAGGCGAAAAAGCACGGTAAGAATTTCAGATTTACTGTAACAACAAACGGTGTATTGTTAAATGACGATATTAAACAATATATTAATGAAAATATGTCAAACGTTGTTTTGAGTATTGACGGTACAAAGGAAACTAACGACAGAATGCGTTATCGTGTAGATGGCAGCGGTTCTTACGATACAATCGTTCCTAAGTTCCAAGACTTGGCTGAAAGCAGAAATCAAAATAATTACTACGTTCGCGGTACGTTTACGGCGTATAACGTGGATTTTGCAAAGGACGTAATTCACCTTGCGGATTTAGGCTTTAAGCAGACAAGCGTTGAACCGGTTGTTGCACCTGAAACAGAGGACTACGCACTTACAAGTGAGCATATCGAAAAGGTCTGTGCCGAATATGATAAGCTTACTGAAGAATATGTAAAGAGATATGACGAGGGCAGAGGTTTTAACTTCTTCCACTTTATGGTTGACCTTGACCAAGGTCCGTGTGCGATAAAGCGTCTTTCAGGTTGTGGTGCAGGACACGAATATCTTGCGGTTGCACCGAACGGAGACATTTATCCGTGTCACCAATTTGTCGGTAACAAGGATTTTCTTATGGGTAATGTCAATGAAAATAAAATTGATGAAAATATCGAGAAGATGTTTGAACGCTCAAATGTGTATACTAAAGAAAAATGTAAGAATTGTTTTGCAAAATTCTATTGCAGCGGTGGTTGCAGTGCGAATGCGTATAACTTTAACGGTGATATAAACAAGCCTTATGAGCTTGCTTGTGAATTTGAAAAAAAGCGTCTTGAATGTTCAATAGCAATCGAGGCACATAAAAAATTAAGTTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 3889,
      "end": 4203,
      "strand": 1,
      "locus_tag": "ctg148_7",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,889 - 4,203,\n (total: 315 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIHKGFKMKLYDGMAEEYEKRHNELWPEMKDMIHEHGGKNYSIFLDKETMVLYGYIEIEDEELWAKGADTAINRKWWDFMADIMETNPDNSPVSEDLHLVFHLD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIHKGFKMKLYDGMAEEYEKRHNELWPEMKDMIHEHGGKNYSIFLDKETMVLYGYIEIEDEELWAKGADTAINRKWWDFMADIMETNPDNSPVSEDLHLVFHLD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATACACAAGGGTTTTAAAATGAAACTTTACGACGGTATGGCTGAGGAGTACGAAAAAAGACATAATGAGTTATGGCCGGAAATGAAGGATATGATTCACGAACACGGCGGTAAGAATTATTCAATATTCCTTGACAAAGAAACAATGGTTCTTTACGGTTATATCGAAATCGAAGATGAAGAACTTTGGGCAAAGGGTGCCGATACCGCCATCAATAGAAAATGGTGGGACTTTATGGCTGACATTATGGAAACAAATCCTGATAACAGTCCTGTTTCAGAAGATTTACACCTTGTATTCCATTTGGATTGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 4421,
      "end": 5200,
      "strand": 1,
      "locus_tag": "ctg148_8",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,421 - 5,200,\n (total: 780 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MGEVIRGILIPFLGTTLGASCVLFMKKMMNKMVQRALTGFAAGIMVSASVWSLLIPSMDYAAEMGKFAFVPAVVGFWIGILFLLAMDHIIPHLHMDTDKAEGPKSKLKKTTMLVFAVTLHNIPEGMAVGVVYAGYLAGNMQISAMGALALAIGIAIQNFPEGAIISMPLKAEGMSKGKAFLYGVLSGVVEPIGTVLTIVASGFIIPVLPYFLSFAAGAMMYVVIEELISEMSHGDHSNIGTVMFAVGFTLMMILDVALG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MGEVIRGILIPFLGTTLGASCVLFMKKMMNKMVQRALTGFAAGIMVSASVWSLLIPSMDYAAEMGKFAFVPAVVGFWIGILFLLAMDHIIPHLHMDTDKAEGPKSKLKKTTMLVFAVTLHNIPEGMAVGVVYAGYLAGNMQISAMGALALAIGIAIQNFPEGAIISMPLKAEGMSKGKAFLYGVLSGVVEPIGTVLTIVASGFIIPVLPYFLSFAAGAMMYVVIEELISEMSHGDHSNIGTVMFAVGFTLMMILDVALG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGGCGAAGTTATAAGAGGAATATTGATACCGTTTTTGGGTACGACACTTGGTGCGTCTTGCGTACTGTTTATGAAGAAAATGATGAATAAGATGGTACAGCGTGCCTTAACAGGATTTGCGGCAGGGATTATGGTCTCCGCATCTGTGTGGAGCTTGCTTATACCGTCAATGGATTATGCGGCGGAAATGGGGAAGTTTGCATTTGTGCCGGCGGTTGTGGGATTTTGGATAGGTATATTGTTTTTGCTGGCAATGGACCATATAATACCGCATTTGCATATGGATACTGATAAAGCTGAAGGCCCGAAAAGTAAATTGAAAAAGACAACAATGCTTGTATTTGCTGTTACACTTCACAATATTCCAGAGGGAATGGCTGTGGGCGTTGTATATGCAGGTTATCTTGCAGGAAATATGCAAATATCGGCTATGGGCGCTTTGGCTTTGGCAATCGGTATTGCAATTCAGAATTTCCCGGAGGGTGCAATTATATCAATGCCACTTAAAGCCGAGGGAATGAGTAAAGGAAAAGCGTTTTTATACGGCGTGCTTTCGGGTGTGGTTGAGCCGATTGGGACAGTGCTTACCATCGTTGCGTCGGGTTTTATAATACCCGTATTGCCATATTTCCTCAGCTTTGCCGCAGGGGCGATGATGTACGTTGTAATAGAAGAATTAATTTCCGAAATGTCACACGGCGATCACTCAAATATTGGTACTGTAATGTTTGCAGTAGGTTTTACACTTATGATGATTCTTGATGTGGCACTTGGGTAA\">Copy to clipboard</span><br>\n</div>"
     }
    ],
    "clusters": [
     {
      "start": 2267,
      "end": 3870,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 5446,
      "product": "ranthipeptide",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "ttaCodons": [],
    "type": "ranthipeptide",
    "products": [
     "ranthipeptide"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP ranthipeptide",
    "anchor": "r148c1"
   }
  ]
 },
 {
  "length": 5434,
  "seq_id": "c00149_NODE_81..",
  "regions": []
 },
 {
  "length": 5291,
  "seq_id": "c00150_NODE_83..",
  "regions": []
 },
 {
  "length": 5276,
  "seq_id": "c00151_NODE_83..",
  "regions": []
 },
 {
  "length": 5233,
  "seq_id": "c00152_NODE_84..",
  "regions": []
 },
 {
  "length": 5221,
  "seq_id": "c00153_NODE_84..",
  "regions": []
 },
 {
  "length": 5218,
  "seq_id": "c00154_NODE_84..",
  "regions": []
 },
 {
  "length": 5215,
  "seq_id": "c00155_NODE_84..",
  "regions": []
 },
 {
  "length": 5203,
  "seq_id": "c00156_NODE_84..",
  "regions": []
 },
 {
  "length": 5191,
  "seq_id": "c00157_NODE_85..",
  "regions": []
 },
 {
  "length": 5091,
  "seq_id": "c00158_NODE_86..",
  "regions": []
 },
 {
  "length": 5070,
  "seq_id": "c00159_NODE_87..",
  "regions": []
 },
 {
  "length": 5016,
  "seq_id": "c00160_NODE_88..",
  "regions": []
 },
 {
  "length": 4973,
  "seq_id": "c00161_NODE_89..",
  "regions": []
 },
 {
  "length": 4867,
  "seq_id": "c00162_NODE_91..",
  "regions": []
 },
 {
  "length": 4742,
  "seq_id": "c00163_NODE_93..",
  "regions": []
 },
 {
  "length": 4711,
  "seq_id": "c00164_NODE_94..",
  "regions": []
 },
 {
  "length": 4697,
  "seq_id": "c00165_NODE_94..",
  "regions": []
 },
 {
  "length": 4695,
  "seq_id": "c00166_NODE_94..",
  "regions": []
 },
 {
  "length": 4674,
  "seq_id": "c00167_NODE_95..",
  "regions": []
 },
 {
  "length": 4654,
  "seq_id": "c00168_NODE_95..",
  "regions": []
 },
 {
  "length": 4651,
  "seq_id": "c00169_NODE_95..",
  "regions": []
 },
 {
  "length": 4550,
  "seq_id": "c00170_NODE_97..",
  "regions": []
 },
 {
  "length": 4530,
  "seq_id": "c00171_NODE_98..",
  "regions": []
 },
 {
  "length": 4406,
  "seq_id": "c00172_NODE_10..",
  "regions": []
 },
 {
  "length": 4400,
  "seq_id": "c00173_NODE_10..",
  "regions": []
 },
 {
  "length": 4363,
  "seq_id": "c00174_NODE_10..",
  "regions": []
 },
 {
  "length": 4343,
  "seq_id": "c00175_NODE_10..",
  "regions": []
 },
 {
  "length": 4290,
  "seq_id": "c00176_NODE_10..",
  "regions": []
 },
 {
  "length": 4286,
  "seq_id": "c00177_NODE_10..",
  "regions": []
 },
 {
  "length": 4215,
  "seq_id": "c00178_NODE_10..",
  "regions": []
 },
 {
  "length": 4185,
  "seq_id": "c00179_NODE_10..",
  "regions": []
 },
 {
  "length": 4161,
  "seq_id": "c00180_NODE_10..",
  "regions": []
 },
 {
  "length": 4125,
  "seq_id": "c00181_NODE_10..",
  "regions": []
 },
 {
  "length": 4103,
  "seq_id": "c00182_NODE_10..",
  "regions": []
 },
 {
  "length": 4087,
  "seq_id": "c00183_NODE_10..",
  "regions": []
 },
 {
  "length": 4041,
  "seq_id": "c00184_NODE_11..",
  "regions": []
 },
 {
  "length": 4029,
  "seq_id": "c00185_NODE_11..",
  "regions": []
 },
 {
  "length": 4021,
  "seq_id": "c00186_NODE_11..",
  "regions": []
 },
 {
  "length": 4015,
  "seq_id": "c00187_NODE_11..",
  "regions": []
 },
 {
  "length": 3998,
  "seq_id": "c00188_NODE_11..",
  "regions": []
 },
 {
  "length": 3988,
  "seq_id": "c00189_NODE_11..",
  "regions": []
 },
 {
  "length": 3933,
  "seq_id": "c00190_NODE_11..",
  "regions": []
 },
 {
  "length": 3865,
  "seq_id": "c00191_NODE_11..",
  "regions": []
 },
 {
  "length": 3865,
  "seq_id": "c00192_NODE_11..",
  "regions": []
 },
 {
  "length": 3781,
  "seq_id": "c00193_NODE_11..",
  "regions": []
 },
 {
  "length": 3760,
  "seq_id": "c00194_NODE_12..",
  "regions": []
 },
 {
  "length": 3742,
  "seq_id": "c00195_NODE_12..",
  "regions": []
 },
 {
  "length": 3739,
  "seq_id": "c00196_NODE_12..",
  "regions": []
 },
 {
  "length": 3738,
  "seq_id": "c00197_NODE_12..",
  "regions": []
 },
 {
  "length": 3727,
  "seq_id": "c00198_NODE_12..",
  "regions": []
 },
 {
  "length": 3713,
  "seq_id": "c00199_NODE_12..",
  "regions": []
 },
 {
  "length": 3693,
  "seq_id": "c00200_NODE_12..",
  "regions": []
 },
 {
  "length": 3618,
  "seq_id": "c00201_NODE_12..",
  "regions": []
 },
 {
  "length": 3585,
  "seq_id": "c00202_NODE_12..",
  "regions": []
 },
 {
  "length": 3549,
  "seq_id": "c00203_NODE_12..",
  "regions": []
 },
 {
  "length": 3547,
  "seq_id": "c00204_NODE_12..",
  "regions": []
 },
 {
  "length": 3542,
  "seq_id": "c00205_NODE_12..",
  "regions": []
 },
 {
  "length": 3499,
  "seq_id": "c00206_NODE_12..",
  "regions": []
 },
 {
  "length": 3462,
  "seq_id": "c00207_NODE_13..",
  "regions": []
 },
 {
  "length": 3428,
  "seq_id": "c00208_NODE_13..",
  "regions": []
 },
 {
  "length": 3405,
  "seq_id": "c00209_NODE_13..",
  "regions": []
 },
 {
  "length": 3399,
  "seq_id": "c00210_NODE_13..",
  "regions": []
 },
 {
  "length": 3399,
  "seq_id": "c00211_NODE_13..",
  "regions": []
 },
 {
  "length": 3384,
  "seq_id": "c00212_NODE_13..",
  "regions": []
 },
 {
  "length": 3370,
  "seq_id": "c00213_NODE_13..",
  "regions": []
 },
 {
  "length": 3367,
  "seq_id": "c00214_NODE_13..",
  "regions": []
 },
 {
  "length": 3352,
  "seq_id": "c00215_NODE_13..",
  "regions": []
 },
 {
  "length": 3347,
  "seq_id": "c00216_NODE_13..",
  "regions": []
 },
 {
  "length": 3346,
  "seq_id": "c00217_NODE_13..",
  "regions": []
 },
 {
  "length": 3339,
  "seq_id": "c00218_NODE_13..",
  "regions": []
 },
 {
  "length": 3322,
  "seq_id": "c00219_NODE_13..",
  "regions": []
 },
 {
  "length": 3307,
  "seq_id": "c00220_NODE_13..",
  "regions": []
 },
 {
  "length": 3303,
  "seq_id": "c00221_NODE_13..",
  "regions": []
 },
 {
  "length": 3286,
  "seq_id": "c00222_NODE_13..",
  "regions": []
 },
 {
  "length": 3239,
  "seq_id": "c00223_NODE_14..",
  "regions": []
 },
 {
  "length": 3162,
  "seq_id": "c00224_NODE_14..",
  "regions": []
 },
 {
  "length": 3161,
  "seq_id": "c00225_NODE_14..",
  "regions": []
 },
 {
  "length": 3154,
  "seq_id": "c00226_NODE_14..",
  "regions": []
 },
 {
  "length": 3137,
  "seq_id": "c00227_NODE_14..",
  "regions": []
 },
 {
  "length": 3136,
  "seq_id": "c00228_NODE_14..",
  "regions": []
 },
 {
  "length": 3129,
  "seq_id": "c00229_NODE_14..",
  "regions": []
 },
 {
  "length": 3093,
  "seq_id": "c00230_NODE_14..",
  "regions": []
 },
 {
  "length": 3086,
  "seq_id": "c00231_NODE_14..",
  "regions": []
 },
 {
  "length": 3082,
  "seq_id": "c00232_NODE_14..",
  "regions": []
 },
 {
  "length": 3049,
  "seq_id": "c00233_NODE_15..",
  "regions": []
 },
 {
  "length": 3040,
  "seq_id": "c00234_NODE_15..",
  "regions": []
 },
 {
  "length": 2997,
  "seq_id": "c00235_NODE_15..",
  "regions": []
 },
 {
  "length": 2991,
  "seq_id": "c00236_NODE_15..",
  "regions": []
 },
 {
  "length": 2990,
  "seq_id": "c00237_NODE_15..",
  "regions": []
 },
 {
  "length": 2982,
  "seq_id": "c00238_NODE_15..",
  "regions": []
 },
 {
  "length": 2982,
  "seq_id": "c00239_NODE_15..",
  "regions": []
 },
 {
  "length": 2923,
  "seq_id": "c00240_NODE_15..",
  "regions": []
 },
 {
  "length": 2916,
  "seq_id": "c00241_NODE_15..",
  "regions": []
 },
 {
  "length": 2885,
  "seq_id": "c00242_NODE_15..",
  "regions": []
 },
 {
  "length": 2848,
  "seq_id": "c00243_NODE_16..",
  "regions": []
 },
 {
  "length": 2840,
  "seq_id": "c00244_NODE_16..",
  "regions": []
 },
 {
  "length": 2802,
  "seq_id": "c00245_NODE_16..",
  "regions": []
 },
 {
  "length": 2793,
  "seq_id": "c00246_NODE_16..",
  "regions": []
 },
 {
  "length": 2793,
  "seq_id": "c00247_NODE_16..",
  "regions": []
 },
 {
  "length": 2787,
  "seq_id": "c00248_NODE_16..",
  "regions": []
 },
 {
  "length": 2782,
  "seq_id": "c00249_NODE_16..",
  "regions": []
 },
 {
  "length": 2767,
  "seq_id": "c00250_NODE_16..",
  "regions": []
 },
 {
  "length": 2745,
  "seq_id": "c00251_NODE_16..",
  "regions": []
 },
 {
  "length": 2734,
  "seq_id": "c00252_NODE_17..",
  "regions": []
 },
 {
  "length": 2665,
  "seq_id": "c00253_NODE_17..",
  "regions": []
 },
 {
  "length": 2651,
  "seq_id": "c00254_NODE_17..",
  "regions": []
 },
 {
  "length": 2632,
  "seq_id": "c00255_NODE_17..",
  "regions": []
 },
 {
  "length": 2627,
  "seq_id": "c00256_NODE_17..",
  "regions": []
 },
 {
  "length": 2623,
  "seq_id": "c00257_NODE_17..",
  "regions": []
 },
 {
  "length": 2612,
  "seq_id": "c00258_NODE_17..",
  "regions": []
 },
 {
  "length": 2586,
  "seq_id": "c00259_NODE_18..",
  "regions": []
 },
 {
  "length": 2559,
  "seq_id": "c00260_NODE_18..",
  "regions": []
 },
 {
  "length": 2531,
  "seq_id": "c00261_NODE_18..",
  "regions": []
 },
 {
  "length": 2517,
  "seq_id": "c00262_NODE_18..",
  "regions": []
 },
 {
  "length": 2492,
  "seq_id": "c00263_NODE_18..",
  "regions": []
 },
 {
  "length": 2483,
  "seq_id": "c00264_NODE_18..",
  "regions": []
 },
 {
  "length": 2455,
  "seq_id": "c00265_NODE_19..",
  "regions": []
 },
 {
  "length": 2450,
  "seq_id": "c00266_NODE_19..",
  "regions": []
 },
 {
  "length": 2427,
  "seq_id": "c00267_NODE_19..",
  "regions": []
 },
 {
  "length": 2410,
  "seq_id": "c00268_NODE_19..",
  "regions": []
 },
 {
  "length": 2382,
  "seq_id": "c00269_NODE_19..",
  "regions": []
 },
 {
  "length": 2351,
  "seq_id": "c00270_NODE_20..",
  "regions": []
 },
 {
  "length": 2326,
  "seq_id": "c00271_NODE_20..",
  "regions": []
 },
 {
  "length": 2303,
  "seq_id": "c00272_NODE_20..",
  "regions": []
 },
 {
  "length": 2269,
  "seq_id": "c00273_NODE_20..",
  "regions": []
 },
 {
  "length": 2225,
  "seq_id": "c00274_NODE_21..",
  "regions": []
 },
 {
  "length": 2200,
  "seq_id": "c00275_NODE_21..",
  "regions": []
 },
 {
  "length": 2148,
  "seq_id": "c00276_NODE_22..",
  "regions": []
 },
 {
  "length": 2130,
  "seq_id": "c00277_NODE_22..",
  "regions": []
 },
 {
  "length": 2124,
  "seq_id": "c00278_NODE_22..",
  "regions": []
 },
 {
  "length": 2118,
  "seq_id": "c00279_NODE_22..",
  "regions": []
 },
 {
  "length": 2110,
  "seq_id": "c00280_NODE_22..",
  "regions": []
 },
 {
  "length": 2107,
  "seq_id": "c00281_NODE_22..",
  "regions": []
 },
 {
  "length": 2106,
  "seq_id": "c00282_NODE_22..",
  "regions": []
 },
 {
  "length": 2106,
  "seq_id": "c00283_NODE_22..",
  "regions": []
 },
 {
  "length": 2077,
  "seq_id": "c00284_NODE_23..",
  "regions": []
 },
 {
  "length": 2075,
  "seq_id": "c00285_NODE_23..",
  "regions": []
 },
 {
  "length": 2075,
  "seq_id": "c00286_NODE_23..",
  "regions": []
 },
 {
  "length": 2042,
  "seq_id": "c00287_NODE_23..",
  "regions": []
 },
 {
  "length": 2028,
  "seq_id": "c00288_NODE_23..",
  "regions": []
 },
 {
  "length": 2000,
  "seq_id": "c00289_NODE_24..",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r87c1",
  "r148c1"
 ],
 "r87c1": {
  "start": 1,
  "end": 8393,
  "idx": 1,
  "orfs": [
   {
    "start": 3,
    "end": 866,
    "strand": 1,
    "locus_tag": "ctg87_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 866,\n (total: 864 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MINTSPLMQSEKSSLLLAAVPIMTFVCLIMVYPLNIDKRIFTSVCIIAITLNVVTFSVNEFMLAKNRRIRILEKENYQNRVELEEYKTIGEKYEHSRIMNHDFREHLNVLKTLISEDIQKAQEYVGKIEKECEDSKIEKYSDNNILNILLIRKKKECEENGIKLNITSTNPKLDFIDGMDTVAIFSNLINNAIEACSSSARKDIFIDLYTVNNAFSVIKVENYADKEPIVVEGMLRSGKDDGNSHGIGIKSINNSLSKYDGKMSWSYDKAKGMFRTVISINNSQINI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MINTSPLMQSEKSSLLLAAVPIMTFVCLIMVYPLNIDKRIFTSVCIIAITLNVVTFSVNEFMLAKNRRIRILEKENYQNRVELEEYKTIGEKYEHSRIMNHDFREHLNVLKTLISEDIQKAQEYVGKIEKECEDSKIEKYSDNNILNILLIRKKKECEENGIKLNITSTNPKLDFIDGMDTVAIFSNLINNAIEACSSSARKDIFIDLYTVNNAFSVIKVENYADKEPIVVEGMLRSGKDDGNSHGIGIKSINNSLSKYDGKMSWSYDKAKGMFRTVISINNSQINI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATCAATACTTCTCCTTTGATGCAATCAGAAAAATCTTCTCTGTTGTTAGCTGCAGTTCCTATAATGACTTTTGTGTGTTTAATTATGGTTTATCCGCTGAATATTGACAAGCGTATATTTACTTCGGTTTGTATTATCGCAATAACCTTAAATGTTGTTACTTTTTCGGTAAACGAATTTATGCTTGCGAAAAACAGAAGGATAAGAATACTCGAGAAAGAAAATTATCAAAATCGTGTTGAATTAGAGGAATATAAAACCATAGGTGAAAAGTATGAACATAGCAGAATAATGAATCATGATTTCAGAGAACATCTAAATGTTTTGAAAACTTTAATTTCGGAAGATATCCAAAAAGCTCAAGAATATGTGGGAAAGATTGAAAAAGAGTGTGAGGATTCAAAAATAGAAAAATACAGTGACAATAATATTCTTAATATATTACTTATTCGCAAGAAAAAAGAATGTGAAGAAAACGGGATTAAGCTAAACATAACTTCAACCAATCCGAAACTTGATTTTATCGACGGAATGGACACTGTTGCTATATTTTCTAATTTGATTAACAATGCAATAGAGGCTTGCTCAAGCTCGGCAAGAAAAGATATATTTATTGATTTATACACAGTTAATAACGCATTTAGTGTTATTAAAGTTGAAAATTATGCCGATAAAGAGCCGATAGTTGTAGAAGGTATGCTTAGAAGCGGAAAAGATGACGGTAATTCTCACGGAATCGGTATTAAGAGTATAAATAATTCATTAAGCAAATATGATGGGAAAATGAGTTGGTCGTATGACAAAGCTAAAGGGATGTTTAGAACCGTTATTTCTATAAATAATTCACAAATTAACATTTGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 954,
    "end": 1109,
    "strand": 1,
    "locus_tag": "ctg87_2",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 954 - 1,109,\n (total: 156 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) cyclic-lactone-autoinducer: TIGR04223<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKKFLNKVVPTLIKFVPVCAALMLVINSNSTSTIVNGQPEAPKGLKKYRKF&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKKFLNKVVPTLIKFVPVCAALMLVINSNSTSTIVNGQPEAPKGLKKYRKF\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAAAGTTCCTAAACAAAGTAGTTCCAACATTAATCAAGTTTGTACCTGTTTGTGCAGCGTTGATGCTTGTGATTAACAGTAATTCAACATCAACCATTGTAAACGGTCAACCTGAAGCACCAAAAGGACTTAAGAAGTATCGTAAGTTCTGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 1112,
    "end": 1708,
    "strand": 1,
    "locus_tag": "ctg87_3",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,112 - 1,708,\n (total: 597 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) cyclic-lactone-autoinducer: AgrB<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MFRKFSEWAVAYAIRLGYIKEEEQEEYTYGLDLVMSVIASDLTMLIIGIIMKMIPQVIVFVFMYKFIRKYTGGFHCETALTCYLSSSTMCICVLLAIKYLPYNLGVYIVATVLSIGVLFAISPIEAINKPLEEIEVKVFGKRARIVLCITLVIFGVICAFGLTEMVKTMAISVVDILLFAVMGKIKLLNYKRKKIEQN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MFRKFSEWAVAYAIRLGYIKEEEQEEYTYGLDLVMSVIASDLTMLIIGIIMKMIPQVIVFVFMYKFIRKYTGGFHCETALTCYLSSSTMCICVLLAIKYLPYNLGVYIVATVLSIGVLFAISPIEAINKPLEEIEVKVFGKRARIVLCITLVIFGVICAFGLTEMVKTMAISVVDILLFAVMGKIKLLNYKRKKIEQN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTTTCGTAAATTTTCGGAATGGGCTGTGGCATATGCCATAAGATTAGGTTACATAAAAGAAGAGGAGCAGGAAGAATATACTTACGGACTTGACCTTGTAATGAGCGTTATTGCAAGTGATTTGACAATGCTTATAATAGGTATAATAATGAAAATGATACCGCAGGTGATTGTTTTTGTATTTATGTACAAGTTCATTCGCAAGTATACGGGCGGATTTCATTGCGAAACAGCCTTGACGTGCTATCTGTCGTCAAGCACGATGTGTATATGCGTTTTGCTTGCTATTAAATATCTTCCGTATAACCTTGGCGTATACATAGTCGCAACCGTTTTATCTATTGGGGTACTCTTTGCAATTTCGCCAATCGAGGCTATAAACAAACCTTTGGAAGAAATTGAAGTTAAAGTTTTCGGAAAAAGGGCGAGAATTGTACTTTGTATTACACTTGTAATATTTGGTGTAATTTGTGCGTTTGGTTTGACGGAAATGGTAAAAACAATGGCAATAAGCGTCGTTGATATTTTGCTTTTTGCGGTTATGGGTAAGATAAAATTGTTGAACTACAAAAGGAAAAAAATTGAACAGAATTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 2022,
    "end": 2576,
    "strand": 1,
    "locus_tag": "ctg87_4",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,022 - 2,576,\n (total: 555 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSYIRNVELSDAEVLVEIYRPYVENTTISFECETPSVDEFRSRIENISKKYPYIVMVEDDEIVGYAYAGRFKGRKAYDWCVETTIYVREDKKGGGYGKKLYLELEKRLKKQNILNMYACIAYTDNEDEHLTNNSMQFHGHMGFRLIGTFKKCGYKFDKWYDMIWMEKFIGEHKVNPDAVTRPEI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSYIRNVELSDAEVLVEIYRPYVENTTISFECETPSVDEFRSRIENISKKYPYIVMVEDDEIVGYAYAGRFKGRKAYDWCVETTIYVREDKKGGGYGKKLYLELEKRLKKQNILNMYACIAYTDNEDEHLTNNSMQFHGHMGFRLIGTFKKCGYKFDKWYDMIWMEKFIGEHKVNPDAVTRPEI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGTTATATAAGAAATGTTGAATTATCCGACGCGGAAGTGTTGGTTGAAATATACCGTCCGTATGTCGAAAACACAACAATATCATTTGAATGTGAAACGCCGTCTGTAGACGAGTTTAGAAGTCGTATTGAAAATATTTCAAAAAAGTATCCTTACATTGTTATGGTGGAAGACGATGAAATTGTCGGTTATGCATATGCGGGAAGATTTAAAGGACGTAAAGCGTATGATTGGTGCGTTGAAACGACTATATATGTAAGAGAGGACAAAAAAGGCGGCGGATACGGTAAAAAGTTGTATCTTGAACTTGAAAAAAGATTGAAGAAACAAAACATTCTTAATATGTATGCTTGTATTGCGTATACGGACAATGAAGATGAGCATTTGACAAACAACAGTATGCAGTTCCACGGGCATATGGGGTTTAGGCTTATCGGTACATTTAAAAAGTGCGGTTACAAGTTCGACAAGTGGTATGATATGATTTGGATGGAGAAATTTATCGGTGAACATAAGGTTAATCCCGACGCGGTGACAAGACCGGAAATTTAG\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 2647,
    "end": 3573,
    "strand": 1,
    "locus_tag": "ctg87_5",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,647 - 3,573,\n (total: 927 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MANKVEDLVNVILDSYNECDITARIDEENMLNKDILIEIIDEIRKVLFPGFFDNNKVRSEYLKFLVGERLEFIQYHLKKQVSNAFANQDVCRECSKAQAEEKAEEVVFEFLKKIPKIREYLNTDIQAAYDGDPAAYSTDEIIFCYPGVFAITVYRIAHELWLLGVPMIPRIMTEYAHSTTGIDIHPGATVGKYFFIDHGTGIVIGETTEIGDNVKIYQGVTLGALSTRKGQQLKGVKRHPTISDNVTIYSGTTILGGETVVGKGTTIGGNAFIVNSVSEGMKVSVKNPELEYSVGNASMKDGYWDWCI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MANKVEDLVNVILDSYNECDITARIDEENMLNKDILIEIIDEIRKVLFPGFFDNNKVRSEYLKFLVGERLEFIQYHLKKQVSNAFANQDVCRECSKAQAEEKAEEVVFEFLKKIPKIREYLNTDIQAAYDGDPAAYSTDEIIFCYPGVFAITVYRIAHELWLLGVPMIPRIMTEYAHSTTGIDIHPGATVGKYFFIDHGTGIVIGETTEIGDNVKIYQGVTLGALSTRKGQQLKGVKRHPTISDNVTIYSGTTILGGETVVGKGTTIGGNAFIVNSVSEGMKVSVKNPELEYSVGNASMKDGYWDWCI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCGAATAAAGTAGAAGATTTAGTCAATGTGATTTTAGACAGCTACAATGAATGTGACATTACAGCGAGAATTGACGAAGAGAATATGCTTAACAAGGATATTCTTATAGAAATTATAGATGAAATAAGAAAAGTGCTTTTTCCGGGCTTTTTTGACAACAACAAGGTCAGAAGTGAATACTTAAAGTTTCTTGTCGGTGAAAGACTGGAATTTATACAGTATCATTTGAAGAAACAGGTGTCAAACGCGTTTGCAAATCAAGATGTATGCAGAGAGTGCAGTAAGGCACAGGCAGAGGAAAAAGCGGAAGAAGTTGTTTTTGAATTTTTAAAGAAAATACCGAAAATAAGAGAATACTTAAATACAGACATTCAAGCTGCGTATGACGGTGACCCTGCGGCATACAGCACAGATGAAATAATTTTCTGTTATCCGGGAGTGTTTGCAATCACTGTTTACAGAATTGCTCACGAATTGTGGCTTTTGGGCGTGCCTATGATTCCGAGAATAATGACGGAATATGCTCACAGCACAACAGGTATAGATATTCACCCGGGTGCGACTGTCGGCAAATATTTCTTTATAGACCACGGTACAGGTATTGTTATAGGTGAAACTACCGAAATCGGCGATAATGTAAAAATATATCAAGGCGTTACTTTAGGCGCACTTTCGACAAGAAAAGGTCAGCAGTTAAAGGGCGTTAAACGTCATCCGACTATCAGTGACAACGTTACGATATATTCGGGTACGACTATTCTCGGCGGTGAAACGGTTGTCGGTAAGGGTACGACTATCGGCGGTAATGCGTTTATCGTTAATTCCGTTTCGGAGGGTATGAAAGTCAGCGTGAAAAATCCCGAACTTGAGTACAGTGTCGGAAATGCGTCTATGAAGGACGGTTATTGGGATTGGTGTATATAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 4112,
    "end": 5401,
    "strand": 1,
    "locus_tag": "ctg87_6",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,112 - 5,401,\n (total: 1290 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) DegT_DnrJ_EryC1<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSNKNWRFETKQLHVGQEQADPVTDSRAVPIYASTSFVFHNSQHAADRFGLRDAGNIYGRLTNPTEDIFEQRIAALEGGVAALAVASGAAALAYTFQTLAKQGDHIVAAKTIYGGTYNYLEHTFPEFGVTTTFVDPEVDGAFEAAIQDNTKAIFIETLGNPNSNLIDIEEIAKIAHAHNIPLVVDSTFATPYLVRPIEYGADIVVHSATKFIGGHGTAIGGVIVDSGNFDWAKSGKFPHLVEPNASYHGISFANDVGAAAFVTYIRAILLRDTGATLSPFHAFIFLQGLETLSLRVERHVENALKIVDYLNKHPKVEAVHHPSLPTEPSHELYKKYLPNGGGSIFTFEIKGGVEEAHKFIDNLEIFSLLANVADSKSLVIHPATTTHSQCNEQELAEQGIKPNTIRLSIGTENIDDLIAALDDAFNAVD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSNKNWRFETKQLHVGQEQADPVTDSRAVPIYASTSFVFHNSQHAADRFGLRDAGNIYGRLTNPTEDIFEQRIAALEGGVAALAVASGAAALAYTFQTLAKQGDHIVAAKTIYGGTYNYLEHTFPEFGVTTTFVDPEVDGAFEAAIQDNTKAIFIETLGNPNSNLIDIEEIAKIAHAHNIPLVVDSTFATPYLVRPIEYGADIVVHSATKFIGGHGTAIGGVIVDSGNFDWAKSGKFPHLVEPNASYHGISFANDVGAAAFVTYIRAILLRDTGATLSPFHAFIFLQGLETLSLRVERHVENALKIVDYLNKHPKVEAVHHPSLPTEPSHELYKKYLPNGGGSIFTFEIKGGVEEAHKFIDNLEIFSLLANVADSKSLVIHPATTTHSQCNEQELAEQGIKPNTIRLSIGTENIDDLIAALDDAFNAVD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCAAATAAGAATTGGAGATTTGAAACAAAGCAATTACACGTTGGTCAGGAACAAGCAGATCCTGTTACAGATTCAAGAGCTGTTCCGATTTATGCATCAACATCATTCGTATTCCACAACTCACAGCACGCAGCTGACCGTTTCGGTTTGAGAGATGCAGGTAACATCTACGGCAGACTTACAAACCCTACAGAAGATATTTTTGAACAGAGAATAGCAGCCCTTGAAGGCGGTGTTGCTGCATTGGCAGTTGCATCGGGTGCGGCAGCTCTTGCTTATACATTCCAAACACTTGCTAAGCAAGGCGATCACATCGTAGCCGCAAAGACAATTTACGGCGGAACATACAACTATCTTGAACATACATTCCCTGAATTCGGTGTTACAACAACATTCGTTGACCCTGAAGTTGACGGTGCATTTGAAGCAGCTATTCAGGATAACACAAAGGCAATCTTCATTGAAACACTTGGTAACCCAAATTCAAACCTAATTGATATTGAAGAAATTGCAAAGATTGCTCACGCACATAACATTCCGCTTGTAGTTGACTCAACATTCGCTACACCTTATCTTGTAAGACCAATCGAATACGGTGCAGACATCGTTGTTCACAGTGCAACTAAGTTTATCGGGGGTCACGGTACTGCAATCGGCGGTGTAATCGTTGACAGCGGTAACTTTGACTGGGCTAAGTCGGGTAAGTTCCCTCACCTTGTAGAGCCTAACGCATCATATCACGGTATCAGCTTTGCAAATGATGTAGGAGCTGCCGCATTTGTAACATATATCAGAGCTATCCTGCTTCGTGACACAGGTGCTACACTTTCACCGTTCCACGCATTCATCTTCTTACAGGGTCTTGAAACTCTATCACTAAGAGTTGAACGTCACGTTGAAAACGCTCTAAAGATTGTTGATTACCTAAACAAGCATCCAAAGGTAGAGGCTGTTCATCATCCGTCACTACCTACAGAGCCAAGCCACGAACTATACAAGAAGTATCTTCCAAACGGCGGCGGAAGTATCTTTACATTTGAAATCAAGGGCGGAGTTGAAGAGGCTCACAAGTTTATCGATAACCTTGAAATTTTCTCGCTTCTTGCAAATGTTGCAGACTCTAAGTCACTTGTAATTCACCCGGCTACAACTACTCATTCACAGTGCAATGAACAGGAACTTGCAGAACAGGGTATTAAGCCAAATACAATAAGACTATCAATCGGTACAGAAAATATTGATGACCTTATTGCAGCTCTTGACGACGCATTCAACGCCGTTGACTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 5444,
    "end": 6376,
    "strand": 1,
    "locus_tag": "ctg87_7",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,444 - 6,376,\n (total: 933 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSKIYQKITDLIGGTPLLELANYEKKNNLEATVLGKLEYFNPAGSVKDRIAKAMVDEAEQEGKLKEGSVIIEPTSGNTGIGLASVAAARGYKIIITMPETMSIERRNLLKAYGAELVLTDGAKGMKGAIEKAKELAETTENSFIPSQFTNPANPAYHRATTGPEIWADTDGKVDIFVAGVGTGGTVTGVGQYLKSQNPDVKVVAVEPAGSPVLSQGKAGAHKIQGIGAGFVPETLDTKVYDEIITVENEDAFKTGRDIARSEGVLVGISSGAAVWAATELAKRPENKGKTIVALLPDTGERYLSTPMFAE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSKIYQKITDLIGGTPLLELANYEKKNNLEATVLGKLEYFNPAGSVKDRIAKAMVDEAEQEGKLKEGSVIIEPTSGNTGIGLASVAAARGYKIIITMPETMSIERRNLLKAYGAELVLTDGAKGMKGAIEKAKELAETTENSFIPSQFTNPANPAYHRATTGPEIWADTDGKVDIFVAGVGTGGTVTGVGQYLKSQNPDVKVVAVEPAGSPVLSQGKAGAHKIQGIGAGFVPETLDTKVYDEIITVENEDAFKTGRDIARSEGVLVGISSGAAVWAATELAKRPENKGKTIVALLPDTGERYLSTPMFAE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCAAAGATATATCAGAAAATTACAGATCTTATCGGTGGTACACCGCTATTGGAACTTGCAAACTATGAAAAGAAGAATAACCTTGAAGCAACAGTTCTTGGTAAGCTTGAATACTTTAACCCTGCCGGTTCGGTAAAAGACAGAATCGCAAAGGCAATGGTTGATGAGGCTGAACAAGAGGGTAAGTTAAAGGAAGGTTCTGTTATCATCGAGCCAACATCAGGTAATACAGGTATCGGTCTTGCGTCGGTTGCCGCCGCAAGAGGTTATAAAATTATAATCACAATGCCTGAAACAATGAGTATTGAAAGACGTAATCTATTAAAAGCATATGGCGCCGAACTTGTTTTGACAGACGGTGCAAAGGGTATGAAAGGTGCTATCGAAAAGGCTAAGGAACTTGCTGAAACAACAGAAAACAGCTTTATCCCAAGCCAGTTCACAAACCCTGCAAACCCTGCTTATCACAGAGCAACAACAGGCCCTGAAATCTGGGCAGATACAGACGGTAAAGTTGATATATTTGTTGCCGGCGTAGGTACAGGCGGTACAGTTACCGGTGTAGGTCAGTATCTAAAGTCACAAAACCCTGACGTTAAGGTTGTTGCAGTTGAGCCTGCAGGCTCACCGGTATTGTCACAAGGCAAAGCAGGTGCGCACAAAATTCAAGGTATCGGTGCAGGTTTCGTTCCTGAAACTCTTGATACAAAGGTTTATGACGAAATCATTACTGTTGAAAACGAGGACGCATTCAAGACAGGCAGAGATATTGCCCGCAGTGAAGGTGTACTTGTAGGTATTTCATCAGGTGCGGCTGTTTGGGCGGCTACAGAGCTTGCCAAACGCCCTGAAAACAAGGGTAAAACAATCGTAGCTCTTTTGCCTGATACAGGTGAAAGATATTTGTCAACTCCTATGTTTGCTGAATAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 6415,
    "end": 6654,
    "strand": 1,
    "locus_tag": "ctg87_8",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,415 - 6,654,\n (total: 240 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKMPSFCVRFFGHCSCYNIIIIKLNCQSEVGVLRVKNEKFSKITLTKTEVNIMVIVGTILISVGASILFVLKVNSVKDI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKMPSFCVRFFGHCSCYNIIIIKLNCQSEVGVLRVKNEKFSKITLTKTEVNIMVIVGTILISVGASILFVLKVNSVKDI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAATGCCATCTTTTTGTGTACGGTTTTTTGGACATTGTAGTTGTTATAATATAATCATAATAAAGCTAAATTGTCAAAGTGAAGTTGGGGTTTTGAGGGTAAAAAACGAGAAATTTTCTAAGATCACCTTGACAAAAACGGAGGTAAATATTATGGTTATAGTGGGAACAATACTTATAAGTGTAGGAGCGTCAATACTTTTTGTATTAAAGGTTAATTCGGTAAAGGATATATAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 6695,
    "end": 7453,
    "strand": 1,
    "locus_tag": "ctg87_9",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,695 - 7,453,\n (total: 759 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MQINELVTFAADVGRGLLESGAETSRVEDTVERIIRHFYDGKSEVLVVMTGLFVTVGDVTKTVRVRRRTINLDKVSKINMMSRDIADDKIDFEEALKRFEYIMAQKPYSLWVKTVAVAFCCGFFTLLFGGNAFDGLNSLVVGAVINVFIWFLRKRHTAEFIITFSGGVVIALLILLFYAIGLGKNINPMITGAIMPLVPGLAITNAIRDIIAGDYLSGGARLFDAVVVAIALATGAGSVMYIFGHMTGGVMG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MQINELVTFAADVGRGLLESGAETSRVEDTVERIIRHFYDGKSEVLVVMTGLFVTVGDVTKTVRVRRRTINLDKVSKINMMSRDIADDKIDFEEALKRFEYIMAQKPYSLWVKTVAVAFCCGFFTLLFGGNAFDGLNSLVVGAVINVFIWFLRKRHTAEFIITFSGGVVIALLILLFYAIGLGKNINPMITGAIMPLVPGLAITNAIRDIIAGDYLSGGARLFDAVVVAIALATGAGSVMYIFGHMTGGVMG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCAGATAAATGAACTTGTGACATTTGCGGCGGATGTCGGCAGAGGTTTGCTTGAAAGCGGTGCGGAAACGAGTCGTGTCGAAGATACGGTTGAGAGGATAATACGGCACTTTTATGACGGTAAAAGTGAGGTTTTGGTCGTAATGACAGGACTGTTTGTCACTGTCGGCGATGTTACAAAAACGGTCAGAGTTCGCAGACGGACTATAAACCTTGATAAAGTATCGAAAATTAATATGATGTCACGAGATATTGCTGATGATAAAATCGACTTTGAAGAAGCTTTAAAACGCTTTGAATATATAATGGCACAGAAACCTTATTCGTTATGGGTGAAAACTGTTGCGGTAGCGTTTTGCTGTGGATTTTTTACGTTGTTGTTTGGCGGTAATGCGTTTGACGGACTTAATTCGCTTGTGGTCGGCGCGGTTATCAATGTTTTTATATGGTTTTTGAGAAAACGTCACACGGCGGAGTTTATTATAACATTTTCAGGCGGAGTTGTTATTGCGTTGCTGATATTACTTTTTTATGCAATAGGTTTGGGAAAAAATATTAATCCTATGATAACGGGAGCTATTATGCCGCTTGTACCAGGTTTGGCAATAACTAATGCAATTCGTGATATTATTGCCGGAGATTACCTTTCGGGCGGTGCGAGATTGTTTGATGCGGTAGTCGTGGCGATTGCACTTGCCACAGGTGCGGGCAGTGTTATGTACATTTTCGGTCATATGACGGGAGGTGTTATGGGATGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 7450,
    "end": 7878,
    "strand": 1,
    "locus_tag": "ctg87_10",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,450 - 7,878,\n (total: 429 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIFLEMFVAFAATMAFAVTFNVSRSELIFCGIAGLVAEGVYLFTLRISDETALAIFVASIAVTVLSRILANVRRMPVTVYLISGIISLVPGAGMYNTVYNIISSDYIKAIYTGVDTIKVAVAIAVGIVLVFALPNKMFFKRK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIFLEMFVAFAATMAFAVTFNVSRSELIFCGIAGLVAEGVYLFTLRISDETALAIFVASIAVTVLSRILANVRRMPVTVYLISGIISLVPGAGMYNTVYNIISSDYIKAIYTGVDTIKVAVAIAVGIVLVFALPNKMFFKRK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATTTTTCTTGAAATGTTTGTCGCTTTTGCGGCGACAATGGCTTTTGCAGTGACATTTAACGTGAGCCGAAGTGAATTGATATTTTGCGGAATCGCAGGTTTAGTCGCAGAGGGGGTGTATTTGTTTACACTTAGAATAAGCGACGAAACGGCACTTGCTATATTTGTTGCGTCGATTGCCGTGACGGTATTGTCGCGAATTTTGGCGAATGTAAGACGTATGCCCGTTACGGTTTATTTGATTTCGGGAATAATATCGCTTGTACCCGGTGCGGGTATGTATAACACTGTTTATAACATAATATCGTCGGACTATATAAAAGCAATATACACAGGCGTTGATACAATAAAAGTTGCCGTAGCGATTGCGGTGGGGATTGTACTTGTGTTTGCATTGCCTAATAAAATGTTTTTCAAGAGAAAATAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 8077,
    "end": 8391,
    "strand": 1,
    "locus_tag": "ctg87_11",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg87_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg87_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,077 - 8,391,\n (total: 315 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKKIIAVMAVLITLFSMGNVSASAAAKVAALMYHSVTTDSSRWNDYTISPEQLDADIQYFKSCGYIPMTATELATANMADIDNRKILLLTFDDGYSNFYTEVFPI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00087_NODE_50..&amp;from=0&amp;to=8393\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKKIIAVMAVLITLFSMGNVSASAAAKVAALMYHSVTTDSSRWNDYTISPEQLDADIQYFKSCGYIPMTATELATANMADIDNRKILLLTFDDGYSNFYTEVFPI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAAAGATAATTGCCGTTATGGCGGTGCTTATAACGCTTTTTTCAATGGGTAATGTGTCGGCAAGTGCGGCGGCAAAGGTTGCGGCACTGATGTATCACAGTGTGACAACTGATTCGTCACGTTGGAATGACTATACAATATCACCCGAACAGCTTGACGCAGATATACAATACTTTAAAAGCTGCGGATATATACCGATGACTGCGACAGAACTCGCAACGGCGAATATGGCTGATATTGACAACAGAAAAATATTGCTTTTGACATTTGATGACGGATACTCAAACTTCTATACGGAGGTATTTCCGATA\">Copy to clipboard</span><br>\n</div>"
   }
  ],
  "clusters": [
   {
    "start": 953,
    "end": 1708,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 8393,
    "product": "cyclic-lactone-autoinducer",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "ttaCodons": [],
  "type": "cyclic-lactone-autoinducer",
  "products": [
   "cyclic-lactone-autoinducer"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP cyclic-lactone-autoinducer",
  "anchor": "r87c1"
 },
 "r148c1": {
  "start": 1,
  "end": 5446,
  "idx": 1,
  "orfs": [
   {
    "start": 3,
    "end": 479,
    "strand": 1,
    "locus_tag": "ctg148_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 479,\n (total: 477 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=IIMLTGDHEGAAKRTADMLGIDNFRAQVLPEDKATIIEELKNEGRTVIMVGDGINDSPALALSDVSIAMKDSADLAREVADVTLLSGDLRDLALLRKLSSRLFRRIKRNYTFIMAFNSLLILLGLKGTITPSASSLLHNSSTMLISANSMRPLLNDKN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"IIMLTGDHEGAAKRTADMLGIDNFRAQVLPEDKATIIEELKNEGRTVIMVGDGINDSPALALSDVSIAMKDSADLAREVADVTLLSGDLRDLALLRKLSSRLFRRIKRNYTFIMAFNSLLILLGLKGTITPSASSLLHNSSTMLISANSMRPLLNDKN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATTATTATGCTTACAGGTGACCATGAAGGTGCTGCAAAACGCACTGCCGATATGCTCGGTATAGACAATTTCCGTGCACAGGTATTACCTGAGGATAAGGCGACAATTATTGAAGAATTGAAGAACGAGGGAAGAACGGTTATAATGGTCGGTGACGGTATCAATGACTCTCCTGCATTGGCACTTAGCGACGTTTCAATTGCTATGAAAGATTCTGCCGATTTGGCAAGAGAAGTGGCTGATGTCACATTGCTTTCGGGCGATTTGAGAGATTTAGCGCTTCTTCGCAAGTTAAGCAGCAGACTGTTCAGACGAATTAAACGTAATTATACGTTTATTATGGCATTTAATTCATTGCTTATTTTGCTTGGATTGAAAGGTACTATAACTCCGTCTGCATCATCACTTTTGCATAATTCGTCAACTATGCTTATAAGTGCGAACAGTATGCGTCCATTATTGAATGACAAGAATTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 631,
    "end": 1233,
    "strand": 1,
    "locus_tag": "ctg148_2",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 631 - 1,233,\n (total: 603 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VRIEKLNKDKIKVTLTTAELINLDIDVKRLSPDSKELHTFLFHIMETIREETGFNPYNGQVVVEATPSQDGISILVKRLNKGIKKITEEQFKKVVSVKPKKKEPGTECVFYFETFNDMCGAISEMDKSILSKASLFKLNKTYCILIRNDNENMRGINVIREFTERMSIYPLQNEYIKEHALLVAKGQKLVEMAENVKRLM&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VRIEKLNKDKIKVTLTTAELINLDIDVKRLSPDSKELHTFLFHIMETIREETGFNPYNGQVVVEATPSQDGISILVKRLNKGIKKITEEQFKKVVSVKPKKKEPGTECVFYFETFNDMCGAISEMDKSILSKASLFKLNKTYCILIRNDNENMRGINVIREFTERMSIYPLQNEYIKEHALLVAKGQKLVEMAENVKRLM\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGAGAATTGAAAAGCTAAACAAAGACAAAATAAAGGTAACGCTTACAACTGCGGAATTAATTAATCTTGATATAGACGTGAAAAGGCTTTCGCCCGATTCAAAAGAATTACATACATTTTTATTTCATATTATGGAAACGATAAGGGAAGAAACAGGTTTTAATCCGTATAACGGTCAAGTGGTCGTTGAGGCTACTCCGTCACAGGACGGTATAAGTATTTTGGTTAAACGTTTAAACAAGGGTATAAAAAAAATTACCGAGGAGCAGTTTAAAAAAGTTGTTTCGGTCAAGCCTAAAAAGAAAGAACCGGGTACGGAATGTGTATTTTATTTTGAAACTTTTAATGATATGTGCGGCGCTATAAGCGAAATGGATAAAAGTATTCTTTCAAAAGCAAGCCTTTTTAAGCTGAATAAAACATATTGTATTCTCATAAGAAACGATAATGAGAATATGAGAGGCATTAATGTAATAAGAGAGTTTACGGAAAGAATGTCGATATACCCGTTGCAGAATGAGTACATAAAAGAACATGCTCTTCTTGTCGCAAAAGGTCAAAAACTTGTTGAAATGGCTGAAAACGTCAAACGATTGATGTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 1333,
    "end": 1734,
    "strand": 1,
    "locus_tag": "ctg148_3",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,333 - 1,734,\n (total: 402 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MANILETVVFADGETANTQQATGTQTAADPNATQQVNPVMSTIVSILPLVLIIVLLYFMMIRPQRKKEKETKAMINAMKVGDKVVTIGGICGKVAKIKDEYVFIETGNIGTPDQKSVVKMERDAIRTVETAKN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MANILETVVFADGETANTQQATGTQTAADPNATQQVNPVMSTIVSILPLVLIIVLLYFMMIRPQRKKEKETKAMINAMKVGDKVVTIGGICGKVAKIKDEYVFIETGNIGTPDQKSVVKMERDAIRTVETAKN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCAAACATTTTAGAAACAGTCGTTTTCGCAGACGGCGAAACAGCAAATACACAACAGGCGACAGGTACTCAAACAGCGGCAGACCCTAATGCTACACAACAGGTTAATCCTGTAATGAGTACAATAGTAAGTATTCTTCCGCTTGTTCTTATTATCGTATTGTTATACTTTATGATGATAAGACCGCAAAGAAAGAAAGAAAAAGAAACAAAGGCAATGATTAACGCAATGAAAGTCGGCGATAAGGTTGTAACAATCGGCGGTATCTGCGGTAAGGTTGCTAAAATTAAAGACGAATATGTTTTTATTGAAACAGGTAACATCGGTACACCGGATCAAAAGTCTGTTGTAAAGATGGAAAGAGACGCTATCAGAACTGTTGAAACAGCTAAAAACTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 1796,
    "end": 2152,
    "strand": 1,
    "locus_tag": "ctg148_4",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,796 - 2,152,\n (total: 357 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MGINFKGVIKGTIFAILVTFVIILILALLSYFTGIDETIITTGVYASVIIGVILGTIAVSKAANSRAFVHAMLVCALYLIVLIGISLIVNNGIMFNTHFLAVIGGTFASGILGCIIGK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MGINFKGVIKGTIFAILVTFVIILILALLSYFTGIDETIITTGVYASVIIGVILGTIAVSKAANSRAFVHAMLVCALYLIVLIGISLIVNNGIMFNTHFLAVIGGTFASGILGCIIGK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGGTATTAATTTTAAGGGTGTGATAAAAGGGACGATATTTGCAATTCTTGTTACTTTTGTTATAATTCTGATATTGGCACTGCTTTCGTATTTTACAGGCATAGACGAAACTATTATCACAACCGGAGTGTATGCCTCGGTTATTATCGGCGTGATACTCGGAACGATTGCGGTATCAAAAGCGGCAAACAGCAGAGCATTTGTTCACGCAATGCTTGTATGTGCGCTGTATTTGATCGTACTTATCGGAATATCGTTGATTGTAAACAATGGAATAATGTTTAACACGCATTTTCTTGCTGTAATAGGCGGTACATTTGCATCGGGAATATTGGGGTGCATCATAGGAAAATAG\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 2268,
    "end": 2411,
    "strand": 1,
    "locus_tag": "ctg148_5",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,268 - 2,411,\n (total: 144 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR03973<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SCIFF<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKHVQTLNKANLKDSAKHGGCGECQTSCQSACKTSCTVANQKCEQAN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKHVQTLNKANLKDSAKHGGCGECQTSCQSACKTSCTVANQKCEQAN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAACACGTACAGACTTTAAACAAGGCTAATTTAAAGGATTCAGCAAAGCACGGTGGTTGCGGAGAATGTCAAACATCATGTCAATCAGCTTGTAAGACATCTTGCACAGTTGCAAATCAAAAATGTGAACAAGCAAACTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 2500,
    "end": 3870,
    "strand": 1,
    "locus_tag": "ctg148_6",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,500 - 3,870,\n (total: 1371 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SPASM<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VIHKYKQLGLNIVMDVYSGAVHVVDDVMYDMLDYTLEPFMAEAKCPDYIKEGLKDKYSEEELEESYAEICALVNAGQLFTDDCYDEIAKNWNKQSVVKALCIHVAHDCNLRCKYCFADTGEFHGGRSLMSAEVGKKAIDFVINNSGNRKNIEIDYFGGEPLMNFGVVKEITEYAKEEAKKHGKNFRFTVTTNGVLLNDDIKQYINENMSNVVLSIDGTKETNDRMRYRVDGSGSYDTIVPKFQDLAESRNQNNYYVRGTFTAYNVDFAKDVIHLADLGFKQTSVEPVVAPETEDYALTSEHIEKVCAEYDKLTEEYVKRYDEGRGFNFFHFMVDLDQGPCAIKRLSGCGAGHEYLAVAPNGDIYPCHQFVGNKDFLMGNVNENKIDENIEKMFERSNVYTKEKCKNCFAKFYCSGGCSANAYNFNGDINKPYELACEFEKKRLECSIAIEAHKKLS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VIHKYKQLGLNIVMDVYSGAVHVVDDVMYDMLDYTLEPFMAEAKCPDYIKEGLKDKYSEEELEESYAEICALVNAGQLFTDDCYDEIAKNWNKQSVVKALCIHVAHDCNLRCKYCFADTGEFHGGRSLMSAEVGKKAIDFVINNSGNRKNIEIDYFGGEPLMNFGVVKEITEYAKEEAKKHGKNFRFTVTTNGVLLNDDIKQYINENMSNVVLSIDGTKETNDRMRYRVDGSGSYDTIVPKFQDLAESRNQNNYYVRGTFTAYNVDFAKDVIHLADLGFKQTSVEPVVAPETEDYALTSEHIEKVCAEYDKLTEEYVKRYDEGRGFNFFHFMVDLDQGPCAIKRLSGCGAGHEYLAVAPNGDIYPCHQFVGNKDFLMGNVNENKIDENIEKMFERSNVYTKEKCKNCFAKFYCSGGCSANAYNFNGDINKPYELACEFEKKRLECSIAIEAHKKLS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGATACATAAGTATAAACAGTTGGGACTTAATATTGTAATGGATGTATATTCAGGTGCGGTACACGTTGTTGATGATGTAATGTACGATATGCTTGATTATACTCTTGAGCCGTTTATGGCAGAGGCAAAATGTCCCGATTATATTAAAGAAGGTTTAAAAGATAAGTATAGTGAAGAAGAATTGGAAGAAAGCTATGCTGAAATATGTGCACTTGTAAATGCAGGTCAGTTGTTTACAGATGATTGCTATGACGAAATCGCGAAGAATTGGAATAAGCAATCTGTTGTAAAGGCTCTTTGTATTCACGTTGCACATGACTGTAATTTGAGATGTAAGTATTGTTTTGCCGATACAGGTGAATTTCACGGTGGCAGAAGTCTTATGAGTGCGGAAGTAGGTAAGAAAGCTATTGATTTTGTTATCAATAACAGCGGTAACAGAAAAAATATAGAAATCGACTACTTCGGCGGTGAACCACTTATGAATTTCGGCGTTGTTAAGGAAATTACAGAATACGCAAAAGAAGAGGCGAAAAAGCACGGTAAGAATTTCAGATTTACTGTAACAACAAACGGTGTATTGTTAAATGACGATATTAAACAATATATTAATGAAAATATGTCAAACGTTGTTTTGAGTATTGACGGTACAAAGGAAACTAACGACAGAATGCGTTATCGTGTAGATGGCAGCGGTTCTTACGATACAATCGTTCCTAAGTTCCAAGACTTGGCTGAAAGCAGAAATCAAAATAATTACTACGTTCGCGGTACGTTTACGGCGTATAACGTGGATTTTGCAAAGGACGTAATTCACCTTGCGGATTTAGGCTTTAAGCAGACAAGCGTTGAACCGGTTGTTGCACCTGAAACAGAGGACTACGCACTTACAAGTGAGCATATCGAAAAGGTCTGTGCCGAATATGATAAGCTTACTGAAGAATATGTAAAGAGATATGACGAGGGCAGAGGTTTTAACTTCTTCCACTTTATGGTTGACCTTGACCAAGGTCCGTGTGCGATAAAGCGTCTTTCAGGTTGTGGTGCAGGACACGAATATCTTGCGGTTGCACCGAACGGAGACATTTATCCGTGTCACCAATTTGTCGGTAACAAGGATTTTCTTATGGGTAATGTCAATGAAAATAAAATTGATGAAAATATCGAGAAGATGTTTGAACGCTCAAATGTGTATACTAAAGAAAAATGTAAGAATTGTTTTGCAAAATTCTATTGCAGCGGTGGTTGCAGTGCGAATGCGTATAACTTTAACGGTGATATAAACAAGCCTTATGAGCTTGCTTGTGAATTTGAAAAAAAGCGTCTTGAATGTTCAATAGCAATCGAGGCACATAAAAAATTAAGTTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 3889,
    "end": 4203,
    "strand": 1,
    "locus_tag": "ctg148_7",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,889 - 4,203,\n (total: 315 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIHKGFKMKLYDGMAEEYEKRHNELWPEMKDMIHEHGGKNYSIFLDKETMVLYGYIEIEDEELWAKGADTAINRKWWDFMADIMETNPDNSPVSEDLHLVFHLD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIHKGFKMKLYDGMAEEYEKRHNELWPEMKDMIHEHGGKNYSIFLDKETMVLYGYIEIEDEELWAKGADTAINRKWWDFMADIMETNPDNSPVSEDLHLVFHLD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATACACAAGGGTTTTAAAATGAAACTTTACGACGGTATGGCTGAGGAGTACGAAAAAAGACATAATGAGTTATGGCCGGAAATGAAGGATATGATTCACGAACACGGCGGTAAGAATTATTCAATATTCCTTGACAAAGAAACAATGGTTCTTTACGGTTATATCGAAATCGAAGATGAAGAACTTTGGGCAAAGGGTGCCGATACCGCCATCAATAGAAAATGGTGGGACTTTATGGCTGACATTATGGAAACAAATCCTGATAACAGTCCTGTTTCAGAAGATTTACACCTTGTATTCCATTTGGATTGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 4421,
    "end": 5200,
    "strand": 1,
    "locus_tag": "ctg148_8",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg148_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg148_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,421 - 5,200,\n (total: 780 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MGEVIRGILIPFLGTTLGASCVLFMKKMMNKMVQRALTGFAAGIMVSASVWSLLIPSMDYAAEMGKFAFVPAVVGFWIGILFLLAMDHIIPHLHMDTDKAEGPKSKLKKTTMLVFAVTLHNIPEGMAVGVVYAGYLAGNMQISAMGALALAIGIAIQNFPEGAIISMPLKAEGMSKGKAFLYGVLSGVVEPIGTVLTIVASGFIIPVLPYFLSFAAGAMMYVVIEELISEMSHGDHSNIGTVMFAVGFTLMMILDVALG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00148_NODE_80..&amp;from=0&amp;to=5446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MGEVIRGILIPFLGTTLGASCVLFMKKMMNKMVQRALTGFAAGIMVSASVWSLLIPSMDYAAEMGKFAFVPAVVGFWIGILFLLAMDHIIPHLHMDTDKAEGPKSKLKKTTMLVFAVTLHNIPEGMAVGVVYAGYLAGNMQISAMGALALAIGIAIQNFPEGAIISMPLKAEGMSKGKAFLYGVLSGVVEPIGTVLTIVASGFIIPVLPYFLSFAAGAMMYVVIEELISEMSHGDHSNIGTVMFAVGFTLMMILDVALG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGGCGAAGTTATAAGAGGAATATTGATACCGTTTTTGGGTACGACACTTGGTGCGTCTTGCGTACTGTTTATGAAGAAAATGATGAATAAGATGGTACAGCGTGCCTTAACAGGATTTGCGGCAGGGATTATGGTCTCCGCATCTGTGTGGAGCTTGCTTATACCGTCAATGGATTATGCGGCGGAAATGGGGAAGTTTGCATTTGTGCCGGCGGTTGTGGGATTTTGGATAGGTATATTGTTTTTGCTGGCAATGGACCATATAATACCGCATTTGCATATGGATACTGATAAAGCTGAAGGCCCGAAAAGTAAATTGAAAAAGACAACAATGCTTGTATTTGCTGTTACACTTCACAATATTCCAGAGGGAATGGCTGTGGGCGTTGTATATGCAGGTTATCTTGCAGGAAATATGCAAATATCGGCTATGGGCGCTTTGGCTTTGGCAATCGGTATTGCAATTCAGAATTTCCCGGAGGGTGCAATTATATCAATGCCACTTAAAGCCGAGGGAATGAGTAAAGGAAAAGCGTTTTTATACGGCGTGCTTTCGGGTGTGGTTGAGCCGATTGGGACAGTGCTTACCATCGTTGCGTCGGGTTTTATAATACCCGTATTGCCATATTTCCTCAGCTTTGCCGCAGGGGCGATGATGTACGTTGTAATAGAAGAATTAATTTCCGAAATGTCACACGGCGATCACTCAAATATTGGTACTGTAATGTTTGCAGTAGGTTTTACACTTATGATGATTCTTGATGTGGCACTTGGGTAA\">Copy to clipboard</span><br>\n</div>"
   }
  ],
  "clusters": [
   {
    "start": 2267,
    "end": 3870,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 5446,
    "product": "ranthipeptide",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "ttaCodons": [],
  "type": "ranthipeptide",
  "products": [
   "ranthipeptide"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP ranthipeptide",
  "anchor": "r148c1"
 }
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
