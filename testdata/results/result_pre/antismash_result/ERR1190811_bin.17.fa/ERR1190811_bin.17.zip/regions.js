var recordData = [
 {
  "length": 91069,
  "seq_id": "c00001_NODE_10..",
  "regions": []
 },
 {
  "length": 86869,
  "seq_id": "c00002_NODE_12..",
  "regions": []
 },
 {
  "length": 83232,
  "seq_id": "c00003_NODE_13..",
  "regions": []
 },
 {
  "length": 57430,
  "seq_id": "c00004_NODE_34..",
  "regions": []
 },
 {
  "length": 56285,
  "seq_id": "c00005_NODE_36..",
  "regions": []
 },
 {
  "length": 54246,
  "seq_id": "c00006_NODE_39..",
  "regions": []
 },
 {
  "length": 53303,
  "seq_id": "c00007_NODE_40..",
  "regions": []
 },
 {
  "length": 44651,
  "seq_id": "c00008_NODE_54..",
  "regions": []
 },
 {
  "length": 41243,
  "seq_id": "c00009_NODE_62..",
  "regions": []
 },
 {
  "length": 40880,
  "seq_id": "c00010_NODE_64..",
  "regions": []
 },
 {
  "length": 40395,
  "seq_id": "c00011_NODE_65..",
  "regions": []
 },
 {
  "length": 36426,
  "seq_id": "c00012_NODE_77..",
  "regions": []
 },
 {
  "length": 36045,
  "seq_id": "c00013_NODE_78..",
  "regions": []
 },
 {
  "length": 34765,
  "seq_id": "c00014_NODE_82..",
  "regions": []
 },
 {
  "length": 32073,
  "seq_id": "c00015_NODE_95..",
  "regions": []
 },
 {
  "length": 31774,
  "seq_id": "c00016_NODE_96..",
  "regions": []
 },
 {
  "length": 31145,
  "seq_id": "c00017_NODE_99..",
  "regions": []
 },
 {
  "length": 30979,
  "seq_id": "c00018_NODE_10..",
  "regions": []
 },
 {
  "length": 29919,
  "seq_id": "c00019_NODE_10..",
  "regions": []
 },
 {
  "length": 29261,
  "seq_id": "c00020_NODE_11..",
  "regions": []
 },
 {
  "length": 28314,
  "seq_id": "c00021_NODE_11..",
  "regions": []
 },
 {
  "length": 26861,
  "seq_id": "c00022_NODE_12..",
  "regions": []
 },
 {
  "length": 24999,
  "seq_id": "c00023_NODE_13..",
  "regions": []
 },
 {
  "length": 24426,
  "seq_id": "c00024_NODE_14..",
  "regions": []
 },
 {
  "length": 23969,
  "seq_id": "c00025_NODE_14..",
  "regions": []
 },
 {
  "length": 23216,
  "seq_id": "c00026_NODE_15..",
  "regions": []
 },
 {
  "length": 22423,
  "seq_id": "c00027_NODE_15..",
  "regions": []
 },
 {
  "length": 21840,
  "seq_id": "c00028_NODE_16..",
  "regions": []
 },
 {
  "length": 21263,
  "seq_id": "c00029_NODE_17..",
  "regions": []
 },
 {
  "length": 20556,
  "seq_id": "c00030_NODE_18..",
  "regions": []
 },
 {
  "length": 19811,
  "seq_id": "c00031_NODE_19..",
  "regions": []
 },
 {
  "length": 19163,
  "seq_id": "c00032_NODE_19..",
  "regions": []
 },
 {
  "length": 18343,
  "seq_id": "c00033_NODE_20..",
  "regions": []
 },
 {
  "length": 18342,
  "seq_id": "c00034_NODE_20..",
  "regions": []
 },
 {
  "length": 18076,
  "seq_id": "c00035_NODE_21..",
  "regions": []
 },
 {
  "length": 16534,
  "seq_id": "c00036_NODE_23..",
  "regions": []
 },
 {
  "length": 16187,
  "seq_id": "c00037_NODE_24..",
  "regions": []
 },
 {
  "length": 16137,
  "seq_id": "c00038_NODE_24..",
  "regions": []
 },
 {
  "length": 16021,
  "seq_id": "c00039_NODE_24..",
  "regions": []
 },
 {
  "length": 16007,
  "seq_id": "c00040_NODE_24..",
  "regions": []
 },
 {
  "length": 14474,
  "seq_id": "c00041_NODE_27..",
  "regions": []
 },
 {
  "length": 13610,
  "seq_id": "c00042_NODE_29..",
  "regions": []
 },
 {
  "length": 13567,
  "seq_id": "c00043_NODE_29..",
  "regions": []
 },
 {
  "length": 13314,
  "seq_id": "c00044_NODE_30..",
  "regions": []
 },
 {
  "length": 13241,
  "seq_id": "c00045_NODE_30..",
  "regions": []
 },
 {
  "length": 12975,
  "seq_id": "c00046_NODE_31..",
  "regions": []
 },
 {
  "length": 12970,
  "seq_id": "c00047_NODE_31..",
  "regions": []
 },
 {
  "length": 12254,
  "seq_id": "c00048_NODE_33..",
  "regions": []
 },
 {
  "length": 12108,
  "seq_id": "c00049_NODE_34..",
  "regions": []
 },
 {
  "length": 12040,
  "seq_id": "c00050_NODE_34..",
  "regions": []
 },
 {
  "length": 11456,
  "seq_id": "c00051_NODE_36..",
  "regions": []
 },
 {
  "length": 10786,
  "seq_id": "c00052_NODE_38..",
  "regions": []
 },
 {
  "length": 10745,
  "seq_id": "c00053_NODE_38..",
  "regions": []
 },
 {
  "length": 10585,
  "seq_id": "c00054_NODE_39..",
  "regions": []
 },
 {
  "length": 10458,
  "seq_id": "c00055_NODE_40..",
  "regions": []
 },
 {
  "length": 10326,
  "seq_id": "c00056_NODE_40..",
  "regions": []
 },
 {
  "length": 9872,
  "seq_id": "c00057_NODE_42..",
  "regions": []
 },
 {
  "length": 9867,
  "seq_id": "c00058_NODE_42..",
  "regions": []
 },
 {
  "length": 9666,
  "seq_id": "c00059_NODE_43..",
  "regions": []
 },
 {
  "length": 8922,
  "seq_id": "c00060_NODE_47..",
  "regions": []
 },
 {
  "length": 8765,
  "seq_id": "c00061_NODE_48..",
  "regions": []
 },
 {
  "length": 8416,
  "seq_id": "c00062_NODE_50..",
  "regions": []
 },
 {
  "length": 8342,
  "seq_id": "c00063_NODE_51..",
  "regions": []
 },
 {
  "length": 8263,
  "seq_id": "c00064_NODE_51..",
  "regions": []
 },
 {
  "length": 8221,
  "seq_id": "c00065_NODE_52..",
  "regions": []
 },
 {
  "length": 8000,
  "seq_id": "c00066_NODE_53..",
  "regions": []
 },
 {
  "length": 7765,
  "seq_id": "c00067_NODE_55..",
  "regions": []
 },
 {
  "length": 7462,
  "seq_id": "c00068_NODE_57..",
  "regions": []
 },
 {
  "length": 7353,
  "seq_id": "c00069_NODE_58..",
  "regions": []
 },
 {
  "length": 7186,
  "seq_id": "c00070_NODE_59..",
  "regions": []
 },
 {
  "length": 7181,
  "seq_id": "c00071_NODE_59..",
  "regions": []
 },
 {
  "length": 7099,
  "seq_id": "c00072_NODE_60..",
  "regions": []
 },
 {
  "length": 6829,
  "seq_id": "c00073_NODE_63..",
  "regions": []
 },
 {
  "length": 6729,
  "seq_id": "c00074_NODE_63..",
  "regions": []
 },
 {
  "length": 6345,
  "seq_id": "c00075_NODE_68..",
  "regions": []
 },
 {
  "length": 6257,
  "seq_id": "c00076_NODE_69..",
  "regions": []
 },
 {
  "length": 6135,
  "seq_id": "c00077_NODE_70..",
  "regions": []
 },
 {
  "length": 6028,
  "seq_id": "c00078_NODE_72..",
  "regions": []
 },
 {
  "length": 5826,
  "seq_id": "c00079_NODE_75..",
  "regions": []
 },
 {
  "length": 5763,
  "seq_id": "c00080_NODE_76..",
  "regions": []
 },
 {
  "length": 5570,
  "seq_id": "c00081_NODE_79..",
  "regions": []
 },
 {
  "length": 5037,
  "seq_id": "c00082_NODE_88..",
  "regions": []
 },
 {
  "length": 4869,
  "seq_id": "c00083_NODE_91..",
  "regions": []
 },
 {
  "length": 4663,
  "seq_id": "c00084_NODE_95..",
  "regions": []
 },
 {
  "length": 4505,
  "seq_id": "c00085_NODE_98..",
  "regions": []
 },
 {
  "length": 4364,
  "seq_id": "c00086_NODE_10..",
  "regions": []
 },
 {
  "length": 4178,
  "seq_id": "c00087_NODE_10..",
  "regions": []
 },
 {
  "length": 4117,
  "seq_id": "c00088_NODE_10..",
  "regions": []
 },
 {
  "length": 4077,
  "seq_id": "c00089_NODE_10..",
  "regions": []
 },
 {
  "length": 4014,
  "seq_id": "c00090_NODE_11..",
  "regions": []
 },
 {
  "length": 3806,
  "seq_id": "c00091_NODE_11..",
  "regions": []
 },
 {
  "length": 3514,
  "seq_id": "c00092_NODE_12..",
  "regions": []
 },
 {
  "length": 2950,
  "seq_id": "c00093_NODE_15..",
  "regions": []
 },
 {
  "length": 2838,
  "seq_id": "c00094_NODE_16..",
  "regions": []
 },
 {
  "length": 2749,
  "seq_id": "c00095_NODE_16..",
  "regions": []
 },
 {
  "length": 2721,
  "seq_id": "c00096_NODE_17..",
  "regions": []
 },
 {
  "length": 2718,
  "seq_id": "c00097_NODE_17..",
  "regions": []
 },
 {
  "length": 2576,
  "seq_id": "c00098_NODE_18..",
  "regions": []
 },
 {
  "length": 2281,
  "seq_id": "c00099_NODE_20..",
  "regions": []
 },
 {
  "length": 2247,
  "seq_id": "c00100_NODE_21..",
  "regions": []
 },
 {
  "length": 2201,
  "seq_id": "c00101_NODE_21..",
  "regions": []
 },
 {
  "length": 2191,
  "seq_id": "c00102_NODE_21..",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
