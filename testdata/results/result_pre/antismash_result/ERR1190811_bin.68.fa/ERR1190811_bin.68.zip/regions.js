var recordData = [
 {
  "length": 63543,
  "seq_id": "c00001_NODE_26..",
  "regions": []
 },
 {
  "length": 46118,
  "seq_id": "c00002_NODE_51..",
  "regions": []
 },
 {
  "length": 41692,
  "seq_id": "c00003_NODE_62..",
  "regions": []
 },
 {
  "length": 38145,
  "seq_id": "c00004_NODE_71..",
  "regions": []
 },
 {
  "length": 34795,
  "seq_id": "c00005_NODE_82..",
  "regions": []
 },
 {
  "length": 34313,
  "seq_id": "c00006_NODE_84..",
  "regions": []
 },
 {
  "length": 31313,
  "seq_id": "c00007_NODE_99..",
  "regions": []
 },
 {
  "length": 30223,
  "seq_id": "c00008_NODE_10..",
  "regions": []
 },
 {
  "length": 30087,
  "seq_id": "c00009_NODE_10..",
  "regions": []
 },
 {
  "length": 29955,
  "seq_id": "c00010_NODE_10..",
  "regions": []
 },
 {
  "length": 27305,
  "seq_id": "c00011_NODE_12..",
  "regions": []
 },
 {
  "length": 26697,
  "seq_id": "c00012_NODE_12..",
  "regions": []
 },
 {
  "length": 25019,
  "seq_id": "c00013_NODE_13..",
  "regions": []
 },
 {
  "length": 24927,
  "seq_id": "c00014_NODE_13..",
  "regions": []
 },
 {
  "length": 24594,
  "seq_id": "c00015_NODE_14..",
  "regions": []
 },
 {
  "length": 22983,
  "seq_id": "c00016_NODE_15..",
  "regions": []
 },
 {
  "length": 22557,
  "seq_id": "c00017_NODE_15..",
  "regions": []
 },
 {
  "length": 22113,
  "seq_id": "c00018_NODE_16..",
  "regions": []
 },
 {
  "length": 20766,
  "seq_id": "c00019_NODE_17..",
  "regions": []
 },
 {
  "length": 20652,
  "seq_id": "c00020_NODE_17..",
  "regions": []
 },
 {
  "length": 19934,
  "seq_id": "c00021_NODE_18..",
  "regions": []
 },
 {
  "length": 19372,
  "seq_id": "c00022_NODE_19..",
  "regions": []
 },
 {
  "length": 18990,
  "seq_id": "c00023_NODE_20..",
  "regions": []
 },
 {
  "length": 18833,
  "seq_id": "c00024_NODE_20..",
  "regions": []
 },
 {
  "length": 18673,
  "seq_id": "c00025_NODE_20..",
  "regions": []
 },
 {
  "length": 17678,
  "seq_id": "c00026_NODE_21..",
  "regions": []
 },
 {
  "length": 17505,
  "seq_id": "c00027_NODE_22..",
  "regions": []
 },
 {
  "length": 17314,
  "seq_id": "c00028_NODE_22..",
  "regions": []
 },
 {
  "length": 17037,
  "seq_id": "c00029_NODE_23..",
  "regions": []
 },
 {
  "length": 17028,
  "seq_id": "c00030_NODE_23..",
  "regions": []
 },
 {
  "length": 17017,
  "seq_id": "c00031_NODE_23..",
  "regions": []
 },
 {
  "length": 16768,
  "seq_id": "c00032_NODE_23..",
  "regions": []
 },
 {
  "length": 16523,
  "seq_id": "c00033_NODE_23..",
  "regions": []
 },
 {
  "length": 16310,
  "seq_id": "c00034_NODE_24..",
  "regions": []
 },
 {
  "length": 15851,
  "seq_id": "c00035_NODE_25..",
  "regions": []
 },
 {
  "length": 15010,
  "seq_id": "c00036_NODE_26..",
  "regions": []
 },
 {
  "length": 14452,
  "seq_id": "c00037_NODE_27..",
  "regions": []
 },
 {
  "length": 14028,
  "seq_id": "c00038_NODE_28..",
  "regions": []
 },
 {
  "length": 13865,
  "seq_id": "c00039_NODE_29..",
  "regions": []
 },
 {
  "length": 13832,
  "seq_id": "c00040_NODE_29..",
  "regions": []
 },
 {
  "length": 13696,
  "seq_id": "c00041_NODE_29..",
  "regions": []
 },
 {
  "length": 13675,
  "seq_id": "c00042_NODE_29..",
  "regions": []
 },
 {
  "length": 12912,
  "seq_id": "c00043_NODE_31..",
  "regions": []
 },
 {
  "length": 12871,
  "seq_id": "c00044_NODE_31..",
  "regions": []
 },
 {
  "length": 12579,
  "seq_id": "c00045_NODE_32..",
  "regions": []
 },
 {
  "length": 12459,
  "seq_id": "c00046_NODE_32..",
  "regions": []
 },
 {
  "length": 12246,
  "seq_id": "c00047_NODE_33..",
  "regions": []
 },
 {
  "length": 12241,
  "seq_id": "c00048_NODE_33..",
  "regions": []
 },
 {
  "length": 12241,
  "seq_id": "c00049_NODE_33..",
  "regions": []
 },
 {
  "length": 12059,
  "seq_id": "c00050_NODE_34..",
  "regions": []
 },
 {
  "length": 11881,
  "seq_id": "c00051_NODE_34..",
  "regions": []
 },
 {
  "length": 11570,
  "seq_id": "c00052_NODE_35..",
  "regions": []
 },
 {
  "length": 11562,
  "seq_id": "c00053_NODE_35..",
  "regions": []
 },
 {
  "length": 11469,
  "seq_id": "c00054_NODE_36..",
  "regions": []
 },
 {
  "length": 11429,
  "seq_id": "c00055_NODE_36..",
  "regions": []
 },
 {
  "length": 11392,
  "seq_id": "c00056_NODE_36..",
  "regions": []
 },
 {
  "length": 11143,
  "seq_id": "c00057_NODE_37..",
  "regions": []
 },
 {
  "length": 11101,
  "seq_id": "c00058_NODE_37..",
  "regions": []
 },
 {
  "length": 11099,
  "seq_id": "c00059_NODE_37..",
  "regions": []
 },
 {
  "length": 11026,
  "seq_id": "c00060_NODE_37..",
  "regions": []
 },
 {
  "length": 10924,
  "seq_id": "c00061_NODE_38..",
  "regions": []
 },
 {
  "length": 10851,
  "seq_id": "c00062_NODE_38..",
  "regions": []
 },
 {
  "length": 10572,
  "seq_id": "c00063_NODE_39..",
  "regions": []
 },
 {
  "length": 10569,
  "seq_id": "c00064_NODE_39..",
  "regions": []
 },
 {
  "length": 10235,
  "seq_id": "c00065_NODE_40..",
  "regions": []
 },
 {
  "length": 10164,
  "seq_id": "c00066_NODE_41..",
  "regions": []
 },
 {
  "length": 9854,
  "seq_id": "c00067_NODE_42..",
  "regions": []
 },
 {
  "length": 9751,
  "seq_id": "c00068_NODE_43..",
  "regions": []
 },
 {
  "length": 9715,
  "seq_id": "c00069_NODE_43..",
  "regions": []
 },
 {
  "length": 9569,
  "seq_id": "c00070_NODE_43..",
  "regions": []
 },
 {
  "length": 9394,
  "seq_id": "c00071_NODE_44..",
  "regions": []
 },
 {
  "length": 9305,
  "seq_id": "c00072_NODE_45..",
  "regions": []
 },
 {
  "length": 9194,
  "seq_id": "c00073_NODE_45..",
  "regions": []
 },
 {
  "length": 8998,
  "seq_id": "c00074_NODE_46..",
  "regions": []
 },
 {
  "length": 8921,
  "seq_id": "c00075_NODE_47..",
  "regions": []
 },
 {
  "length": 8915,
  "seq_id": "c00076_NODE_47..",
  "regions": []
 },
 {
  "length": 8888,
  "seq_id": "c00077_NODE_47..",
  "regions": []
 },
 {
  "length": 8754,
  "seq_id": "c00078_NODE_48..",
  "regions": []
 },
 {
  "length": 8741,
  "seq_id": "c00079_NODE_48..",
  "regions": []
 },
 {
  "length": 8678,
  "seq_id": "c00080_NODE_49..",
  "regions": []
 },
 {
  "length": 8617,
  "seq_id": "c00081_NODE_49..",
  "regions": []
 },
 {
  "length": 8511,
  "seq_id": "c00082_NODE_50..",
  "regions": []
 },
 {
  "length": 8458,
  "seq_id": "c00083_NODE_50..",
  "regions": []
 },
 {
  "length": 8418,
  "seq_id": "c00084_NODE_50..",
  "regions": []
 },
 {
  "length": 8336,
  "seq_id": "c00085_NODE_51..",
  "regions": []
 },
 {
  "length": 8288,
  "seq_id": "c00086_NODE_51..",
  "regions": []
 },
 {
  "length": 8090,
  "seq_id": "c00087_NODE_53..",
  "regions": []
 },
 {
  "length": 8058,
  "seq_id": "c00088_NODE_53..",
  "regions": []
 },
 {
  "length": 7868,
  "seq_id": "c00089_NODE_54..",
  "regions": []
 },
 {
  "length": 7697,
  "seq_id": "c00090_NODE_55..",
  "regions": []
 },
 {
  "length": 7670,
  "seq_id": "c00091_NODE_56..",
  "regions": []
 },
 {
  "length": 7306,
  "seq_id": "c00092_NODE_58..",
  "regions": []
 },
 {
  "length": 7264,
  "seq_id": "c00093_NODE_59..",
  "regions": []
 },
 {
  "length": 7152,
  "seq_id": "c00094_NODE_60..",
  "regions": []
 },
 {
  "length": 7052,
  "seq_id": "c00095_NODE_61..",
  "regions": []
 },
 {
  "length": 6880,
  "seq_id": "c00096_NODE_62..",
  "regions": []
 },
 {
  "length": 6818,
  "seq_id": "c00097_NODE_63..",
  "regions": []
 },
 {
  "length": 6818,
  "seq_id": "c00098_NODE_63..",
  "regions": []
 },
 {
  "length": 6756,
  "seq_id": "c00099_NODE_63..",
  "regions": []
 },
 {
  "length": 6648,
  "seq_id": "c00100_NODE_64..",
  "regions": []
 },
 {
  "length": 6419,
  "seq_id": "c00101_NODE_67..",
  "regions": []
 },
 {
  "length": 6406,
  "seq_id": "c00102_NODE_67..",
  "regions": []
 },
 {
  "length": 6358,
  "seq_id": "c00103_NODE_67..",
  "regions": []
 },
 {
  "length": 6332,
  "seq_id": "c00104_NODE_68..",
  "regions": []
 },
 {
  "length": 6300,
  "seq_id": "c00105_NODE_68..",
  "regions": []
 },
 {
  "length": 6286,
  "seq_id": "c00106_NODE_68..",
  "regions": []
 },
 {
  "length": 6280,
  "seq_id": "c00107_NODE_68..",
  "regions": []
 },
 {
  "length": 6229,
  "seq_id": "c00108_NODE_69..",
  "regions": []
 },
 {
  "length": 6210,
  "seq_id": "c00109_NODE_69..",
  "regions": []
 },
 {
  "length": 6170,
  "seq_id": "c00110_NODE_70..",
  "regions": []
 },
 {
  "length": 6098,
  "seq_id": "c00111_NODE_71..",
  "regions": []
 },
 {
  "length": 6014,
  "seq_id": "c00112_NODE_72..",
  "regions": []
 },
 {
  "length": 5977,
  "seq_id": "c00113_NODE_72..",
  "regions": []
 },
 {
  "length": 5938,
  "seq_id": "c00114_NODE_73..",
  "regions": []
 },
 {
  "length": 5931,
  "seq_id": "c00115_NODE_73..",
  "regions": []
 },
 {
  "length": 5838,
  "seq_id": "c00116_NODE_75..",
  "regions": []
 },
 {
  "length": 5811,
  "seq_id": "c00117_NODE_75..",
  "regions": []
 },
 {
  "length": 5802,
  "seq_id": "c00118_NODE_75..",
  "regions": []
 },
 {
  "length": 5701,
  "seq_id": "c00119_NODE_76..",
  "regions": []
 },
 {
  "length": 5690,
  "seq_id": "c00120_NODE_77..",
  "regions": []
 },
 {
  "length": 5686,
  "seq_id": "c00121_NODE_77..",
  "regions": []
 },
 {
  "length": 5620,
  "seq_id": "c00122_NODE_78..",
  "regions": []
 },
 {
  "length": 5587,
  "seq_id": "c00123_NODE_78..",
  "regions": []
 },
 {
  "length": 5406,
  "seq_id": "c00124_NODE_81..",
  "regions": []
 },
 {
  "length": 5355,
  "seq_id": "c00125_NODE_82..",
  "regions": []
 },
 {
  "length": 5344,
  "seq_id": "c00126_NODE_82..",
  "regions": []
 },
 {
  "length": 5219,
  "seq_id": "c00127_NODE_84..",
  "regions": []
 },
 {
  "length": 5167,
  "seq_id": "c00128_NODE_85..",
  "regions": []
 },
 {
  "length": 5164,
  "seq_id": "c00129_NODE_85..",
  "regions": []
 },
 {
  "length": 5122,
  "seq_id": "c00130_NODE_86..",
  "regions": []
 },
 {
  "length": 5018,
  "seq_id": "c00131_NODE_88..",
  "regions": []
 },
 {
  "length": 5009,
  "seq_id": "c00132_NODE_88..",
  "regions": []
 },
 {
  "length": 4963,
  "seq_id": "c00133_NODE_89..",
  "regions": []
 },
 {
  "length": 4723,
  "seq_id": "c00134_NODE_94..",
  "regions": []
 },
 {
  "length": 4666,
  "seq_id": "c00135_NODE_95..",
  "regions": []
 },
 {
  "length": 4659,
  "seq_id": "c00136_NODE_95..",
  "regions": []
 },
 {
  "length": 4659,
  "seq_id": "c00137_NODE_95..",
  "regions": []
 },
 {
  "length": 4627,
  "seq_id": "c00138_NODE_96..",
  "regions": []
 },
 {
  "length": 4625,
  "seq_id": "c00139_NODE_96..",
  "regions": []
 },
 {
  "length": 4619,
  "seq_id": "c00140_NODE_96..",
  "regions": []
 },
 {
  "length": 4614,
  "seq_id": "c00141_NODE_96..",
  "regions": []
 },
 {
  "length": 4600,
  "seq_id": "c00142_NODE_96..",
  "regions": []
 },
 {
  "length": 4587,
  "seq_id": "c00143_NODE_97..",
  "regions": []
 },
 {
  "length": 4585,
  "seq_id": "c00144_NODE_97..",
  "regions": []
 },
 {
  "length": 4566,
  "seq_id": "c00145_NODE_97..",
  "regions": []
 },
 {
  "length": 4554,
  "seq_id": "c00146_NODE_97..",
  "regions": []
 },
 {
  "length": 4539,
  "seq_id": "c00147_NODE_98..",
  "regions": []
 },
 {
  "length": 4499,
  "seq_id": "c00148_NODE_99..",
  "regions": []
 },
 {
  "length": 4496,
  "seq_id": "c00149_NODE_99..",
  "regions": []
 },
 {
  "length": 4432,
  "seq_id": "c00150_NODE_10..",
  "regions": []
 },
 {
  "length": 4411,
  "seq_id": "c00151_NODE_10..",
  "regions": []
 },
 {
  "length": 4388,
  "seq_id": "c00152_NODE_10..",
  "regions": []
 },
 {
  "length": 4376,
  "seq_id": "c00153_NODE_10..",
  "regions": []
 },
 {
  "length": 4355,
  "seq_id": "c00154_NODE_10..",
  "regions": []
 },
 {
  "length": 4342,
  "seq_id": "c00155_NODE_10..",
  "regions": []
 },
 {
  "length": 4235,
  "seq_id": "c00156_NODE_10..",
  "regions": []
 },
 {
  "length": 4201,
  "seq_id": "c00157_NODE_10..",
  "regions": []
 },
 {
  "length": 4185,
  "seq_id": "c00158_NODE_10..",
  "regions": []
 },
 {
  "length": 4182,
  "seq_id": "c00159_NODE_10..",
  "regions": []
 },
 {
  "length": 4112,
  "seq_id": "c00160_NODE_10..",
  "regions": []
 },
 {
  "length": 4053,
  "seq_id": "c00161_NODE_11..",
  "regions": []
 },
 {
  "length": 3945,
  "seq_id": "c00162_NODE_11..",
  "regions": []
 },
 {
  "length": 3919,
  "seq_id": "c00163_NODE_11..",
  "regions": []
 },
 {
  "length": 3918,
  "seq_id": "c00164_NODE_11..",
  "regions": []
 },
 {
  "length": 3887,
  "seq_id": "c00165_NODE_11..",
  "regions": []
 },
 {
  "length": 3755,
  "seq_id": "c00166_NODE_12..",
  "regions": []
 },
 {
  "length": 3682,
  "seq_id": "c00167_NODE_12..",
  "regions": []
 },
 {
  "length": 3621,
  "seq_id": "c00168_NODE_12..",
  "regions": []
 },
 {
  "length": 3566,
  "seq_id": "c00169_NODE_12..",
  "regions": []
 },
 {
  "length": 3559,
  "seq_id": "c00170_NODE_12..",
  "regions": []
 },
 {
  "length": 3401,
  "seq_id": "c00171_NODE_13..",
  "regions": []
 },
 {
  "length": 3365,
  "seq_id": "c00172_NODE_13..",
  "regions": []
 },
 {
  "length": 3336,
  "seq_id": "c00173_NODE_13..",
  "regions": []
 },
 {
  "length": 3239,
  "seq_id": "c00174_NODE_14..",
  "regions": []
 },
 {
  "length": 3206,
  "seq_id": "c00175_NODE_14..",
  "regions": []
 },
 {
  "length": 3204,
  "seq_id": "c00176_NODE_14..",
  "regions": []
 },
 {
  "length": 3126,
  "seq_id": "c00177_NODE_14..",
  "regions": []
 },
 {
  "length": 3101,
  "seq_id": "c00178_NODE_14..",
  "regions": []
 },
 {
  "length": 3079,
  "seq_id": "c00179_NODE_14..",
  "regions": []
 },
 {
  "length": 3063,
  "seq_id": "c00180_NODE_14..",
  "regions": []
 },
 {
  "length": 3020,
  "seq_id": "c00181_NODE_15..",
  "regions": []
 },
 {
  "length": 3004,
  "seq_id": "c00182_NODE_15..",
  "regions": []
 },
 {
  "length": 2991,
  "seq_id": "c00183_NODE_15..",
  "regions": []
 },
 {
  "length": 2982,
  "seq_id": "c00184_NODE_15..",
  "regions": []
 },
 {
  "length": 2959,
  "seq_id": "c00185_NODE_15..",
  "regions": []
 },
 {
  "length": 2920,
  "seq_id": "c00186_NODE_15..",
  "regions": []
 },
 {
  "length": 2834,
  "seq_id": "c00187_NODE_16..",
  "regions": []
 },
 {
  "length": 2825,
  "seq_id": "c00188_NODE_16..",
  "regions": []
 },
 {
  "length": 2794,
  "seq_id": "c00189_NODE_16..",
  "regions": []
 },
 {
  "length": 2776,
  "seq_id": "c00190_NODE_16..",
  "regions": []
 },
 {
  "length": 2767,
  "seq_id": "c00191_NODE_16..",
  "regions": []
 },
 {
  "length": 2752,
  "seq_id": "c00192_NODE_16..",
  "regions": []
 },
 {
  "length": 2726,
  "seq_id": "c00193_NODE_17..",
  "regions": []
 },
 {
  "length": 2720,
  "seq_id": "c00194_NODE_17..",
  "regions": []
 },
 {
  "length": 2700,
  "seq_id": "c00195_NODE_17..",
  "regions": []
 },
 {
  "length": 2663,
  "seq_id": "c00196_NODE_17..",
  "regions": []
 },
 {
  "length": 2662,
  "seq_id": "c00197_NODE_17..",
  "regions": []
 },
 {
  "length": 2613,
  "seq_id": "c00198_NODE_17..",
  "regions": []
 },
 {
  "length": 2600,
  "seq_id": "c00199_NODE_17..",
  "regions": []
 },
 {
  "length": 2544,
  "seq_id": "c00200_NODE_18..",
  "regions": []
 },
 {
  "length": 2521,
  "seq_id": "c00201_NODE_18..",
  "regions": []
 },
 {
  "length": 2516,
  "seq_id": "c00202_NODE_18..",
  "regions": []
 },
 {
  "length": 2498,
  "seq_id": "c00203_NODE_18..",
  "regions": []
 },
 {
  "length": 2477,
  "seq_id": "c00204_NODE_18..",
  "regions": []
 },
 {
  "length": 2445,
  "seq_id": "c00205_NODE_19..",
  "regions": []
 },
 {
  "length": 2445,
  "seq_id": "c00206_NODE_19..",
  "regions": []
 },
 {
  "length": 2441,
  "seq_id": "c00207_NODE_19..",
  "regions": []
 },
 {
  "length": 2370,
  "seq_id": "c00208_NODE_19..",
  "regions": []
 },
 {
  "length": 2300,
  "seq_id": "c00209_NODE_20..",
  "regions": []
 },
 {
  "length": 2286,
  "seq_id": "c00210_NODE_20..",
  "regions": []
 },
 {
  "length": 2282,
  "seq_id": "c00211_NODE_20..",
  "regions": []
 },
 {
  "length": 2247,
  "seq_id": "c00212_NODE_21..",
  "regions": []
 },
 {
  "length": 2239,
  "seq_id": "c00213_NODE_21..",
  "regions": []
 },
 {
  "length": 2208,
  "seq_id": "c00214_NODE_21..",
  "regions": []
 },
 {
  "length": 2190,
  "seq_id": "c00215_NODE_21..",
  "regions": []
 },
 {
  "length": 2149,
  "seq_id": "c00216_NODE_22..",
  "regions": []
 },
 {
  "length": 2123,
  "seq_id": "c00217_NODE_22..",
  "regions": []
 },
 {
  "length": 2103,
  "seq_id": "c00218_NODE_22..",
  "regions": []
 },
 {
  "length": 2065,
  "seq_id": "c00219_NODE_23..",
  "regions": []
 },
 {
  "length": 2058,
  "seq_id": "c00220_NODE_23..",
  "regions": []
 },
 {
  "length": 2048,
  "seq_id": "c00221_NODE_23..",
  "regions": []
 },
 {
  "length": 2036,
  "seq_id": "c00222_NODE_23..",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
