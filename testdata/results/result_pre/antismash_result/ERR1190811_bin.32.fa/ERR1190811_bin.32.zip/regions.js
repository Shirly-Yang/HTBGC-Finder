var recordData = [
 {
  "length": 40270,
  "seq_id": "c00001_NODE_65..",
  "regions": []
 },
 {
  "length": 34488,
  "seq_id": "c00002_NODE_83..",
  "regions": []
 },
 {
  "length": 33086,
  "seq_id": "c00003_NODE_90..",
  "regions": []
 },
 {
  "length": 32706,
  "seq_id": "c00004_NODE_92..",
  "regions": []
 },
 {
  "length": 26975,
  "seq_id": "c00005_NODE_12..",
  "regions": []
 },
 {
  "length": 24892,
  "seq_id": "c00006_NODE_13..",
  "regions": []
 },
 {
  "length": 24838,
  "seq_id": "c00007_NODE_14..",
  "regions": []
 },
 {
  "length": 23752,
  "seq_id": "c00008_NODE_14..",
  "regions": []
 },
 {
  "length": 23396,
  "seq_id": "c00009_NODE_15..",
  "regions": []
 },
 {
  "length": 22390,
  "seq_id": "c00010_NODE_16..",
  "regions": []
 },
 {
  "length": 20919,
  "seq_id": "c00011_NODE_17..",
  "regions": []
 },
 {
  "length": 20110,
  "seq_id": "c00012_NODE_18..",
  "regions": []
 },
 {
  "length": 19279,
  "seq_id": "c00013_NODE_19..",
  "regions": []
 },
 {
  "length": 18462,
  "seq_id": "c00014_NODE_20..",
  "regions": []
 },
 {
  "length": 18401,
  "seq_id": "c00015_NODE_20..",
  "regions": []
 },
 {
  "length": 18340,
  "seq_id": "c00016_NODE_20..",
  "regions": []
 },
 {
  "length": 18293,
  "seq_id": "c00017_NODE_21..",
  "regions": []
 },
 {
  "length": 17834,
  "seq_id": "c00018_NODE_21..",
  "regions": []
 },
 {
  "length": 17652,
  "seq_id": "c00019_NODE_21..",
  "regions": []
 },
 {
  "length": 17498,
  "seq_id": "c00020_NODE_22..",
  "regions": []
 },
 {
  "length": 17207,
  "seq_id": "c00021_NODE_22..",
  "regions": []
 },
 {
  "length": 16887,
  "seq_id": "c00022_NODE_23..",
  "regions": []
 },
 {
  "length": 16757,
  "seq_id": "c00023_NODE_23..",
  "regions": []
 },
 {
  "length": 16660,
  "seq_id": "c00024_NODE_23..",
  "regions": []
 },
 {
  "length": 16243,
  "seq_id": "c00025_NODE_24..",
  "regions": []
 },
 {
  "length": 15512,
  "seq_id": "c00026_NODE_25..",
  "regions": []
 },
 {
  "length": 15328,
  "seq_id": "c00027_NODE_26..",
  "regions": []
 },
 {
  "length": 14789,
  "seq_id": "c00028_NODE_27..",
  "regions": []
 },
 {
  "length": 14505,
  "seq_id": "c00029_NODE_27..",
  "regions": []
 },
 {
  "length": 14499,
  "seq_id": "c00030_NODE_27..",
  "regions": []
 },
 {
  "length": 14329,
  "seq_id": "c00031_NODE_28..",
  "regions": []
 },
 {
  "length": 13870,
  "seq_id": "c00032_NODE_29..",
  "regions": []
 },
 {
  "length": 13668,
  "seq_id": "c00033_NODE_29..",
  "regions": []
 },
 {
  "length": 13474,
  "seq_id": "c00034_NODE_30..",
  "regions": []
 },
 {
  "length": 13372,
  "seq_id": "c00035_NODE_30..",
  "regions": []
 },
 {
  "length": 13237,
  "seq_id": "c00036_NODE_30..",
  "regions": []
 },
 {
  "length": 13107,
  "seq_id": "c00037_NODE_31..",
  "regions": []
 },
 {
  "length": 12971,
  "seq_id": "c00038_NODE_31..",
  "regions": []
 },
 {
  "length": 12935,
  "seq_id": "c00039_NODE_31..",
  "regions": []
 },
 {
  "length": 12686,
  "seq_id": "c00040_NODE_32..",
  "regions": []
 },
 {
  "length": 12600,
  "seq_id": "c00041_NODE_32..",
  "regions": []
 },
 {
  "length": 12588,
  "seq_id": "c00042_NODE_32..",
  "regions": []
 },
 {
  "length": 12450,
  "seq_id": "c00043_NODE_32..",
  "regions": []
 },
 {
  "length": 12283,
  "seq_id": "c00044_NODE_33..",
  "regions": []
 },
 {
  "length": 12030,
  "seq_id": "c00045_NODE_34..",
  "regions": []
 },
 {
  "length": 11924,
  "seq_id": "c00046_NODE_34..",
  "regions": []
 },
 {
  "length": 11918,
  "seq_id": "c00047_NODE_34..",
  "regions": []
 },
 {
  "length": 11709,
  "seq_id": "c00048_NODE_35..",
  "regions": []
 },
 {
  "length": 11624,
  "seq_id": "c00049_NODE_35..",
  "regions": []
 },
 {
  "length": 11614,
  "seq_id": "c00050_NODE_35..",
  "regions": []
 },
 {
  "length": 11413,
  "seq_id": "c00051_NODE_36..",
  "regions": []
 },
 {
  "length": 11306,
  "seq_id": "c00052_NODE_36..",
  "regions": []
 },
 {
  "length": 11173,
  "seq_id": "c00053_NODE_37..",
  "regions": []
 },
 {
  "length": 11154,
  "seq_id": "c00054_NODE_37..",
  "regions": []
 },
 {
  "length": 11126,
  "seq_id": "c00055_NODE_37..",
  "regions": []
 },
 {
  "length": 10952,
  "seq_id": "c00056_NODE_38..",
  "regions": []
 },
 {
  "length": 10853,
  "seq_id": "c00057_NODE_38..",
  "regions": []
 },
 {
  "length": 10815,
  "seq_id": "c00058_NODE_38..",
  "regions": []
 },
 {
  "length": 10806,
  "seq_id": "c00059_NODE_38..",
  "regions": []
 },
 {
  "length": 10687,
  "seq_id": "c00060_NODE_39..",
  "regions": []
 },
 {
  "length": 10683,
  "seq_id": "c00061_NODE_39..",
  "regions": []
 },
 {
  "length": 10604,
  "seq_id": "c00062_NODE_39..",
  "regions": []
 },
 {
  "length": 10574,
  "seq_id": "c00063_NODE_39..",
  "regions": []
 },
 {
  "length": 10560,
  "seq_id": "c00064_NODE_39..",
  "regions": []
 },
 {
  "length": 10535,
  "seq_id": "c00065_NODE_39..",
  "regions": []
 },
 {
  "length": 10460,
  "seq_id": "c00066_NODE_40..",
  "regions": []
 },
 {
  "length": 10106,
  "seq_id": "c00067_NODE_41..",
  "regions": []
 },
 {
  "length": 9946,
  "seq_id": "c00068_NODE_42..",
  "regions": []
 },
 {
  "length": 9797,
  "seq_id": "c00069_NODE_42..",
  "regions": []
 },
 {
  "length": 9687,
  "seq_id": "c00070_NODE_43..",
  "regions": []
 },
 {
  "length": 9671,
  "seq_id": "c00071_NODE_43..",
  "regions": []
 },
 {
  "length": 9559,
  "seq_id": "c00072_NODE_43..",
  "regions": []
 },
 {
  "length": 9421,
  "seq_id": "c00073_NODE_44..",
  "regions": []
 },
 {
  "length": 9382,
  "seq_id": "c00074_NODE_44..",
  "regions": []
 },
 {
  "length": 9376,
  "seq_id": "c00075_NODE_44..",
  "regions": []
 },
 {
  "length": 9323,
  "seq_id": "c00076_NODE_45..",
  "regions": []
 },
 {
  "length": 9313,
  "seq_id": "c00077_NODE_45..",
  "regions": []
 },
 {
  "length": 9221,
  "seq_id": "c00078_NODE_45..",
  "regions": []
 },
 {
  "length": 9202,
  "seq_id": "c00079_NODE_45..",
  "regions": []
 },
 {
  "length": 9160,
  "seq_id": "c00080_NODE_46..",
  "regions": []
 },
 {
  "length": 9074,
  "seq_id": "c00081_NODE_46..",
  "regions": []
 },
 {
  "length": 8791,
  "seq_id": "c00082_NODE_48..",
  "regions": []
 },
 {
  "length": 8782,
  "seq_id": "c00083_NODE_48..",
  "regions": []
 },
 {
  "length": 8556,
  "seq_id": "c00084_NODE_49..",
  "regions": []
 },
 {
  "length": 8458,
  "seq_id": "c00085_NODE_50..",
  "regions": []
 },
 {
  "length": 8431,
  "seq_id": "c00086_NODE_50..",
  "regions": []
 },
 {
  "length": 8421,
  "seq_id": "c00087_NODE_50..",
  "regions": []
 },
 {
  "length": 8365,
  "seq_id": "c00088_NODE_51..",
  "regions": []
 },
 {
  "length": 8309,
  "seq_id": "c00089_NODE_51..",
  "regions": []
 },
 {
  "length": 8273,
  "seq_id": "c00090_NODE_51..",
  "regions": []
 },
 {
  "length": 7980,
  "seq_id": "c00091_NODE_53..",
  "regions": []
 },
 {
  "length": 7964,
  "seq_id": "c00092_NODE_53..",
  "regions": []
 },
 {
  "length": 7904,
  "seq_id": "c00093_NODE_54..",
  "regions": []
 },
 {
  "length": 7898,
  "seq_id": "c00094_NODE_54..",
  "regions": []
 },
 {
  "length": 7895,
  "seq_id": "c00095_NODE_54..",
  "regions": []
 },
 {
  "length": 7826,
  "seq_id": "c00096_NODE_54..",
  "regions": []
 },
 {
  "length": 7823,
  "seq_id": "c00097_NODE_54..",
  "regions": []
 },
 {
  "length": 7779,
  "seq_id": "c00098_NODE_55..",
  "regions": []
 },
 {
  "length": 7680,
  "seq_id": "c00099_NODE_56..",
  "regions": []
 },
 {
  "length": 7588,
  "seq_id": "c00100_NODE_56..",
  "regions": []
 },
 {
  "length": 7508,
  "seq_id": "c00101_NODE_57..",
  "regions": []
 },
 {
  "length": 7489,
  "seq_id": "c00102_NODE_57..",
  "regions": []
 },
 {
  "length": 7435,
  "seq_id": "c00103_NODE_57..",
  "regions": []
 },
 {
  "length": 7422,
  "seq_id": "c00104_NODE_57..",
  "regions": []
 },
 {
  "length": 7341,
  "seq_id": "c00105_NODE_58..",
  "regions": []
 },
 {
  "length": 7267,
  "seq_id": "c00106_NODE_59..",
  "regions": []
 },
 {
  "length": 7026,
  "seq_id": "c00107_NODE_61..",
  "regions": []
 },
 {
  "length": 7026,
  "seq_id": "c00108_NODE_61..",
  "regions": []
 },
 {
  "length": 6990,
  "seq_id": "c00109_NODE_61..",
  "regions": []
 },
 {
  "length": 6905,
  "seq_id": "c00110_NODE_62..",
  "regions": []
 },
 {
  "length": 6900,
  "seq_id": "c00111_NODE_62..",
  "regions": []
 },
 {
  "length": 6876,
  "seq_id": "c00112_NODE_62..",
  "regions": []
 },
 {
  "length": 6855,
  "seq_id": "c00113_NODE_62..",
  "regions": []
 },
 {
  "length": 6847,
  "seq_id": "c00114_NODE_62..",
  "regions": []
 },
 {
  "length": 6763,
  "seq_id": "c00115_NODE_63..",
  "regions": []
 },
 {
  "length": 6642,
  "seq_id": "c00116_NODE_64..",
  "regions": []
 },
 {
  "length": 6639,
  "seq_id": "c00117_NODE_64..",
  "regions": []
 },
 {
  "length": 6638,
  "seq_id": "c00118_NODE_65..",
  "regions": []
 },
 {
  "length": 6611,
  "seq_id": "c00119_NODE_65..",
  "regions": []
 },
 {
  "length": 6548,
  "seq_id": "c00120_NODE_65..",
  "regions": []
 },
 {
  "length": 6446,
  "seq_id": "c00121_NODE_66..",
  "regions": []
 },
 {
  "length": 6355,
  "seq_id": "c00122_NODE_67..",
  "regions": []
 },
 {
  "length": 6331,
  "seq_id": "c00123_NODE_68..",
  "regions": []
 },
 {
  "length": 6258,
  "seq_id": "c00124_NODE_69..",
  "regions": []
 },
 {
  "length": 6143,
  "seq_id": "c00125_NODE_70..",
  "regions": []
 },
 {
  "length": 6132,
  "seq_id": "c00126_NODE_70..",
  "regions": []
 },
 {
  "length": 6096,
  "seq_id": "c00127_NODE_71..",
  "regions": []
 },
 {
  "length": 6086,
  "seq_id": "c00128_NODE_71..",
  "regions": []
 },
 {
  "length": 6061,
  "seq_id": "c00129_NODE_71..",
  "regions": []
 },
 {
  "length": 6045,
  "seq_id": "c00130_NODE_71..",
  "regions": []
 },
 {
  "length": 5922,
  "seq_id": "c00131_NODE_73..",
  "regions": []
 },
 {
  "length": 5825,
  "seq_id": "c00132_NODE_75..",
  "regions": []
 },
 {
  "length": 5755,
  "seq_id": "c00133_NODE_76..",
  "regions": []
 },
 {
  "length": 5720,
  "seq_id": "c00134_NODE_76..",
  "regions": []
 },
 {
  "length": 5708,
  "seq_id": "c00135_NODE_76..",
  "regions": []
 },
 {
  "length": 5680,
  "seq_id": "c00136_NODE_77..",
  "regions": []
 },
 {
  "length": 5672,
  "seq_id": "c00137_NODE_77..",
  "regions": []
 },
 {
  "length": 5612,
  "seq_id": "c00138_NODE_78..",
  "regions": []
 },
 {
  "length": 5606,
  "seq_id": "c00139_NODE_78..",
  "regions": []
 },
 {
  "length": 5585,
  "seq_id": "c00140_NODE_78..",
  "regions": []
 },
 {
  "length": 5551,
  "seq_id": "c00141_NODE_79..",
  "regions": []
 },
 {
  "length": 5525,
  "seq_id": "c00142_NODE_79..",
  "regions": []
 },
 {
  "length": 5481,
  "seq_id": "c00143_NODE_80..",
  "regions": []
 },
 {
  "length": 5470,
  "seq_id": "c00144_NODE_80..",
  "regions": []
 },
 {
  "length": 5415,
  "seq_id": "c00145_NODE_81..",
  "regions": []
 },
 {
  "length": 5358,
  "seq_id": "c00146_NODE_82..",
  "regions": []
 },
 {
  "length": 5338,
  "seq_id": "c00147_NODE_82..",
  "regions": []
 },
 {
  "length": 5316,
  "seq_id": "c00148_NODE_82..",
  "regions": []
 },
 {
  "length": 5288,
  "seq_id": "c00149_NODE_83..",
  "regions": []
 },
 {
  "length": 5193,
  "seq_id": "c00150_NODE_85..",
  "regions": []
 },
 {
  "length": 5164,
  "seq_id": "c00151_NODE_85..",
  "regions": []
 },
 {
  "length": 5144,
  "seq_id": "c00152_NODE_85..",
  "regions": []
 },
 {
  "length": 5139,
  "seq_id": "c00153_NODE_85..",
  "regions": []
 },
 {
  "length": 5138,
  "seq_id": "c00154_NODE_85..",
  "regions": []
 },
 {
  "length": 5095,
  "seq_id": "c00155_NODE_86..",
  "regions": []
 },
 {
  "length": 5086,
  "seq_id": "c00156_NODE_87..",
  "regions": []
 },
 {
  "length": 5054,
  "seq_id": "c00157_NODE_87..",
  "regions": []
 },
 {
  "length": 5047,
  "seq_id": "c00158_NODE_87..",
  "regions": []
 },
 {
  "length": 5034,
  "seq_id": "c00159_NODE_88..",
  "regions": []
 },
 {
  "length": 4981,
  "seq_id": "c00160_NODE_89..",
  "regions": []
 },
 {
  "length": 4921,
  "seq_id": "c00161_NODE_90..",
  "regions": []
 },
 {
  "length": 4890,
  "seq_id": "c00162_NODE_90..",
  "regions": []
 },
 {
  "length": 4874,
  "seq_id": "c00163_NODE_91..",
  "regions": []
 },
 {
  "length": 4844,
  "seq_id": "c00164_NODE_91..",
  "regions": []
 },
 {
  "length": 4813,
  "seq_id": "c00165_NODE_92..",
  "regions": []
 },
 {
  "length": 4810,
  "seq_id": "c00166_NODE_92..",
  "regions": []
 },
 {
  "length": 4782,
  "seq_id": "c00167_NODE_92..",
  "regions": []
 },
 {
  "length": 4757,
  "seq_id": "c00168_NODE_93..",
  "regions": []
 },
 {
  "length": 4753,
  "seq_id": "c00169_NODE_93..",
  "regions": []
 },
 {
  "length": 4676,
  "seq_id": "c00170_NODE_95..",
  "regions": []
 },
 {
  "length": 4635,
  "seq_id": "c00171_NODE_96..",
  "regions": []
 },
 {
  "length": 4609,
  "seq_id": "c00172_NODE_96..",
  "regions": []
 },
 {
  "length": 4580,
  "seq_id": "c00173_NODE_97..",
  "regions": []
 },
 {
  "length": 4547,
  "seq_id": "c00174_NODE_98..",
  "regions": []
 },
 {
  "length": 4456,
  "seq_id": "c00175_NODE_99..",
  "regions": []
 },
 {
  "length": 4443,
  "seq_id": "c00176_NODE_10..",
  "regions": []
 },
 {
  "length": 4412,
  "seq_id": "c00177_NODE_10..",
  "regions": []
 },
 {
  "length": 4410,
  "seq_id": "c00178_NODE_10..",
  "regions": []
 },
 {
  "length": 4383,
  "seq_id": "c00179_NODE_10..",
  "regions": []
 },
 {
  "length": 4361,
  "seq_id": "c00180_NODE_10..",
  "regions": []
 },
 {
  "length": 4340,
  "seq_id": "c00181_NODE_10..",
  "regions": []
 },
 {
  "length": 4335,
  "seq_id": "c00182_NODE_10..",
  "regions": []
 },
 {
  "length": 4164,
  "seq_id": "c00183_NODE_10..",
  "regions": []
 },
 {
  "length": 4073,
  "seq_id": "c00184_NODE_11..",
  "regions": []
 },
 {
  "length": 4051,
  "seq_id": "c00185_NODE_11..",
  "regions": []
 },
 {
  "length": 4029,
  "seq_id": "c00186_NODE_11..",
  "regions": []
 },
 {
  "length": 3980,
  "seq_id": "c00187_NODE_11..",
  "regions": []
 },
 {
  "length": 3950,
  "seq_id": "c00188_NODE_11..",
  "regions": []
 },
 {
  "length": 3913,
  "seq_id": "c00189_NODE_11..",
  "regions": []
 },
 {
  "length": 3890,
  "seq_id": "c00190_NODE_11..",
  "regions": []
 },
 {
  "length": 3889,
  "seq_id": "c00191_NODE_11..",
  "regions": []
 },
 {
  "length": 3870,
  "seq_id": "c00192_NODE_11..",
  "regions": []
 },
 {
  "length": 3858,
  "seq_id": "c00193_NODE_11..",
  "regions": []
 },
 {
  "length": 3830,
  "seq_id": "c00194_NODE_11..",
  "regions": []
 },
 {
  "length": 3828,
  "seq_id": "c00195_NODE_11..",
  "regions": []
 },
 {
  "length": 3826,
  "seq_id": "c00196_NODE_11..",
  "regions": []
 },
 {
  "length": 3810,
  "seq_id": "c00197_NODE_11..",
  "regions": []
 },
 {
  "length": 3795,
  "seq_id": "c00198_NODE_11..",
  "regions": []
 },
 {
  "length": 3794,
  "seq_id": "c00199_NODE_11..",
  "regions": []
 },
 {
  "length": 3760,
  "seq_id": "c00200_NODE_11..",
  "regions": []
 },
 {
  "length": 3704,
  "seq_id": "c00201_NODE_12..",
  "regions": []
 },
 {
  "length": 3692,
  "seq_id": "c00202_NODE_12..",
  "regions": []
 },
 {
  "length": 3624,
  "seq_id": "c00203_NODE_12..",
  "regions": []
 },
 {
  "length": 3619,
  "seq_id": "c00204_NODE_12..",
  "regions": []
 },
 {
  "length": 3594,
  "seq_id": "c00205_NODE_12..",
  "regions": []
 },
 {
  "length": 3583,
  "seq_id": "c00206_NODE_12..",
  "regions": []
 },
 {
  "length": 3556,
  "seq_id": "c00207_NODE_12..",
  "regions": []
 },
 {
  "length": 3541,
  "seq_id": "c00208_NODE_12..",
  "regions": []
 },
 {
  "length": 3464,
  "seq_id": "c00209_NODE_13..",
  "regions": []
 },
 {
  "length": 3447,
  "seq_id": "c00210_NODE_13..",
  "regions": []
 },
 {
  "length": 3423,
  "seq_id": "c00211_NODE_13..",
  "regions": []
 },
 {
  "length": 3402,
  "seq_id": "c00212_NODE_13..",
  "regions": []
 },
 {
  "length": 3381,
  "seq_id": "c00213_NODE_13..",
  "regions": []
 },
 {
  "length": 3344,
  "seq_id": "c00214_NODE_13..",
  "regions": []
 },
 {
  "length": 3331,
  "seq_id": "c00215_NODE_13..",
  "regions": []
 },
 {
  "length": 3328,
  "seq_id": "c00216_NODE_13..",
  "regions": []
 },
 {
  "length": 3288,
  "seq_id": "c00217_NODE_13..",
  "regions": []
 },
 {
  "length": 3258,
  "seq_id": "c00218_NODE_13..",
  "regions": []
 },
 {
  "length": 3254,
  "seq_id": "c00219_NODE_14..",
  "regions": []
 },
 {
  "length": 3251,
  "seq_id": "c00220_NODE_14..",
  "regions": []
 },
 {
  "length": 3246,
  "seq_id": "c00221_NODE_14..",
  "regions": []
 },
 {
  "length": 3172,
  "seq_id": "c00222_NODE_14..",
  "regions": []
 },
 {
  "length": 3168,
  "seq_id": "c00223_NODE_14..",
  "regions": []
 },
 {
  "length": 3123,
  "seq_id": "c00224_NODE_14..",
  "regions": []
 },
 {
  "length": 3091,
  "seq_id": "c00225_NODE_14..",
  "regions": []
 },
 {
  "length": 3032,
  "seq_id": "c00226_NODE_15..",
  "regions": []
 },
 {
  "length": 3030,
  "seq_id": "c00227_NODE_15..",
  "regions": []
 },
 {
  "length": 3016,
  "seq_id": "c00228_NODE_15..",
  "regions": []
 },
 {
  "length": 3007,
  "seq_id": "c00229_NODE_15..",
  "regions": []
 },
 {
  "length": 2995,
  "seq_id": "c00230_NODE_15..",
  "regions": []
 },
 {
  "length": 2957,
  "seq_id": "c00231_NODE_15..",
  "regions": []
 },
 {
  "length": 2953,
  "seq_id": "c00232_NODE_15..",
  "regions": []
 },
 {
  "length": 2949,
  "seq_id": "c00233_NODE_15..",
  "regions": []
 },
 {
  "length": 2940,
  "seq_id": "c00234_NODE_15..",
  "regions": []
 },
 {
  "length": 2833,
  "seq_id": "c00235_NODE_16..",
  "regions": []
 },
 {
  "length": 2831,
  "seq_id": "c00236_NODE_16..",
  "regions": []
 },
 {
  "length": 2813,
  "seq_id": "c00237_NODE_16..",
  "regions": []
 },
 {
  "length": 2788,
  "seq_id": "c00238_NODE_16..",
  "regions": []
 },
 {
  "length": 2769,
  "seq_id": "c00239_NODE_16..",
  "regions": []
 },
 {
  "length": 2730,
  "seq_id": "c00240_NODE_17..",
  "regions": []
 },
 {
  "length": 2722,
  "seq_id": "c00241_NODE_17..",
  "regions": []
 },
 {
  "length": 2714,
  "seq_id": "c00242_NODE_17..",
  "regions": []
 },
 {
  "length": 2708,
  "seq_id": "c00243_NODE_17..",
  "regions": []
 },
 {
  "length": 2706,
  "seq_id": "c00244_NODE_17..",
  "regions": []
 },
 {
  "length": 2689,
  "seq_id": "c00245_NODE_17..",
  "regions": []
 },
 {
  "length": 2685,
  "seq_id": "c00246_NODE_17..",
  "regions": []
 },
 {
  "length": 2681,
  "seq_id": "c00247_NODE_17..",
  "regions": []
 },
 {
  "length": 2681,
  "seq_id": "c00248_NODE_17..",
  "regions": []
 },
 {
  "length": 2636,
  "seq_id": "c00249_NODE_17..",
  "regions": []
 },
 {
  "length": 2594,
  "seq_id": "c00250_NODE_17..",
  "regions": []
 },
 {
  "length": 2546,
  "seq_id": "c00251_NODE_18..",
  "regions": []
 },
 {
  "length": 2512,
  "seq_id": "c00252_NODE_18..",
  "regions": []
 },
 {
  "length": 2504,
  "seq_id": "c00253_NODE_18..",
  "regions": []
 },
 {
  "length": 2499,
  "seq_id": "c00254_NODE_18..",
  "regions": []
 },
 {
  "length": 2451,
  "seq_id": "c00255_NODE_19..",
  "regions": []
 },
 {
  "length": 2443,
  "seq_id": "c00256_NODE_19..",
  "regions": []
 },
 {
  "length": 2426,
  "seq_id": "c00257_NODE_19..",
  "regions": []
 },
 {
  "length": 2360,
  "seq_id": "c00258_NODE_19..",
  "regions": []
 },
 {
  "length": 2329,
  "seq_id": "c00259_NODE_20..",
  "regions": []
 },
 {
  "length": 2316,
  "seq_id": "c00260_NODE_20..",
  "regions": []
 },
 {
  "length": 2266,
  "seq_id": "c00261_NODE_20..",
  "regions": []
 },
 {
  "length": 2253,
  "seq_id": "c00262_NODE_21..",
  "regions": []
 },
 {
  "length": 2236,
  "seq_id": "c00263_NODE_21..",
  "regions": []
 },
 {
  "length": 2200,
  "seq_id": "c00264_NODE_21..",
  "regions": []
 },
 {
  "length": 2170,
  "seq_id": "c00265_NODE_21..",
  "regions": [
   {
    "start": 1,
    "end": 2170,
    "idx": 1,
    "orfs": [
     {
      "start": 3,
      "end": 1271,
      "strand": -1,
      "locus_tag": "ctg265_1",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg265_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg265_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 1,271,\n (total: 1269 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MVHQYQLNGYNIVLDTCSGSVHVVDEVAYDVIAMYPEHTADEIVAAMLAKYGSRPDVTEEDLRQCIDDVTSLKENGKLWSPDVYKDMAFDFKNRNTVVKALCLHVAHSCNLSCSYCFASQGRYHGDRALMSFEVGKRAMDFLIENSGTRRNLEVDFFGGEPLMNFDMVKKLVAYCREQEKIHNKNFRFTMTTNGVLIDDDVIDFCNKECHNVVLSLDGRKEVNDRFRVDCAGNGSYDRIVPKFQEFVKKRGDKNYYMRGTYTHYNTDFTNDIFHMADLGFTELSMEPVVCDPSDPSALTEADLPILKEQYEILAKEMIKRDREGRGFTFYHYMIDLTGGPCIYKRISGCGSGTEYMAVTPWGDLYPCHQFVGDPKYLLGDIWKGVTNTAVRDEFKHCNAYARKECQDCWAKLYCSGGCAANSY&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00265_NODE_21..&amp;from=0&amp;to=2170\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MVHQYQLNGYNIVLDTCSGSVHVVDEVAYDVIAMYPEHTADEIVAAMLAKYGSRPDVTEEDLRQCIDDVTSLKENGKLWSPDVYKDMAFDFKNRNTVVKALCLHVAHSCNLSCSYCFASQGRYHGDRALMSFEVGKRAMDFLIENSGTRRNLEVDFFGGEPLMNFDMVKKLVAYCREQEKIHNKNFRFTMTTNGVLIDDDVIDFCNKECHNVVLSLDGRKEVNDRFRVDCAGNGSYDRIVPKFQEFVKKRGDKNYYMRGTYTHYNTDFTNDIFHMADLGFTELSMEPVVCDPSDPSALTEADLPILKEQYEILAKEMIKRDREGRGFTFYHYMIDLTGGPCIYKRISGCGSGTEYMAVTPWGDLYPCHQFVGDPKYLLGDIWKGVTNTAVRDEFKHCNAYARKECQDCWAKLYCSGGCAANSY\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGTACATCAGTATCAATTGAACGGTTATAACATCGTGCTGGACACCTGCAGCGGCTCGGTGCACGTTGTGGACGAGGTGGCCTACGATGTCATCGCCATGTACCCGGAGCATACCGCAGACGAGATCGTTGCCGCCATGCTGGCAAAATACGGCAGCCGCCCGGACGTGACCGAGGAGGATCTGCGCCAGTGCATCGACGACGTGACCAGCCTGAAGGAAAACGGCAAGCTGTGGAGCCCGGATGTCTATAAGGACATGGCTTTTGACTTCAAGAACCGCAACACCGTGGTAAAGGCTCTGTGCCTGCACGTTGCCCATAGCTGCAACCTGAGCTGCTCTTACTGCTTTGCCTCGCAGGGGCGCTACCACGGCGACCGCGCCCTGATGAGCTTTGAGGTGGGCAAGCGCGCCATGGACTTCCTCATCGAGAACAGCGGCACCCGCCGCAATCTGGAAGTGGACTTCTTTGGCGGTGAGCCGCTGATGAACTTTGATATGGTCAAAAAGCTGGTGGCCTACTGCCGCGAGCAGGAAAAGATCCATAACAAGAACTTCCGCTTTACCATGACCACCAACGGTGTGCTCATTGATGACGACGTCATCGACTTCTGCAACAAGGAGTGCCACAACGTGGTGCTGAGTCTGGACGGCCGCAAGGAGGTCAACGACCGTTTCCGCGTGGACTGCGCAGGCAACGGCAGCTACGACCGCATCGTGCCCAAGTTCCAGGAGTTCGTCAAGAAGCGCGGCGACAAGAACTACTATATGCGCGGCACCTATACCCACTATAACACCGACTTTACCAACGATATCTTCCACATGGCAGACCTCGGCTTTACCGAGCTGAGCATGGAGCCGGTGGTCTGCGACCCCAGCGACCCCAGCGCCCTGACCGAGGCCGATCTGCCCATCCTGAAGGAGCAGTACGAGATCCTTGCCAAGGAGATGATCAAGCGCGACCGCGAGGGCAGAGGCTTTACCTTCTACCACTACATGATCGACCTGACCGGCGGCCCCTGCATCTATAAGCGCATCTCCGGCTGCGGCTCCGGCACCGAGTACATGGCTGTTACCCCCTGGGGCGATCTGTACCCCTGCCACCAGTTCGTGGGCGACCCCAAGTACCTGCTGGGCGATATCTGGAAGGGCGTTACCAACACCGCTGTGCGGGATGAGTTCAAGCACTGCAACGCCTACGCCCGCAAGGAGTGTCAGGACTGCTGGGCAAAGCTGTACTGCTCCGGCGGCTGCGCTGCCAACTCCTAC\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 1339,
      "end": 1566,
      "strand": -1,
      "locus_tag": "ctg265_2",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg265_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg265_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,339 - 1,566,\n (total: 228 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SCIFF<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR03973<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VISYYKIKAYRNYVRRDKFLRVREVSIMERIKTIATRDLTKSVKTGGCGECQTSCQSACKTSCGVANQQCENSNK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00265_NODE_21..&amp;from=0&amp;to=2170\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VISYYKIKAYRNYVRRDKFLRVREVSIMERIKTIATRDLTKSVKTGGCGECQTSCQSACKTSCGVANQQCENSNK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGATATCCTATTACAAGATAAAAGCGTACCGGAACTATGTCCGGCGCGATAAATTTTTGAGAGTTAGAGAGGTTTCTATCATGGAGCGTATTAAGACTATTGCTACTCGTGACCTGACCAAGAGCGTTAAGACCGGTGGCTGCGGCGAGTGCCAGACTTCCTGCCAGTCCGCCTGCAAGACCTCCTGCGGCGTGGCTAACCAGCAGTGCGAGAACAGCAACAAGTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 1606,
      "end": 1893,
      "strand": -1,
      "locus_tag": "ctg265_3",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg265_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg265_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,606 - 1,893,\n (total: 288 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPERITQNAQTLLSPRVPRDTEHERYHPELEEELKECLFCLKRNEMMFDMEVDTDLIEQRIYERQALLCRYRYLLARARELGLHTVLTRYQPMGG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00265_NODE_21..&amp;from=0&amp;to=2170\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPERITQNAQTLLSPRVPRDTEHERYHPELEEELKECLFCLKRNEMMFDMEVDTDLIEQRIYERQALLCRYRYLLARARELGLHTVLTRYQPMGG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCGGAACGAATCACACAGAATGCCCAGACCCTGCTTTCGCCCCGCGTCCCGCGGGATACCGAGCACGAGCGCTACCATCCGGAACTGGAGGAGGAGCTGAAGGAATGCCTGTTCTGTTTGAAGCGCAACGAGATGATGTTTGATATGGAGGTGGATACGGACCTGATCGAGCAGCGCATCTACGAGCGGCAGGCGCTGCTGTGCCGCTACCGGTACTTACTGGCGCGCGCCCGGGAACTGGGGCTGCACACGGTGCTTACCCGATACCAGCCCATGGGCGGGTGA\">Copy to clipboard</span><br>\n</div>"
     }
    ],
    "clusters": [
     {
      "start": 2,
      "end": 1566,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 2170,
      "product": "ranthipeptide",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "ttaCodons": [],
    "type": "ranthipeptide",
    "products": [
     "ranthipeptide"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP ranthipeptide",
    "anchor": "r265c1"
   }
  ]
 },
 {
  "length": 2090,
  "seq_id": "c00266_NODE_22..",
  "regions": []
 },
 {
  "length": 2070,
  "seq_id": "c00267_NODE_23..",
  "regions": []
 },
 {
  "length": 2063,
  "seq_id": "c00268_NODE_23..",
  "regions": []
 },
 {
  "length": 2033,
  "seq_id": "c00269_NODE_23..",
  "regions": []
 },
 {
  "length": 2017,
  "seq_id": "c00270_NODE_23..",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r265c1"
 ],
 "r265c1": {
  "start": 1,
  "end": 2170,
  "idx": 1,
  "orfs": [
   {
    "start": 3,
    "end": 1271,
    "strand": -1,
    "locus_tag": "ctg265_1",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg265_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg265_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 1,271,\n (total: 1269 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MVHQYQLNGYNIVLDTCSGSVHVVDEVAYDVIAMYPEHTADEIVAAMLAKYGSRPDVTEEDLRQCIDDVTSLKENGKLWSPDVYKDMAFDFKNRNTVVKALCLHVAHSCNLSCSYCFASQGRYHGDRALMSFEVGKRAMDFLIENSGTRRNLEVDFFGGEPLMNFDMVKKLVAYCREQEKIHNKNFRFTMTTNGVLIDDDVIDFCNKECHNVVLSLDGRKEVNDRFRVDCAGNGSYDRIVPKFQEFVKKRGDKNYYMRGTYTHYNTDFTNDIFHMADLGFTELSMEPVVCDPSDPSALTEADLPILKEQYEILAKEMIKRDREGRGFTFYHYMIDLTGGPCIYKRISGCGSGTEYMAVTPWGDLYPCHQFVGDPKYLLGDIWKGVTNTAVRDEFKHCNAYARKECQDCWAKLYCSGGCAANSY&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00265_NODE_21..&amp;from=0&amp;to=2170\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MVHQYQLNGYNIVLDTCSGSVHVVDEVAYDVIAMYPEHTADEIVAAMLAKYGSRPDVTEEDLRQCIDDVTSLKENGKLWSPDVYKDMAFDFKNRNTVVKALCLHVAHSCNLSCSYCFASQGRYHGDRALMSFEVGKRAMDFLIENSGTRRNLEVDFFGGEPLMNFDMVKKLVAYCREQEKIHNKNFRFTMTTNGVLIDDDVIDFCNKECHNVVLSLDGRKEVNDRFRVDCAGNGSYDRIVPKFQEFVKKRGDKNYYMRGTYTHYNTDFTNDIFHMADLGFTELSMEPVVCDPSDPSALTEADLPILKEQYEILAKEMIKRDREGRGFTFYHYMIDLTGGPCIYKRISGCGSGTEYMAVTPWGDLYPCHQFVGDPKYLLGDIWKGVTNTAVRDEFKHCNAYARKECQDCWAKLYCSGGCAANSY\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGTACATCAGTATCAATTGAACGGTTATAACATCGTGCTGGACACCTGCAGCGGCTCGGTGCACGTTGTGGACGAGGTGGCCTACGATGTCATCGCCATGTACCCGGAGCATACCGCAGACGAGATCGTTGCCGCCATGCTGGCAAAATACGGCAGCCGCCCGGACGTGACCGAGGAGGATCTGCGCCAGTGCATCGACGACGTGACCAGCCTGAAGGAAAACGGCAAGCTGTGGAGCCCGGATGTCTATAAGGACATGGCTTTTGACTTCAAGAACCGCAACACCGTGGTAAAGGCTCTGTGCCTGCACGTTGCCCATAGCTGCAACCTGAGCTGCTCTTACTGCTTTGCCTCGCAGGGGCGCTACCACGGCGACCGCGCCCTGATGAGCTTTGAGGTGGGCAAGCGCGCCATGGACTTCCTCATCGAGAACAGCGGCACCCGCCGCAATCTGGAAGTGGACTTCTTTGGCGGTGAGCCGCTGATGAACTTTGATATGGTCAAAAAGCTGGTGGCCTACTGCCGCGAGCAGGAAAAGATCCATAACAAGAACTTCCGCTTTACCATGACCACCAACGGTGTGCTCATTGATGACGACGTCATCGACTTCTGCAACAAGGAGTGCCACAACGTGGTGCTGAGTCTGGACGGCCGCAAGGAGGTCAACGACCGTTTCCGCGTGGACTGCGCAGGCAACGGCAGCTACGACCGCATCGTGCCCAAGTTCCAGGAGTTCGTCAAGAAGCGCGGCGACAAGAACTACTATATGCGCGGCACCTATACCCACTATAACACCGACTTTACCAACGATATCTTCCACATGGCAGACCTCGGCTTTACCGAGCTGAGCATGGAGCCGGTGGTCTGCGACCCCAGCGACCCCAGCGCCCTGACCGAGGCCGATCTGCCCATCCTGAAGGAGCAGTACGAGATCCTTGCCAAGGAGATGATCAAGCGCGACCGCGAGGGCAGAGGCTTTACCTTCTACCACTACATGATCGACCTGACCGGCGGCCCCTGCATCTATAAGCGCATCTCCGGCTGCGGCTCCGGCACCGAGTACATGGCTGTTACCCCCTGGGGCGATCTGTACCCCTGCCACCAGTTCGTGGGCGACCCCAAGTACCTGCTGGGCGATATCTGGAAGGGCGTTACCAACACCGCTGTGCGGGATGAGTTCAAGCACTGCAACGCCTACGCCCGCAAGGAGTGTCAGGACTGCTGGGCAAAGCTGTACTGCTCCGGCGGCTGCGCTGCCAACTCCTAC\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 1339,
    "end": 1566,
    "strand": -1,
    "locus_tag": "ctg265_2",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg265_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg265_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,339 - 1,566,\n (total: 228 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SCIFF<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR03973<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VISYYKIKAYRNYVRRDKFLRVREVSIMERIKTIATRDLTKSVKTGGCGECQTSCQSACKTSCGVANQQCENSNK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00265_NODE_21..&amp;from=0&amp;to=2170\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VISYYKIKAYRNYVRRDKFLRVREVSIMERIKTIATRDLTKSVKTGGCGECQTSCQSACKTSCGVANQQCENSNK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGATATCCTATTACAAGATAAAAGCGTACCGGAACTATGTCCGGCGCGATAAATTTTTGAGAGTTAGAGAGGTTTCTATCATGGAGCGTATTAAGACTATTGCTACTCGTGACCTGACCAAGAGCGTTAAGACCGGTGGCTGCGGCGAGTGCCAGACTTCCTGCCAGTCCGCCTGCAAGACCTCCTGCGGCGTGGCTAACCAGCAGTGCGAGAACAGCAACAAGTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 1606,
    "end": 1893,
    "strand": -1,
    "locus_tag": "ctg265_3",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg265_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg265_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,606 - 1,893,\n (total: 288 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPERITQNAQTLLSPRVPRDTEHERYHPELEEELKECLFCLKRNEMMFDMEVDTDLIEQRIYERQALLCRYRYLLARARELGLHTVLTRYQPMGG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00265_NODE_21..&amp;from=0&amp;to=2170\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPERITQNAQTLLSPRVPRDTEHERYHPELEEELKECLFCLKRNEMMFDMEVDTDLIEQRIYERQALLCRYRYLLARARELGLHTVLTRYQPMGG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCGGAACGAATCACACAGAATGCCCAGACCCTGCTTTCGCCCCGCGTCCCGCGGGATACCGAGCACGAGCGCTACCATCCGGAACTGGAGGAGGAGCTGAAGGAATGCCTGTTCTGTTTGAAGCGCAACGAGATGATGTTTGATATGGAGGTGGATACGGACCTGATCGAGCAGCGCATCTACGAGCGGCAGGCGCTGCTGTGCCGCTACCGGTACTTACTGGCGCGCGCCCGGGAACTGGGGCTGCACACGGTGCTTACCCGATACCAGCCCATGGGCGGGTGA\">Copy to clipboard</span><br>\n</div>"
   }
  ],
  "clusters": [
   {
    "start": 2,
    "end": 1566,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 2170,
    "product": "ranthipeptide",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "ttaCodons": [],
  "type": "ranthipeptide",
  "products": [
   "ranthipeptide"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP ranthipeptide",
  "anchor": "r265c1"
 }
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
