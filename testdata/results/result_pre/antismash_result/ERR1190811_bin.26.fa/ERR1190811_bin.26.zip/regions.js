var recordData = [
 {
  "length": 61625,
  "seq_id": "c00001_NODE_29..",
  "regions": []
 },
 {
  "length": 52372,
  "seq_id": "c00002_NODE_41..",
  "regions": []
 },
 {
  "length": 51358,
  "seq_id": "c00003_NODE_43..",
  "regions": []
 },
 {
  "length": 43260,
  "seq_id": "c00004_NODE_58..",
  "regions": []
 },
 {
  "length": 42721,
  "seq_id": "c00005_NODE_60..",
  "regions": []
 },
 {
  "length": 37970,
  "seq_id": "c00006_NODE_72..",
  "regions": []
 },
 {
  "length": 35847,
  "seq_id": "c00007_NODE_78..",
  "regions": []
 },
 {
  "length": 35766,
  "seq_id": "c00008_NODE_79..",
  "regions": []
 },
 {
  "length": 34482,
  "seq_id": "c00009_NODE_83..",
  "regions": []
 },
 {
  "length": 34399,
  "seq_id": "c00010_NODE_84..",
  "regions": []
 },
 {
  "length": 33865,
  "seq_id": "c00011_NODE_86..",
  "regions": []
 },
 {
  "length": 33540,
  "seq_id": "c00012_NODE_88..",
  "regions": []
 },
 {
  "length": 33135,
  "seq_id": "c00013_NODE_89..",
  "regions": []
 },
 {
  "length": 31715,
  "seq_id": "c00014_NODE_96..",
  "regions": []
 },
 {
  "length": 31662,
  "seq_id": "c00015_NODE_97..",
  "regions": []
 },
 {
  "length": 31607,
  "seq_id": "c00016_NODE_97..",
  "regions": []
 },
 {
  "length": 30697,
  "seq_id": "c00017_NODE_10..",
  "regions": []
 },
 {
  "length": 30445,
  "seq_id": "c00018_NODE_10..",
  "regions": []
 },
 {
  "length": 30192,
  "seq_id": "c00019_NODE_10..",
  "regions": []
 },
 {
  "length": 29783,
  "seq_id": "c00020_NODE_10..",
  "regions": []
 },
 {
  "length": 29515,
  "seq_id": "c00021_NODE_10..",
  "regions": []
 },
 {
  "length": 29087,
  "seq_id": "c00022_NODE_11..",
  "regions": []
 },
 {
  "length": 29010,
  "seq_id": "c00023_NODE_11..",
  "regions": []
 },
 {
  "length": 28730,
  "seq_id": "c00024_NODE_11..",
  "regions": []
 },
 {
  "length": 28320,
  "seq_id": "c00025_NODE_11..",
  "regions": []
 },
 {
  "length": 27744,
  "seq_id": "c00026_NODE_11..",
  "regions": []
 },
 {
  "length": 27449,
  "seq_id": "c00027_NODE_12..",
  "regions": []
 },
 {
  "length": 27020,
  "seq_id": "c00028_NODE_12..",
  "regions": []
 },
 {
  "length": 26375,
  "seq_id": "c00029_NODE_12..",
  "regions": []
 },
 {
  "length": 25592,
  "seq_id": "c00030_NODE_13..",
  "regions": []
 },
 {
  "length": 25322,
  "seq_id": "c00031_NODE_13..",
  "regions": []
 },
 {
  "length": 25221,
  "seq_id": "c00032_NODE_13..",
  "regions": []
 },
 {
  "length": 25174,
  "seq_id": "c00033_NODE_13..",
  "regions": []
 },
 {
  "length": 25119,
  "seq_id": "c00034_NODE_13..",
  "regions": []
 },
 {
  "length": 24809,
  "seq_id": "c00035_NODE_14..",
  "regions": []
 },
 {
  "length": 24456,
  "seq_id": "c00036_NODE_14..",
  "regions": []
 },
 {
  "length": 24330,
  "seq_id": "c00037_NODE_14..",
  "regions": []
 },
 {
  "length": 23907,
  "seq_id": "c00038_NODE_14..",
  "regions": []
 },
 {
  "length": 23556,
  "seq_id": "c00039_NODE_15..",
  "regions": []
 },
 {
  "length": 22292,
  "seq_id": "c00040_NODE_16..",
  "regions": []
 },
 {
  "length": 21714,
  "seq_id": "c00041_NODE_16..",
  "regions": []
 },
 {
  "length": 21684,
  "seq_id": "c00042_NODE_16..",
  "regions": []
 },
 {
  "length": 21670,
  "seq_id": "c00043_NODE_16..",
  "regions": []
 },
 {
  "length": 20606,
  "seq_id": "c00044_NODE_17..",
  "regions": []
 },
 {
  "length": 20353,
  "seq_id": "c00045_NODE_18..",
  "regions": []
 },
 {
  "length": 20149,
  "seq_id": "c00046_NODE_18..",
  "regions": []
 },
 {
  "length": 19885,
  "seq_id": "c00047_NODE_18..",
  "regions": []
 },
 {
  "length": 19659,
  "seq_id": "c00048_NODE_19..",
  "regions": []
 },
 {
  "length": 19617,
  "seq_id": "c00049_NODE_19..",
  "regions": []
 },
 {
  "length": 19569,
  "seq_id": "c00050_NODE_19..",
  "regions": []
 },
 {
  "length": 18679,
  "seq_id": "c00051_NODE_20..",
  "regions": []
 },
 {
  "length": 18659,
  "seq_id": "c00052_NODE_20..",
  "regions": []
 },
 {
  "length": 18624,
  "seq_id": "c00053_NODE_20..",
  "regions": []
 },
 {
  "length": 18565,
  "seq_id": "c00054_NODE_20..",
  "regions": []
 },
 {
  "length": 18462,
  "seq_id": "c00055_NODE_20..",
  "regions": []
 },
 {
  "length": 17642,
  "seq_id": "c00056_NODE_21..",
  "regions": []
 },
 {
  "length": 17430,
  "seq_id": "c00057_NODE_22..",
  "regions": []
 },
 {
  "length": 17321,
  "seq_id": "c00058_NODE_22..",
  "regions": []
 },
 {
  "length": 17190,
  "seq_id": "c00059_NODE_22..",
  "regions": []
 },
 {
  "length": 16490,
  "seq_id": "c00060_NODE_24..",
  "regions": []
 },
 {
  "length": 16366,
  "seq_id": "c00061_NODE_24..",
  "regions": []
 },
 {
  "length": 15340,
  "seq_id": "c00062_NODE_26..",
  "regions": []
 },
 {
  "length": 15268,
  "seq_id": "c00063_NODE_26..",
  "regions": []
 },
 {
  "length": 15128,
  "seq_id": "c00064_NODE_26..",
  "regions": []
 },
 {
  "length": 14918,
  "seq_id": "c00065_NODE_26..",
  "regions": []
 },
 {
  "length": 14843,
  "seq_id": "c00066_NODE_26..",
  "regions": []
 },
 {
  "length": 14730,
  "seq_id": "c00067_NODE_27..",
  "regions": []
 },
 {
  "length": 14602,
  "seq_id": "c00068_NODE_27..",
  "regions": []
 },
 {
  "length": 14584,
  "seq_id": "c00069_NODE_27..",
  "regions": []
 },
 {
  "length": 14565,
  "seq_id": "c00070_NODE_27..",
  "regions": []
 },
 {
  "length": 14482,
  "seq_id": "c00071_NODE_27..",
  "regions": []
 },
 {
  "length": 14402,
  "seq_id": "c00072_NODE_27..",
  "regions": []
 },
 {
  "length": 14163,
  "seq_id": "c00073_NODE_28..",
  "regions": []
 },
 {
  "length": 13945,
  "seq_id": "c00074_NODE_28..",
  "regions": []
 },
 {
  "length": 13696,
  "seq_id": "c00075_NODE_29..",
  "regions": []
 },
 {
  "length": 13648,
  "seq_id": "c00076_NODE_29..",
  "regions": []
 },
 {
  "length": 13633,
  "seq_id": "c00077_NODE_29..",
  "regions": []
 },
 {
  "length": 13557,
  "seq_id": "c00078_NODE_29..",
  "regions": []
 },
 {
  "length": 13237,
  "seq_id": "c00079_NODE_30..",
  "regions": []
 },
 {
  "length": 13217,
  "seq_id": "c00080_NODE_30..",
  "regions": []
 },
 {
  "length": 13061,
  "seq_id": "c00081_NODE_31..",
  "regions": []
 },
 {
  "length": 13058,
  "seq_id": "c00082_NODE_31..",
  "regions": []
 },
 {
  "length": 12800,
  "seq_id": "c00083_NODE_32..",
  "regions": []
 },
 {
  "length": 12676,
  "seq_id": "c00084_NODE_32..",
  "regions": []
 },
 {
  "length": 12591,
  "seq_id": "c00085_NODE_32..",
  "regions": []
 },
 {
  "length": 12582,
  "seq_id": "c00086_NODE_32..",
  "regions": []
 },
 {
  "length": 12537,
  "seq_id": "c00087_NODE_32..",
  "regions": []
 },
 {
  "length": 12500,
  "seq_id": "c00088_NODE_32..",
  "regions": []
 },
 {
  "length": 12439,
  "seq_id": "c00089_NODE_33..",
  "regions": []
 },
 {
  "length": 12405,
  "seq_id": "c00090_NODE_33..",
  "regions": []
 },
 {
  "length": 11879,
  "seq_id": "c00091_NODE_34..",
  "regions": []
 },
 {
  "length": 11623,
  "seq_id": "c00092_NODE_35..",
  "regions": []
 },
 {
  "length": 11571,
  "seq_id": "c00093_NODE_35..",
  "regions": []
 },
 {
  "length": 11382,
  "seq_id": "c00094_NODE_36..",
  "regions": []
 },
 {
  "length": 11367,
  "seq_id": "c00095_NODE_36..",
  "regions": []
 },
 {
  "length": 11278,
  "seq_id": "c00096_NODE_36..",
  "regions": []
 },
 {
  "length": 11269,
  "seq_id": "c00097_NODE_36..",
  "regions": []
 },
 {
  "length": 11068,
  "seq_id": "c00098_NODE_37..",
  "regions": []
 },
 {
  "length": 11004,
  "seq_id": "c00099_NODE_37..",
  "regions": []
 },
 {
  "length": 10945,
  "seq_id": "c00100_NODE_38..",
  "regions": []
 },
 {
  "length": 10822,
  "seq_id": "c00101_NODE_38..",
  "regions": []
 },
 {
  "length": 10791,
  "seq_id": "c00102_NODE_38..",
  "regions": []
 },
 {
  "length": 10664,
  "seq_id": "c00103_NODE_39..",
  "regions": []
 },
 {
  "length": 10658,
  "seq_id": "c00104_NODE_39..",
  "regions": []
 },
 {
  "length": 10570,
  "seq_id": "c00105_NODE_39..",
  "regions": []
 },
 {
  "length": 10530,
  "seq_id": "c00106_NODE_39..",
  "regions": []
 },
 {
  "length": 10245,
  "seq_id": "c00107_NODE_40..",
  "regions": []
 },
 {
  "length": 10171,
  "seq_id": "c00108_NODE_41..",
  "regions": []
 },
 {
  "length": 10123,
  "seq_id": "c00109_NODE_41..",
  "regions": []
 },
 {
  "length": 10099,
  "seq_id": "c00110_NODE_41..",
  "regions": []
 },
 {
  "length": 10093,
  "seq_id": "c00111_NODE_41..",
  "regions": []
 },
 {
  "length": 10067,
  "seq_id": "c00112_NODE_41..",
  "regions": []
 },
 {
  "length": 10050,
  "seq_id": "c00113_NODE_41..",
  "regions": []
 },
 {
  "length": 9940,
  "seq_id": "c00114_NODE_42..",
  "regions": []
 },
 {
  "length": 9531,
  "seq_id": "c00115_NODE_44..",
  "regions": []
 },
 {
  "length": 9497,
  "seq_id": "c00116_NODE_44..",
  "regions": []
 },
 {
  "length": 9487,
  "seq_id": "c00117_NODE_44..",
  "regions": []
 },
 {
  "length": 9446,
  "seq_id": "c00118_NODE_44..",
  "regions": [
   {
    "start": 1,
    "end": 9446,
    "idx": 1,
    "orfs": [
     {
      "start": 48,
      "end": 2444,
      "strand": 1,
      "locus_tag": "ctg118_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 48 - 2,444,\n (total: 2397 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKQQNRLYLIIYVAALLMLSGQLITGCSSTSALKEDEQLFTGLVPIEYKNYEKGTYADSTITEMEYALASAPNGALFGSSYYRTPFPVRLWIWNAFSQSDGALAKWITKVFGSKPKLMANVNPQLRAQVAEHQLDKYGYFNGKVTYDVLTQSNPKKAKVAYQVDFGHLWTLDSMAYLNFPAKSKQFIDASMNKALIRKGSPFNVANMESERQRITRLFRNRGYYFYQNSYASYLADTVNVPGKVQLRLMMADSVDDRATRQWYIGKIHVNFRKQYMEELKDSFVRSYLSFHYNGRKMPIRPGIVLQSLRLRPRELYRVRTEERAKTGLQEMGLFSYSSIQFSPRSVQTLDSLGNVVYRDTLDANIDLVFDKPYDFYVEANARGKTTGRVGPELVVGLTKRNAFHGGEKLTVNLHGSHEWQTISQAGGGSTRINSYEYGSDVSVEFPRIITPWNMFRTMEQNERRYRAGHMPTKYRGVPTTTIKASMNVLNRASYFRRHVAAGELTYAWSTSYQHQHSFSPLILSYEFMNSRTAAFDSILTLHPYLQISMRDQFVPKMSYTYTYRSPRRYRHPITWSTTISEAANILSLGYMAAGKGWNEKDKKMFKNPFAQFLKLETDFVKYWRIPQDGTLVGHVNAGIIWSYGNAENAPYYEQFYIGGANSVRAFNVRSIGPGRYQPTNSKYSYIDQTGDIKYLMNLEYRQKVWGDLYGALFLDAGNVWTLRNHEYSPLGKFDVDKFFRQLAVGTGVGVRYDMGMFVIRVDWGIGLHVPYDTGKNGFYNIRRFKDAQSLHFAVGYPF&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKQQNRLYLIIYVAALLMLSGQLITGCSSTSALKEDEQLFTGLVPIEYKNYEKGTYADSTITEMEYALASAPNGALFGSSYYRTPFPVRLWIWNAFSQSDGALAKWITKVFGSKPKLMANVNPQLRAQVAEHQLDKYGYFNGKVTYDVLTQSNPKKAKVAYQVDFGHLWTLDSMAYLNFPAKSKQFIDASMNKALIRKGSPFNVANMESERQRITRLFRNRGYYFYQNSYASYLADTVNVPGKVQLRLMMADSVDDRATRQWYIGKIHVNFRKQYMEELKDSFVRSYLSFHYNGRKMPIRPGIVLQSLRLRPRELYRVRTEERAKTGLQEMGLFSYSSIQFSPRSVQTLDSLGNVVYRDTLDANIDLVFDKPYDFYVEANARGKTTGRVGPELVVGLTKRNAFHGGEKLTVNLHGSHEWQTISQAGGGSTRINSYEYGSDVSVEFPRIITPWNMFRTMEQNERRYRAGHMPTKYRGVPTTTIKASMNVLNRASYFRRHVAAGELTYAWSTSYQHQHSFSPLILSYEFMNSRTAAFDSILTLHPYLQISMRDQFVPKMSYTYTYRSPRRYRHPITWSTTISEAANILSLGYMAAGKGWNEKDKKMFKNPFAQFLKLETDFVKYWRIPQDGTLVGHVNAGIIWSYGNAENAPYYEQFYIGGANSVRAFNVRSIGPGRYQPTNSKYSYIDQTGDIKYLMNLEYRQKVWGDLYGALFLDAGNVWTLRNHEYSPLGKFDVDKFFRQLAVGTGVGVRYDMGMFVIRVDWGIGLHVPYDTGKNGFYNIRRFKDAQSLHFAVGYPF\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAACAGCAGAACAGGTTATACCTTATTATATATGTGGCAGCATTGCTGATGTTGTCGGGGCAGCTCATAACGGGTTGCTCTTCAACCAGTGCGCTGAAAGAAGACGAGCAGCTGTTTACGGGTCTGGTACCTATCGAGTATAAGAACTACGAGAAGGGAACTTATGCTGATTCTACCATCACCGAGATGGAGTATGCCCTGGCTTCGGCTCCGAACGGTGCCTTGTTTGGGAGCAGCTATTACCGCACACCGTTCCCTGTGCGCCTGTGGATATGGAATGCTTTCTCTCAGTCGGATGGAGCACTGGCTAAGTGGATAACCAAGGTATTCGGTTCCAAACCTAAGCTGATGGCGAATGTGAATCCGCAACTCCGTGCCCAGGTAGCCGAGCATCAGCTCGATAAATATGGCTATTTTAACGGTAAGGTGACTTATGATGTGCTGACACAGAGCAATCCGAAGAAGGCGAAGGTTGCCTATCAGGTAGACTTCGGTCATCTCTGGACGCTTGATTCTATGGCTTATCTCAACTTCCCAGCCAAGAGCAAGCAGTTTATAGATGCTTCCATGAACAAGGCGCTCATACGGAAGGGGAGTCCTTTCAATGTCGCCAACATGGAATCGGAACGTCAGCGTATCACCCGTCTGTTCCGCAACAGGGGCTATTATTTCTATCAGAACAGTTATGCTTCTTATCTTGCCGATACCGTGAATGTGCCCGGCAAGGTGCAGTTGCGGCTGATGATGGCAGACAGCGTGGACGATAGGGCTACCCGCCAGTGGTATATCGGAAAGATTCATGTTAATTTCAGAAAGCAGTATATGGAGGAGTTGAAGGATTCCTTTGTGCGCAGCTATCTGAGTTTCCATTATAATGGAAGAAAGATGCCGATACGTCCGGGCATCGTTTTGCAGAGTCTGCGCCTGCGTCCCCGTGAACTGTATCGGGTACGTACCGAGGAGCGTGCCAAGACCGGACTCCAGGAGATGGGACTCTTCAGCTATTCCAGCATCCAGTTCTCTCCCCGTTCGGTGCAGACCCTAGACAGTCTGGGCAATGTCGTATATCGTGATACCTTGGATGCCAATATCGATCTGGTATTCGACAAGCCATACGATTTCTATGTCGAGGCAAATGCCCGCGGTAAAACGACCGGTAGAGTAGGACCGGAGTTGGTAGTGGGTCTTACCAAGCGCAATGCTTTTCATGGAGGCGAGAAACTTACTGTCAACCTGCATGGTTCGCATGAGTGGCAAACCATCAGTCAGGCTGGTGGAGGTTCTACCCGCATCAATTCCTATGAATACGGATCGGATGTTTCCGTAGAGTTCCCTCGCATCATCACGCCTTGGAATATGTTCAGAACGATGGAGCAGAATGAGCGCAGATACCGTGCCGGGCATATGCCTACCAAATATCGGGGTGTGCCAACTACTACCATCAAGGCTTCGATGAATGTGCTGAACAGAGCCAGCTATTTCCGACGTCATGTGGCAGCGGGCGAGTTAACCTATGCGTGGTCTACCTCTTACCAGCATCAGCATTCTTTCAGCCCGCTGATTCTCTCTTATGAGTTTATGAACAGCCGCACAGCCGCTTTCGATAGCATCCTCACCCTGCATCCTTATCTTCAGATATCGATGCGCGACCAGTTTGTACCTAAGATGAGTTACACCTATACTTATCGCAGTCCGCGCCGTTACCGCCATCCTATCACCTGGTCAACCACCATCAGCGAGGCAGCCAATATCCTTTCGCTCGGTTACATGGCGGCCGGAAAGGGATGGAACGAGAAAGACAAGAAGATGTTCAAGAATCCGTTTGCTCAGTTTCTGAAACTGGAGACAGATTTCGTGAAATATTGGCGTATCCCCCAGGATGGTACGCTGGTGGGACATGTCAATGCCGGCATTATCTGGAGTTATGGCAATGCCGAGAATGCTCCTTATTATGAGCAGTTCTATATCGGTGGTGCCAACAGTGTGCGAGCCTTTAATGTGAGAAGCATCGGACCGGGCAGATACCAGCCTACCAACAGCAAGTATTCGTATATCGACCAGACGGGCGACATCAAGTATCTGATGAATCTGGAATACCGTCAGAAGGTATGGGGCGATCTCTATGGAGCCCTTTTCCTGGATGCAGGTAATGTGTGGACCTTACGCAACCATGAGTACAGTCCGCTCGGCAAGTTTGATGTAGACAAGTTTTTCCGGCAGCTGGCGGTAGGCACCGGTGTCGGTGTGCGTTATGACATGGGTATGTTTGTGATACGTGTCGACTGGGGTATCGGTCTGCATGTTCCTTACGATACCGGCAAGAATGGCTTCTATAACATCCGTCGGTTCAAGGATGCCCAGAGTCTGCATTTCGCTGTGGGTTATCCTTTCTAG\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 2632,
      "end": 3543,
      "strand": 1,
      "locus_tag": "ctg118_2",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,632 - 3,543,\n (total: 912 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKPTLLLLAAGMGSRYGGLKQLDGLGPNGETIMDYSIYDAIQAGFGKIVFVIRKDFEDQFREKILSKYEGHIPAELCFQALDDLPEGFSVPEGREKPWGTNHAVLMAKDIIKEPFCVINCDDFYNRDCFMVIGKFLSELPEGSKNRYAMVGFRVGNTLSENGTVARGICSKDADENLTTCVERTEIMRIDGKVSYKDEQGEWVAVGDNTPVSMNVWGFTPDYFQHSEEYFKEFLSDPKNMENKKAEFFIPLMVNKLINEGTATVKVLDTTSKWFGVTYAADRQSVVDKIQHLIDEGVYPNKLF&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKPTLLLLAAGMGSRYGGLKQLDGLGPNGETIMDYSIYDAIQAGFGKIVFVIRKDFEDQFREKILSKYEGHIPAELCFQALDDLPEGFSVPEGREKPWGTNHAVLMAKDIIKEPFCVINCDDFYNRDCFMVIGKFLSELPEGSKNRYAMVGFRVGNTLSENGTVARGICSKDADENLTTCVERTEIMRIDGKVSYKDEQGEWVAVGDNTPVSMNVWGFTPDYFQHSEEYFKEFLSDPKNMENKKAEFFIPLMVNKLINEGTATVKVLDTTSKWFGVTYAADRQSVVDKIQHLIDEGVYPNKLF\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAACCTACGTTATTGCTTTTGGCTGCCGGTATGGGTAGCCGTTATGGTGGTTTGAAACAGCTTGATGGTCTGGGTCCTAATGGTGAGACTATCATGGACTACAGCATCTATGATGCTATTCAGGCTGGTTTCGGAAAGATCGTATTCGTTATCCGCAAGGACTTCGAAGATCAGTTCCGTGAGAAGATTCTTTCAAAGTATGAGGGTCATATTCCTGCAGAACTTTGCTTCCAGGCATTGGATGATCTCCCAGAGGGATTCTCAGTTCCAGAAGGTCGTGAGAAACCATGGGGTACAAACCATGCTGTCCTGATGGCAAAGGATATCATCAAGGAACCTTTCTGCGTAATCAACTGCGATGACTTCTACAACCGCGATTGCTTCATGGTAATCGGCAAGTTCCTCTCTGAACTTCCAGAGGGCAGCAAGAACCGTTACGCCATGGTAGGTTTCCGTGTAGGTAATACCTTGAGCGAGAATGGTACCGTAGCTCGCGGCATCTGCTCTAAGGATGCTGATGAGAACTTGACAACCTGTGTAGAGCGTACCGAGATCATGCGTATTGATGGTAAGGTATCTTACAAGGACGAGCAGGGCGAGTGGGTTGCTGTTGGCGACAATACTCCTGTTTCCATGAACGTTTGGGGCTTCACACCTGATTACTTCCAGCATAGTGAGGAGTACTTCAAGGAGTTCTTGAGTGATCCTAAGAATATGGAAAACAAGAAGGCTGAGTTCTTCATCCCATTGATGGTCAACAAGCTCATCAATGAGGGTACAGCTACCGTTAAGGTGCTCGATACTACCAGCAAGTGGTTTGGTGTAACTTATGCAGCCGACCGCCAGAGTGTTGTTGATAAGATCCAGCATCTTATCGATGAGGGTGTTTATCCAAACAAGCTCTTCTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 3553,
      "end": 4593,
      "strand": 1,
      "locus_tag": "ctg118_3",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,553 - 4,593,\n (total: 1041 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDININILTDQEAAILRETIAASHRIVVCAHKSPDGDAIGSSLGWAGYLRSLGKKVDICVPDMVPDSISWLPGAAGILRYDRQPELVQRAFDEADLVCCVDFSSEGRLDEMDHLLLGCKTQRVIIDHHLSPNLEAKLLVSQPHASSASDLVFRVVWQLGGFPQMDQTWATCIYCGMMTDTGGFTYNSTQPYIYYIICLLLTKNIDKDKIYRNVFNNARIPAVRFRGYLMNEKLQVVEGLHASFYTVTRKELKKYDFIKGDLEGLVNVPLTIKGHKLSISLREDTDIDNRILVSLRSVDDFPCNKMAAEFFNGGGHRNASGGKLLCSIQEAEQIALKAILAYADMLK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDININILTDQEAAILRETIAASHRIVVCAHKSPDGDAIGSSLGWAGYLRSLGKKVDICVPDMVPDSISWLPGAAGILRYDRQPELVQRAFDEADLVCCVDFSSEGRLDEMDHLLLGCKTQRVIIDHHLSPNLEAKLLVSQPHASSASDLVFRVVWQLGGFPQMDQTWATCIYCGMMTDTGGFTYNSTQPYIYYIICLLLTKNIDKDKIYRNVFNNARIPAVRFRGYLMNEKLQVVEGLHASFYTVTRKELKKYDFIKGDLEGLVNVPLTIKGHKLSISLREDTDIDNRILVSLRSVDDFPCNKMAAEFFNGGGHRNASGGKLLCSIQEAEQIALKAILAYADMLK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGATATAAACATTAATATATTGACAGATCAGGAAGCCGCTATTCTCCGAGAGACGATAGCGGCTTCTCATCGTATTGTCGTCTGTGCACATAAGTCGCCAGACGGTGATGCCATCGGCTCTTCTTTGGGATGGGCTGGTTATCTTCGCTCTTTGGGCAAGAAAGTTGACATTTGTGTGCCGGATATGGTACCGGATTCTATTTCCTGGTTGCCTGGAGCTGCCGGTATCCTGCGATATGACAGACAGCCTGAACTGGTGCAGCGAGCTTTCGATGAAGCCGACCTGGTATGCTGTGTTGACTTTAGCAGTGAGGGACGTCTTGATGAGATGGATCATTTATTGTTGGGTTGCAAGACTCAGCGTGTCATCATCGACCACCATCTGTCTCCTAATCTTGAGGCTAAGCTGCTGGTTTCGCAGCCACATGCCAGCAGTGCCAGCGACCTGGTATTCCGTGTAGTCTGGCAGTTGGGAGGTTTCCCACAGATGGATCAGACCTGGGCTACCTGCATCTATTGCGGCATGATGACCGATACGGGCGGTTTCACCTATAATTCTACCCAGCCTTATATCTATTACATCATCTGCTTGCTGCTTACCAAGAACATCGACAAGGATAAGATTTACCGTAATGTCTTCAATAATGCCCGCATTCCGGCAGTCCGGTTTCGTGGCTATCTGATGAATGAAAAGTTGCAGGTAGTAGAGGGTCTTCATGCCAGTTTCTATACAGTGACCCGTAAAGAATTGAAGAAGTATGACTTTATCAAGGGCGACCTGGAAGGACTGGTGAACGTGCCTCTTACCATCAAGGGACACAAACTCTCCATTTCTCTTCGTGAAGATACGGATATAGACAATCGCATATTGGTAAGTCTCCGTTCGGTAGACGATTTCCCATGCAATAAGATGGCAGCCGAGTTCTTCAATGGTGGCGGTCATCGCAATGCTTCTGGCGGCAAATTGCTTTGCAGCATACAGGAGGCAGAGCAGATAGCACTGAAGGCTATCCTGGCATACGCCGATATGCTGAAGTAG\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 4757,
      "end": 5455,
      "strand": 1,
      "locus_tag": "ctg118_4",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,757 - 5,455,\n (total: 699 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKKFLFAMIAFAAVLSFAACNDSETYKDMRDRELDSISSFLRKENIKVISEDEFNRRWKNNEKLTDTAKNNNEWVLFNSNGIYMQVIDQGCGDYIKKGTSVDVLVRFDEYNLSYAAEMSDKCLTLSNKVPAYSYYVDKISVTNTSGTFTGSFVDPKASLMANTYNSSNYGSVSSTVPSGWLIPFTWIKIGRPKTDDERIAHIRLLVPHSYGTTSASGSVQACVYDMTLQKGR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKKFLFAMIAFAAVLSFAACNDSETYKDMRDRELDSISSFLRKENIKVISEDEFNRRWKNNEKLTDTAKNNNEWVLFNSNGIYMQVIDQGCGDYIKKGTSVDVLVRFDEYNLSYAAEMSDKCLTLSNKVPAYSYYVDKISVTNTSGTFTGSFVDPKASLMANTYNSSNYGSVSSTVPSGWLIPFTWIKIGRPKTDDERIAHIRLLVPHSYGTTSASGSVQACVYDMTLQKGR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGAAATTTTTGTTTGCAATGATTGCTTTTGCGGCTGTTTTATCGTTTGCCGCATGCAATGATAGTGAGACTTATAAGGACATGCGCGACAGAGAGCTCGATTCTATCAGCTCTTTCTTGCGTAAGGAAAATATTAAGGTCATCTCTGAGGATGAGTTCAACAGACGTTGGAAAAATAATGAAAAACTGACGGATACAGCAAAGAACAACAACGAATGGGTACTTTTCAACAGTAACGGTATCTACATGCAGGTGATTGACCAGGGATGTGGCGACTATATCAAGAAAGGTACATCGGTAGATGTATTGGTCCGCTTTGATGAGTATAACCTTTCGTATGCTGCTGAAATGAGCGATAAGTGTCTCACGCTTTCAAACAAAGTTCCTGCTTATTCCTATTATGTAGATAAGATAAGCGTTACCAATACTTCCGGTACATTCACCGGTTCTTTCGTTGATCCTAAAGCCAGTCTGATGGCCAATACATATAATTCATCCAATTATGGCAGTGTAAGTTCTACCGTGCCTAGCGGTTGGCTCATACCATTCACCTGGATTAAGATAGGCAGACCGAAGACTGATGATGAACGCATCGCTCATATCCGTTTGCTCGTACCTCACTCTTACGGTACCACATCGGCATCGGGCAGTGTGCAGGCATGTGTCTACGACATGACCCTGCAGAAAGGAAGATAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 5476,
      "end": 6867,
      "strand": 1,
      "locus_tag": "ctg118_5",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,476 - 6,867,\n (total: 1392 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTLIKSISGIRGTIGGPAGDTLNPLDIVKFTSAYATFIRRSGASESNTIVVGRDARISGEMVKNVVCGTLMGMGYDVLNIGLATTPTTELAVTMSGAAGGIIITASHNPRQWNALKLLNEKGEFLTAVNGNEVLGIAEKEDFDYADVDHLGKYTEDNTFNKRHIDSVLALKLVDVEAIKNAHFKVCVDSINSVGGVILPELLDALGVAYTFLNGEPTGDFAHNPEPLEKNLGGIMDELKKGGYDMGIVVDPDVDRLAFICEDGKMFGEEYTLVSVADYVLGKTPGNTVSNLSSTRALRDVTEKHGGKYTAAAVGEVNVTTKMKDVHAVIGGEGNGGVIYPESHYGRDALVGIALFLSSLAHKGCKVSELRASFPNYFIAKNRIDLTPSTDVDAILVKVKEMYGKEKDVTVTDIDGVKLDFPDKWVHLRKSNTEPIIRVYSEASTMEQADELGKKLMQVVYDMQ&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTLIKSISGIRGTIGGPAGDTLNPLDIVKFTSAYATFIRRSGASESNTIVVGRDARISGEMVKNVVCGTLMGMGYDVLNIGLATTPTTELAVTMSGAAGGIIITASHNPRQWNALKLLNEKGEFLTAVNGNEVLGIAEKEDFDYADVDHLGKYTEDNTFNKRHIDSVLALKLVDVEAIKNAHFKVCVDSINSVGGVILPELLDALGVAYTFLNGEPTGDFAHNPEPLEKNLGGIMDELKKGGYDMGIVVDPDVDRLAFICEDGKMFGEEYTLVSVADYVLGKTPGNTVSNLSSTRALRDVTEKHGGKYTAAAVGEVNVTTKMKDVHAVIGGEGNGGVIYPESHYGRDALVGIALFLSSLAHKGCKVSELRASFPNYFIAKNRIDLTPSTDVDAILVKVKEMYGKEKDVTVTDIDGVKLDFPDKWVHLRKSNTEPIIRVYSEASTMEQADELGKKLMQVVYDMQ\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACACTGATTAAGTCAATTTCTGGTATCCGCGGTACTATCGGCGGTCCAGCGGGCGATACTTTGAATCCGCTCGATATCGTAAAGTTCACTTCAGCATACGCTACCTTCATTCGCCGTAGCGGTGCTTCAGAGAGTAATACCATCGTTGTAGGCCGTGATGCGCGCATCTCTGGCGAGATGGTAAAGAATGTGGTTTGTGGAACCCTCATGGGTATGGGCTACGATGTGCTGAACATCGGTCTGGCTACTACTCCTACCACCGAACTTGCTGTTACCATGAGTGGTGCGGCCGGCGGTATCATCATCACAGCTTCTCACAACCCACGCCAGTGGAATGCCCTCAAGCTCCTCAACGAGAAGGGTGAGTTCCTCACAGCAGTTAATGGTAACGAGGTGCTGGGTATCGCAGAGAAGGAAGACTTCGACTATGCGGATGTGGATCATCTCGGAAAATATACTGAAGACAATACCTTCAACAAGCGCCATATCGACTCCGTACTTGCTTTGAAGCTCGTAGATGTCGAAGCAATCAAGAATGCCCACTTCAAGGTTTGTGTAGATTCCATCAACTCAGTTGGTGGCGTTATACTTCCAGAGTTGCTCGATGCGCTCGGTGTAGCATATACTTTCCTCAATGGTGAGCCTACAGGCGACTTTGCTCATAATCCGGAGCCATTGGAGAAGAACCTCGGTGGTATCATGGATGAGTTGAAGAAGGGTGGCTACGATATGGGTATCGTTGTAGACCCTGATGTTGACCGTCTGGCTTTCATCTGCGAAGATGGCAAGATGTTTGGCGAAGAGTATACCTTGGTAAGTGTGGCAGATTACGTATTGGGCAAGACTCCAGGTAATACCGTCAGCAACCTTTCATCTACCCGTGCCCTCCGTGATGTTACAGAGAAGCATGGTGGCAAGTACACCGCAGCTGCTGTAGGCGAGGTGAATGTAACTACCAAGATGAAGGATGTTCACGCTGTTATCGGTGGTGAAGGCAATGGTGGAGTTATCTATCCAGAGAGCCATTACGGTCGTGATGCCCTCGTTGGTATCGCCCTCTTCCTGAGCAGTCTGGCTCACAAGGGCTGCAAGGTGAGCGAGCTCCGTGCCAGCTTCCCTAACTATTTCATCGCCAAGAACCGCATCGACCTGACTCCATCTACCGATGTAGATGCTATCCTCGTGAAGGTTAAGGAGATGTATGGTAAGGAGAAGGATGTCACCGTAACAGATATCGATGGCGTCAAGCTCGATTTCCCTGACAAGTGGGTTCACCTCCGCAAGAGTAATACCGAGCCTATCATCCGCGTATATAGCGAGGCCTCTACTATGGAGCAGGCTGATGAACTGGGCAAGAAGCTCATGCAGGTGGTTTACGATATGCAGTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 7119,
      "end": 8042,
      "strand": 1,
      "locus_tag": "ctg118_6",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,119 - 8,042,\n (total: 924 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MESIIKYYQVAHVGFSLSYPDSSQEMMVVLLEPYQAFECDEQVASAALTSFSLTLNESGEELRKPAGFKEECRQDEEGQLIISGSLGEKQKAFLMAMTDMKSILVTGHDYQHSSLLVPAGTFSQKSAFGSLKATVDTSLMLLYAMRSAAGDTLLFHSSTIVKDGKAYLFLGKSGTGKSTHSGLWLKHIDGTRLLNDDNPVVYISHEGTPMVSGSPWSGKTPCYKNEEYPIGAIVQLRQAPENKIRKQTVIESYVSIKTSVSGKAWEKEIADGQHQTIEKLIGATRLYQLDCLPDAGAALLCSQTISQ&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MESIIKYYQVAHVGFSLSYPDSSQEMMVVLLEPYQAFECDEQVASAALTSFSLTLNESGEELRKPAGFKEECRQDEEGQLIISGSLGEKQKAFLMAMTDMKSILVTGHDYQHSSLLVPAGTFSQKSAFGSLKATVDTSLMLLYAMRSAAGDTLLFHSSTIVKDGKAYLFLGKSGTGKSTHSGLWLKHIDGTRLLNDDNPVVYISHEGTPMVSGSPWSGKTPCYKNEEYPIGAIVQLRQAPENKIRKQTVIESYVSIKTSVSGKAWEKEIADGQHQTIEKLIGATRLYQLDCLPDAGAALLCSQTISQ\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGAATCTATTATAAAGTATTATCAGGTAGCCCATGTCGGGTTCAGCCTTTCATATCCTGATTCCTCTCAGGAGATGATGGTTGTTTTACTGGAGCCTTATCAGGCGTTTGAATGCGATGAACAGGTCGCATCTGCTGCCCTGACCTCCTTCTCTCTTACCTTGAACGAAAGCGGGGAAGAACTGAGGAAACCTGCCGGTTTCAAGGAGGAATGCAGACAGGATGAGGAGGGACAGCTCATTATCAGCGGTAGTCTGGGAGAGAAGCAGAAGGCGTTCCTGATGGCAATGACTGATATGAAATCGATACTGGTTACAGGTCATGATTATCAGCATTCCAGTCTTCTGGTTCCTGCTGGTACCTTCAGCCAGAAGTCGGCTTTCGGATCCCTCAAGGCAACCGTTGACACCTCGCTGATGCTGCTCTATGCCATGCGTTCGGCTGCCGGAGATACACTCCTGTTTCATTCTTCTACCATAGTAAAGGATGGAAAGGCTTATCTCTTCCTGGGCAAGAGCGGAACGGGCAAGAGTACGCATTCCGGACTGTGGCTCAAACATATCGATGGCACCCGATTGCTGAATGATGACAACCCGGTGGTATATATATCGCACGAAGGAACGCCCATGGTGAGTGGCTCGCCTTGGAGCGGAAAGACACCTTGCTATAAGAACGAGGAATATCCGATAGGGGCAATTGTCCAATTGCGCCAGGCACCAGAGAATAAAATCAGAAAACAGACCGTCATAGAGTCTTATGTGTCTATCAAGACTTCTGTCTCCGGCAAGGCATGGGAGAAGGAAATTGCAGATGGCCAGCATCAAACGATAGAGAAGCTGATCGGGGCTACCCGGCTTTATCAGCTCGACTGTCTGCCTGATGCCGGTGCAGCCCTCCTTTGCAGTCAGACCATCAGCCAGTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 8064,
      "end": 8567,
      "strand": 1,
      "locus_tag": "ctg118_7",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,064 - 8,567,\n (total: 504 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNISYSKYKAIAALEQFIREGRPVKFPVKGTSMLPFIVGDRDCVEFYPVEGELKVGDIVMARVEEGYPVVHRIIGIEPVTGAASPASFSADDCRIVLTGDGNLGFKEHCLRKDVIAKAHAVICPDGTRKSLISQKALRNWRRWQRLRPVRRVLLKIIKLYIRLSYKN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNISYSKYKAIAALEQFIREGRPVKFPVKGTSMLPFIVGDRDCVEFYPVEGELKVGDIVMARVEEGYPVVHRIIGIEPVTGAASPASFSADDCRIVLTGDGNLGFKEHCLRKDVIAKAHAVICPDGTRKSLISQKALRNWRRWQRLRPVRRVLLKIIKLYIRLSYKN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAATATATCCTATTCAAAATATAAGGCAATAGCCGCGCTCGAGCAATTCATCCGTGAAGGTCGTCCTGTCAAGTTTCCGGTCAAGGGAACCAGTATGCTTCCCTTTATCGTAGGTGATAGAGATTGCGTAGAATTCTATCCGGTAGAAGGCGAGTTGAAGGTGGGCGATATTGTGATGGCGAGGGTAGAAGAAGGCTATCCGGTGGTGCATCGCATCATCGGGATAGAGCCTGTTACAGGAGCAGCTTCCCCCGCATCCTTTTCTGCAGATGATTGCCGTATCGTGCTGACGGGCGATGGAAATCTCGGTTTTAAGGAGCATTGCCTGCGCAAGGATGTCATTGCGAAGGCGCATGCTGTCATCTGTCCCGACGGCACCCGCAAGAGTCTCATCTCGCAGAAAGCGCTCAGAAACTGGCGCAGATGGCAGAGGTTGAGGCCTGTGCGTAGGGTCTTGCTTAAAATAATCAAGCTCTATATCCGTTTATCATATAAAAACTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 8581,
      "end": 8847,
      "strand": 1,
      "locus_tag": "ctg118_8",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,581 - 8,847,\n (total: 267 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKIKNDFKLREICGEYVVTAEGMQAVDFTKLISLNETAAFLWKTAEKQGDFTVASLAQALCDEYDVVMAQAEKDCEAIIAQWQKEGLV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKIKNDFKLREICGEYVVTAEGMQAVDFTKLISLNETAAFLWKTAEKQGDFTVASLAQALCDEYDVVMAQAEKDCEAIIAQWQKEGLV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGATCAAGAACGATTTCAAGCTCCGCGAAATTTGCGGTGAGTATGTGGTAACAGCTGAAGGTATGCAGGCAGTAGACTTTACCAAGTTGATCAGTCTCAACGAAACTGCCGCCTTTCTCTGGAAGACGGCTGAGAAACAGGGTGATTTTACGGTAGCTTCGTTGGCTCAGGCTCTGTGCGATGAGTATGATGTAGTCATGGCTCAGGCAGAAAAAGACTGCGAGGCGATTATTGCCCAGTGGCAGAAAGAGGGACTGGTATGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 8844,
      "end": 9446,
      "strand": 1,
      "locus_tag": "ctg118_9",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,844 - 9,446,\n (total: 603 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRKYALWFFRQMSAVRGRLLLRIIAGLLQVALGLWLVWLCRRFIDVVIWRGNVLRETIVLFSVIALLIALRQLVFYLSGITEVILQNDMRSRLFRFVLGRKLYAVKHQAEAGSGKPASDMLSGDISQRLERDLSSASSVVTDILPTIVVTLVQLFGAFFLMRSIDSILAWSLLVLTPVVAVCAKYLGSRLKKMTLAIREEE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRKYALWFFRQMSAVRGRLLLRIIAGLLQVALGLWLVWLCRRFIDVVIWRGNVLRETIVLFSVIALLIALRQLVFYLSGITEVILQNDMRSRLFRFVLGRKLYAVKHQAEAGSGKPASDMLSGDISQRLERDLSSASSVVTDILPTIVVTLVQLFGAFFLMRSIDSILAWSLLVLTPVVAVCAKYLGSRLKKMTLAIREEE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGGAAGTATGCACTTTGGTTTTTTCGCCAGATGTCTGCTGTCCGGGGACGTTTGCTGTTGCGCATCATCGCCGGTCTTCTGCAGGTAGCATTAGGTTTGTGGCTCGTCTGGCTGTGTCGCCGGTTCATCGATGTGGTGATCTGGCGTGGCAATGTGCTGCGCGAAACCATCGTGCTTTTTTCTGTCATCGCCCTGCTGATAGCCCTTCGCCAGCTGGTATTCTATCTTTCCGGCATCACCGAGGTTATCCTCCAGAATGATATGCGTAGCCGCCTTTTCCGGTTTGTGCTGGGTAGGAAACTCTATGCCGTTAAGCATCAGGCTGAGGCTGGTTCCGGAAAACCAGCTTCCGATATGCTTTCCGGTGACATCAGCCAGCGTTTGGAGCGCGATCTCTCATCAGCCTCTTCGGTAGTTACGGATATCCTGCCCACAATCGTAGTCACCCTGGTGCAGCTCTTCGGTGCCTTCTTCCTGATGCGTTCCATCGATTCCATTCTGGCATGGAGTCTTCTGGTACTGACACCGGTGGTTGCAGTCTGTGCCAAGTATCTCGGCAGCCGACTCAAGAAGATGACGCTGGCGATACGCGAGGAGGAG\">Copy to clipboard</span><br>\n</div>"
     }
    ],
    "clusters": [
     {
      "start": 8580,
      "end": 8847,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 9446,
      "product": "RRE-containing",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "ttaCodons": [],
    "type": "RRE-containing",
    "products": [
     "RRE-containing"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP RRE-containing",
    "anchor": "r118c1"
   }
  ]
 },
 {
  "length": 9380,
  "seq_id": "c00119_NODE_44..",
  "regions": []
 },
 {
  "length": 9375,
  "seq_id": "c00120_NODE_44..",
  "regions": []
 },
 {
  "length": 9250,
  "seq_id": "c00121_NODE_45..",
  "regions": []
 },
 {
  "length": 9017,
  "seq_id": "c00122_NODE_46..",
  "regions": []
 },
 {
  "length": 8952,
  "seq_id": "c00123_NODE_47..",
  "regions": []
 },
 {
  "length": 8926,
  "seq_id": "c00124_NODE_47..",
  "regions": []
 },
 {
  "length": 8922,
  "seq_id": "c00125_NODE_47..",
  "regions": []
 },
 {
  "length": 8785,
  "seq_id": "c00126_NODE_48..",
  "regions": []
 },
 {
  "length": 8733,
  "seq_id": "c00127_NODE_48..",
  "regions": []
 },
 {
  "length": 8722,
  "seq_id": "c00128_NODE_48..",
  "regions": []
 },
 {
  "length": 8645,
  "seq_id": "c00129_NODE_49..",
  "regions": []
 },
 {
  "length": 8485,
  "seq_id": "c00130_NODE_50..",
  "regions": []
 },
 {
  "length": 8442,
  "seq_id": "c00131_NODE_50..",
  "regions": []
 },
 {
  "length": 8440,
  "seq_id": "c00132_NODE_50..",
  "regions": []
 },
 {
  "length": 8403,
  "seq_id": "c00133_NODE_50..",
  "regions": []
 },
 {
  "length": 8349,
  "seq_id": "c00134_NODE_51..",
  "regions": []
 },
 {
  "length": 8284,
  "seq_id": "c00135_NODE_51..",
  "regions": []
 },
 {
  "length": 8220,
  "seq_id": "c00136_NODE_52..",
  "regions": []
 },
 {
  "length": 8219,
  "seq_id": "c00137_NODE_52..",
  "regions": []
 },
 {
  "length": 8202,
  "seq_id": "c00138_NODE_52..",
  "regions": []
 },
 {
  "length": 8149,
  "seq_id": "c00139_NODE_52..",
  "regions": []
 },
 {
  "length": 7932,
  "seq_id": "c00140_NODE_54..",
  "regions": []
 },
 {
  "length": 7867,
  "seq_id": "c00141_NODE_54..",
  "regions": []
 },
 {
  "length": 7820,
  "seq_id": "c00142_NODE_54..",
  "regions": []
 },
 {
  "length": 7779,
  "seq_id": "c00143_NODE_55..",
  "regions": []
 },
 {
  "length": 7779,
  "seq_id": "c00144_NODE_55..",
  "regions": []
 },
 {
  "length": 7730,
  "seq_id": "c00145_NODE_55..",
  "regions": []
 },
 {
  "length": 7673,
  "seq_id": "c00146_NODE_56..",
  "regions": []
 },
 {
  "length": 7561,
  "seq_id": "c00147_NODE_57..",
  "regions": []
 },
 {
  "length": 7509,
  "seq_id": "c00148_NODE_57..",
  "regions": []
 },
 {
  "length": 7405,
  "seq_id": "c00149_NODE_58..",
  "regions": []
 },
 {
  "length": 7390,
  "seq_id": "c00150_NODE_58..",
  "regions": []
 },
 {
  "length": 7334,
  "seq_id": "c00151_NODE_58..",
  "regions": []
 },
 {
  "length": 7316,
  "seq_id": "c00152_NODE_58..",
  "regions": []
 },
 {
  "length": 7160,
  "seq_id": "c00153_NODE_60..",
  "regions": []
 },
 {
  "length": 7072,
  "seq_id": "c00154_NODE_60..",
  "regions": []
 },
 {
  "length": 7040,
  "seq_id": "c00155_NODE_61..",
  "regions": []
 },
 {
  "length": 7035,
  "seq_id": "c00156_NODE_61..",
  "regions": []
 },
 {
  "length": 6950,
  "seq_id": "c00157_NODE_61..",
  "regions": []
 },
 {
  "length": 6919,
  "seq_id": "c00158_NODE_62..",
  "regions": []
 },
 {
  "length": 6886,
  "seq_id": "c00159_NODE_62..",
  "regions": []
 },
 {
  "length": 6733,
  "seq_id": "c00160_NODE_63..",
  "regions": []
 },
 {
  "length": 6696,
  "seq_id": "c00161_NODE_64..",
  "regions": []
 },
 {
  "length": 6674,
  "seq_id": "c00162_NODE_64..",
  "regions": []
 },
 {
  "length": 6615,
  "seq_id": "c00163_NODE_65..",
  "regions": []
 },
 {
  "length": 6552,
  "seq_id": "c00164_NODE_65..",
  "regions": []
 },
 {
  "length": 6503,
  "seq_id": "c00165_NODE_66..",
  "regions": []
 },
 {
  "length": 6431,
  "seq_id": "c00166_NODE_67..",
  "regions": []
 },
 {
  "length": 6330,
  "seq_id": "c00167_NODE_68..",
  "regions": []
 },
 {
  "length": 6306,
  "seq_id": "c00168_NODE_68..",
  "regions": []
 },
 {
  "length": 6293,
  "seq_id": "c00169_NODE_68..",
  "regions": []
 },
 {
  "length": 6259,
  "seq_id": "c00170_NODE_69..",
  "regions": []
 },
 {
  "length": 6193,
  "seq_id": "c00171_NODE_70..",
  "regions": []
 },
 {
  "length": 6183,
  "seq_id": "c00172_NODE_70..",
  "regions": []
 },
 {
  "length": 6123,
  "seq_id": "c00173_NODE_70..",
  "regions": []
 },
 {
  "length": 6038,
  "seq_id": "c00174_NODE_72..",
  "regions": []
 },
 {
  "length": 5966,
  "seq_id": "c00175_NODE_73..",
  "regions": []
 },
 {
  "length": 5874,
  "seq_id": "c00176_NODE_74..",
  "regions": []
 },
 {
  "length": 5817,
  "seq_id": "c00177_NODE_75..",
  "regions": []
 },
 {
  "length": 5776,
  "seq_id": "c00178_NODE_75..",
  "regions": []
 },
 {
  "length": 5711,
  "seq_id": "c00179_NODE_76..",
  "regions": []
 },
 {
  "length": 5684,
  "seq_id": "c00180_NODE_77..",
  "regions": []
 },
 {
  "length": 5637,
  "seq_id": "c00181_NODE_77..",
  "regions": []
 },
 {
  "length": 5485,
  "seq_id": "c00182_NODE_80..",
  "regions": []
 },
 {
  "length": 5402,
  "seq_id": "c00183_NODE_81..",
  "regions": []
 },
 {
  "length": 5401,
  "seq_id": "c00184_NODE_81..",
  "regions": []
 },
 {
  "length": 5364,
  "seq_id": "c00185_NODE_82..",
  "regions": []
 },
 {
  "length": 5304,
  "seq_id": "c00186_NODE_83..",
  "regions": []
 },
 {
  "length": 5247,
  "seq_id": "c00187_NODE_84..",
  "regions": []
 },
 {
  "length": 5204,
  "seq_id": "c00188_NODE_84..",
  "regions": []
 },
 {
  "length": 5190,
  "seq_id": "c00189_NODE_85..",
  "regions": []
 },
 {
  "length": 5153,
  "seq_id": "c00190_NODE_85..",
  "regions": []
 },
 {
  "length": 5122,
  "seq_id": "c00191_NODE_86..",
  "regions": []
 },
 {
  "length": 5082,
  "seq_id": "c00192_NODE_87..",
  "regions": []
 },
 {
  "length": 4910,
  "seq_id": "c00193_NODE_90..",
  "regions": []
 },
 {
  "length": 4783,
  "seq_id": "c00194_NODE_92..",
  "regions": []
 },
 {
  "length": 4770,
  "seq_id": "c00195_NODE_93..",
  "regions": []
 },
 {
  "length": 4735,
  "seq_id": "c00196_NODE_93..",
  "regions": []
 },
 {
  "length": 4731,
  "seq_id": "c00197_NODE_93..",
  "regions": []
 },
 {
  "length": 4654,
  "seq_id": "c00198_NODE_95..",
  "regions": []
 },
 {
  "length": 4613,
  "seq_id": "c00199_NODE_96..",
  "regions": []
 },
 {
  "length": 4595,
  "seq_id": "c00200_NODE_96..",
  "regions": []
 },
 {
  "length": 4556,
  "seq_id": "c00201_NODE_97..",
  "regions": []
 },
 {
  "length": 4545,
  "seq_id": "c00202_NODE_98..",
  "regions": []
 },
 {
  "length": 4463,
  "seq_id": "c00203_NODE_99..",
  "regions": []
 },
 {
  "length": 4436,
  "seq_id": "c00204_NODE_10..",
  "regions": []
 },
 {
  "length": 4412,
  "seq_id": "c00205_NODE_10..",
  "regions": []
 },
 {
  "length": 4305,
  "seq_id": "c00206_NODE_10..",
  "regions": []
 },
 {
  "length": 4287,
  "seq_id": "c00207_NODE_10..",
  "regions": []
 },
 {
  "length": 4253,
  "seq_id": "c00208_NODE_10..",
  "regions": []
 },
 {
  "length": 4253,
  "seq_id": "c00209_NODE_10..",
  "regions": []
 },
 {
  "length": 4215,
  "seq_id": "c00210_NODE_10..",
  "regions": []
 },
 {
  "length": 4177,
  "seq_id": "c00211_NODE_10..",
  "regions": []
 },
 {
  "length": 4176,
  "seq_id": "c00212_NODE_10..",
  "regions": []
 },
 {
  "length": 4170,
  "seq_id": "c00213_NODE_10..",
  "regions": []
 },
 {
  "length": 4113,
  "seq_id": "c00214_NODE_10..",
  "regions": []
 },
 {
  "length": 4067,
  "seq_id": "c00215_NODE_11..",
  "regions": []
 },
 {
  "length": 4035,
  "seq_id": "c00216_NODE_11..",
  "regions": []
 },
 {
  "length": 3954,
  "seq_id": "c00217_NODE_11..",
  "regions": []
 },
 {
  "length": 3842,
  "seq_id": "c00218_NODE_11..",
  "regions": []
 },
 {
  "length": 3811,
  "seq_id": "c00219_NODE_11..",
  "regions": []
 },
 {
  "length": 3690,
  "seq_id": "c00220_NODE_12..",
  "regions": []
 },
 {
  "length": 3671,
  "seq_id": "c00221_NODE_12..",
  "regions": []
 },
 {
  "length": 3636,
  "seq_id": "c00222_NODE_12..",
  "regions": []
 },
 {
  "length": 3629,
  "seq_id": "c00223_NODE_12..",
  "regions": []
 },
 {
  "length": 3598,
  "seq_id": "c00224_NODE_12..",
  "regions": []
 },
 {
  "length": 3567,
  "seq_id": "c00225_NODE_12..",
  "regions": []
 },
 {
  "length": 3472,
  "seq_id": "c00226_NODE_13..",
  "regions": []
 },
 {
  "length": 3462,
  "seq_id": "c00227_NODE_13..",
  "regions": []
 },
 {
  "length": 3327,
  "seq_id": "c00228_NODE_13..",
  "regions": []
 },
 {
  "length": 3168,
  "seq_id": "c00229_NODE_14..",
  "regions": []
 },
 {
  "length": 3148,
  "seq_id": "c00230_NODE_14..",
  "regions": []
 },
 {
  "length": 3115,
  "seq_id": "c00231_NODE_14..",
  "regions": []
 },
 {
  "length": 3039,
  "seq_id": "c00232_NODE_15..",
  "regions": []
 },
 {
  "length": 2938,
  "seq_id": "c00233_NODE_15..",
  "regions": []
 },
 {
  "length": 2915,
  "seq_id": "c00234_NODE_15..",
  "regions": []
 },
 {
  "length": 2896,
  "seq_id": "c00235_NODE_15..",
  "regions": []
 },
 {
  "length": 2896,
  "seq_id": "c00236_NODE_15..",
  "regions": []
 },
 {
  "length": 2895,
  "seq_id": "c00237_NODE_15..",
  "regions": []
 },
 {
  "length": 2844,
  "seq_id": "c00238_NODE_16..",
  "regions": []
 },
 {
  "length": 2839,
  "seq_id": "c00239_NODE_16..",
  "regions": []
 },
 {
  "length": 2759,
  "seq_id": "c00240_NODE_16..",
  "regions": []
 },
 {
  "length": 2758,
  "seq_id": "c00241_NODE_16..",
  "regions": []
 },
 {
  "length": 2754,
  "seq_id": "c00242_NODE_16..",
  "regions": []
 },
 {
  "length": 2617,
  "seq_id": "c00243_NODE_17..",
  "regions": []
 },
 {
  "length": 2588,
  "seq_id": "c00244_NODE_18..",
  "regions": []
 },
 {
  "length": 2575,
  "seq_id": "c00245_NODE_18..",
  "regions": []
 },
 {
  "length": 2548,
  "seq_id": "c00246_NODE_18..",
  "regions": []
 },
 {
  "length": 2539,
  "seq_id": "c00247_NODE_18..",
  "regions": []
 },
 {
  "length": 2419,
  "seq_id": "c00248_NODE_19..",
  "regions": []
 },
 {
  "length": 2358,
  "seq_id": "c00249_NODE_19..",
  "regions": []
 },
 {
  "length": 2259,
  "seq_id": "c00250_NODE_20..",
  "regions": []
 },
 {
  "length": 2258,
  "seq_id": "c00251_NODE_20..",
  "regions": []
 },
 {
  "length": 2107,
  "seq_id": "c00252_NODE_22..",
  "regions": []
 },
 {
  "length": 2081,
  "seq_id": "c00253_NODE_23..",
  "regions": []
 },
 {
  "length": 2061,
  "seq_id": "c00254_NODE_23..",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r118c1"
 ],
 "r118c1": {
  "start": 1,
  "end": 9446,
  "idx": 1,
  "orfs": [
   {
    "start": 48,
    "end": 2444,
    "strand": 1,
    "locus_tag": "ctg118_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 48 - 2,444,\n (total: 2397 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKQQNRLYLIIYVAALLMLSGQLITGCSSTSALKEDEQLFTGLVPIEYKNYEKGTYADSTITEMEYALASAPNGALFGSSYYRTPFPVRLWIWNAFSQSDGALAKWITKVFGSKPKLMANVNPQLRAQVAEHQLDKYGYFNGKVTYDVLTQSNPKKAKVAYQVDFGHLWTLDSMAYLNFPAKSKQFIDASMNKALIRKGSPFNVANMESERQRITRLFRNRGYYFYQNSYASYLADTVNVPGKVQLRLMMADSVDDRATRQWYIGKIHVNFRKQYMEELKDSFVRSYLSFHYNGRKMPIRPGIVLQSLRLRPRELYRVRTEERAKTGLQEMGLFSYSSIQFSPRSVQTLDSLGNVVYRDTLDANIDLVFDKPYDFYVEANARGKTTGRVGPELVVGLTKRNAFHGGEKLTVNLHGSHEWQTISQAGGGSTRINSYEYGSDVSVEFPRIITPWNMFRTMEQNERRYRAGHMPTKYRGVPTTTIKASMNVLNRASYFRRHVAAGELTYAWSTSYQHQHSFSPLILSYEFMNSRTAAFDSILTLHPYLQISMRDQFVPKMSYTYTYRSPRRYRHPITWSTTISEAANILSLGYMAAGKGWNEKDKKMFKNPFAQFLKLETDFVKYWRIPQDGTLVGHVNAGIIWSYGNAENAPYYEQFYIGGANSVRAFNVRSIGPGRYQPTNSKYSYIDQTGDIKYLMNLEYRQKVWGDLYGALFLDAGNVWTLRNHEYSPLGKFDVDKFFRQLAVGTGVGVRYDMGMFVIRVDWGIGLHVPYDTGKNGFYNIRRFKDAQSLHFAVGYPF&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKQQNRLYLIIYVAALLMLSGQLITGCSSTSALKEDEQLFTGLVPIEYKNYEKGTYADSTITEMEYALASAPNGALFGSSYYRTPFPVRLWIWNAFSQSDGALAKWITKVFGSKPKLMANVNPQLRAQVAEHQLDKYGYFNGKVTYDVLTQSNPKKAKVAYQVDFGHLWTLDSMAYLNFPAKSKQFIDASMNKALIRKGSPFNVANMESERQRITRLFRNRGYYFYQNSYASYLADTVNVPGKVQLRLMMADSVDDRATRQWYIGKIHVNFRKQYMEELKDSFVRSYLSFHYNGRKMPIRPGIVLQSLRLRPRELYRVRTEERAKTGLQEMGLFSYSSIQFSPRSVQTLDSLGNVVYRDTLDANIDLVFDKPYDFYVEANARGKTTGRVGPELVVGLTKRNAFHGGEKLTVNLHGSHEWQTISQAGGGSTRINSYEYGSDVSVEFPRIITPWNMFRTMEQNERRYRAGHMPTKYRGVPTTTIKASMNVLNRASYFRRHVAAGELTYAWSTSYQHQHSFSPLILSYEFMNSRTAAFDSILTLHPYLQISMRDQFVPKMSYTYTYRSPRRYRHPITWSTTISEAANILSLGYMAAGKGWNEKDKKMFKNPFAQFLKLETDFVKYWRIPQDGTLVGHVNAGIIWSYGNAENAPYYEQFYIGGANSVRAFNVRSIGPGRYQPTNSKYSYIDQTGDIKYLMNLEYRQKVWGDLYGALFLDAGNVWTLRNHEYSPLGKFDVDKFFRQLAVGTGVGVRYDMGMFVIRVDWGIGLHVPYDTGKNGFYNIRRFKDAQSLHFAVGYPF\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAACAGCAGAACAGGTTATACCTTATTATATATGTGGCAGCATTGCTGATGTTGTCGGGGCAGCTCATAACGGGTTGCTCTTCAACCAGTGCGCTGAAAGAAGACGAGCAGCTGTTTACGGGTCTGGTACCTATCGAGTATAAGAACTACGAGAAGGGAACTTATGCTGATTCTACCATCACCGAGATGGAGTATGCCCTGGCTTCGGCTCCGAACGGTGCCTTGTTTGGGAGCAGCTATTACCGCACACCGTTCCCTGTGCGCCTGTGGATATGGAATGCTTTCTCTCAGTCGGATGGAGCACTGGCTAAGTGGATAACCAAGGTATTCGGTTCCAAACCTAAGCTGATGGCGAATGTGAATCCGCAACTCCGTGCCCAGGTAGCCGAGCATCAGCTCGATAAATATGGCTATTTTAACGGTAAGGTGACTTATGATGTGCTGACACAGAGCAATCCGAAGAAGGCGAAGGTTGCCTATCAGGTAGACTTCGGTCATCTCTGGACGCTTGATTCTATGGCTTATCTCAACTTCCCAGCCAAGAGCAAGCAGTTTATAGATGCTTCCATGAACAAGGCGCTCATACGGAAGGGGAGTCCTTTCAATGTCGCCAACATGGAATCGGAACGTCAGCGTATCACCCGTCTGTTCCGCAACAGGGGCTATTATTTCTATCAGAACAGTTATGCTTCTTATCTTGCCGATACCGTGAATGTGCCCGGCAAGGTGCAGTTGCGGCTGATGATGGCAGACAGCGTGGACGATAGGGCTACCCGCCAGTGGTATATCGGAAAGATTCATGTTAATTTCAGAAAGCAGTATATGGAGGAGTTGAAGGATTCCTTTGTGCGCAGCTATCTGAGTTTCCATTATAATGGAAGAAAGATGCCGATACGTCCGGGCATCGTTTTGCAGAGTCTGCGCCTGCGTCCCCGTGAACTGTATCGGGTACGTACCGAGGAGCGTGCCAAGACCGGACTCCAGGAGATGGGACTCTTCAGCTATTCCAGCATCCAGTTCTCTCCCCGTTCGGTGCAGACCCTAGACAGTCTGGGCAATGTCGTATATCGTGATACCTTGGATGCCAATATCGATCTGGTATTCGACAAGCCATACGATTTCTATGTCGAGGCAAATGCCCGCGGTAAAACGACCGGTAGAGTAGGACCGGAGTTGGTAGTGGGTCTTACCAAGCGCAATGCTTTTCATGGAGGCGAGAAACTTACTGTCAACCTGCATGGTTCGCATGAGTGGCAAACCATCAGTCAGGCTGGTGGAGGTTCTACCCGCATCAATTCCTATGAATACGGATCGGATGTTTCCGTAGAGTTCCCTCGCATCATCACGCCTTGGAATATGTTCAGAACGATGGAGCAGAATGAGCGCAGATACCGTGCCGGGCATATGCCTACCAAATATCGGGGTGTGCCAACTACTACCATCAAGGCTTCGATGAATGTGCTGAACAGAGCCAGCTATTTCCGACGTCATGTGGCAGCGGGCGAGTTAACCTATGCGTGGTCTACCTCTTACCAGCATCAGCATTCTTTCAGCCCGCTGATTCTCTCTTATGAGTTTATGAACAGCCGCACAGCCGCTTTCGATAGCATCCTCACCCTGCATCCTTATCTTCAGATATCGATGCGCGACCAGTTTGTACCTAAGATGAGTTACACCTATACTTATCGCAGTCCGCGCCGTTACCGCCATCCTATCACCTGGTCAACCACCATCAGCGAGGCAGCCAATATCCTTTCGCTCGGTTACATGGCGGCCGGAAAGGGATGGAACGAGAAAGACAAGAAGATGTTCAAGAATCCGTTTGCTCAGTTTCTGAAACTGGAGACAGATTTCGTGAAATATTGGCGTATCCCCCAGGATGGTACGCTGGTGGGACATGTCAATGCCGGCATTATCTGGAGTTATGGCAATGCCGAGAATGCTCCTTATTATGAGCAGTTCTATATCGGTGGTGCCAACAGTGTGCGAGCCTTTAATGTGAGAAGCATCGGACCGGGCAGATACCAGCCTACCAACAGCAAGTATTCGTATATCGACCAGACGGGCGACATCAAGTATCTGATGAATCTGGAATACCGTCAGAAGGTATGGGGCGATCTCTATGGAGCCCTTTTCCTGGATGCAGGTAATGTGTGGACCTTACGCAACCATGAGTACAGTCCGCTCGGCAAGTTTGATGTAGACAAGTTTTTCCGGCAGCTGGCGGTAGGCACCGGTGTCGGTGTGCGTTATGACATGGGTATGTTTGTGATACGTGTCGACTGGGGTATCGGTCTGCATGTTCCTTACGATACCGGCAAGAATGGCTTCTATAACATCCGTCGGTTCAAGGATGCCCAGAGTCTGCATTTCGCTGTGGGTTATCCTTTCTAG\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 2632,
    "end": 3543,
    "strand": 1,
    "locus_tag": "ctg118_2",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,632 - 3,543,\n (total: 912 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKPTLLLLAAGMGSRYGGLKQLDGLGPNGETIMDYSIYDAIQAGFGKIVFVIRKDFEDQFREKILSKYEGHIPAELCFQALDDLPEGFSVPEGREKPWGTNHAVLMAKDIIKEPFCVINCDDFYNRDCFMVIGKFLSELPEGSKNRYAMVGFRVGNTLSENGTVARGICSKDADENLTTCVERTEIMRIDGKVSYKDEQGEWVAVGDNTPVSMNVWGFTPDYFQHSEEYFKEFLSDPKNMENKKAEFFIPLMVNKLINEGTATVKVLDTTSKWFGVTYAADRQSVVDKIQHLIDEGVYPNKLF&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKPTLLLLAAGMGSRYGGLKQLDGLGPNGETIMDYSIYDAIQAGFGKIVFVIRKDFEDQFREKILSKYEGHIPAELCFQALDDLPEGFSVPEGREKPWGTNHAVLMAKDIIKEPFCVINCDDFYNRDCFMVIGKFLSELPEGSKNRYAMVGFRVGNTLSENGTVARGICSKDADENLTTCVERTEIMRIDGKVSYKDEQGEWVAVGDNTPVSMNVWGFTPDYFQHSEEYFKEFLSDPKNMENKKAEFFIPLMVNKLINEGTATVKVLDTTSKWFGVTYAADRQSVVDKIQHLIDEGVYPNKLF\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAACCTACGTTATTGCTTTTGGCTGCCGGTATGGGTAGCCGTTATGGTGGTTTGAAACAGCTTGATGGTCTGGGTCCTAATGGTGAGACTATCATGGACTACAGCATCTATGATGCTATTCAGGCTGGTTTCGGAAAGATCGTATTCGTTATCCGCAAGGACTTCGAAGATCAGTTCCGTGAGAAGATTCTTTCAAAGTATGAGGGTCATATTCCTGCAGAACTTTGCTTCCAGGCATTGGATGATCTCCCAGAGGGATTCTCAGTTCCAGAAGGTCGTGAGAAACCATGGGGTACAAACCATGCTGTCCTGATGGCAAAGGATATCATCAAGGAACCTTTCTGCGTAATCAACTGCGATGACTTCTACAACCGCGATTGCTTCATGGTAATCGGCAAGTTCCTCTCTGAACTTCCAGAGGGCAGCAAGAACCGTTACGCCATGGTAGGTTTCCGTGTAGGTAATACCTTGAGCGAGAATGGTACCGTAGCTCGCGGCATCTGCTCTAAGGATGCTGATGAGAACTTGACAACCTGTGTAGAGCGTACCGAGATCATGCGTATTGATGGTAAGGTATCTTACAAGGACGAGCAGGGCGAGTGGGTTGCTGTTGGCGACAATACTCCTGTTTCCATGAACGTTTGGGGCTTCACACCTGATTACTTCCAGCATAGTGAGGAGTACTTCAAGGAGTTCTTGAGTGATCCTAAGAATATGGAAAACAAGAAGGCTGAGTTCTTCATCCCATTGATGGTCAACAAGCTCATCAATGAGGGTACAGCTACCGTTAAGGTGCTCGATACTACCAGCAAGTGGTTTGGTGTAACTTATGCAGCCGACCGCCAGAGTGTTGTTGATAAGATCCAGCATCTTATCGATGAGGGTGTTTATCCAAACAAGCTCTTCTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 3553,
    "end": 4593,
    "strand": 1,
    "locus_tag": "ctg118_3",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,553 - 4,593,\n (total: 1041 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDININILTDQEAAILRETIAASHRIVVCAHKSPDGDAIGSSLGWAGYLRSLGKKVDICVPDMVPDSISWLPGAAGILRYDRQPELVQRAFDEADLVCCVDFSSEGRLDEMDHLLLGCKTQRVIIDHHLSPNLEAKLLVSQPHASSASDLVFRVVWQLGGFPQMDQTWATCIYCGMMTDTGGFTYNSTQPYIYYIICLLLTKNIDKDKIYRNVFNNARIPAVRFRGYLMNEKLQVVEGLHASFYTVTRKELKKYDFIKGDLEGLVNVPLTIKGHKLSISLREDTDIDNRILVSLRSVDDFPCNKMAAEFFNGGGHRNASGGKLLCSIQEAEQIALKAILAYADMLK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDININILTDQEAAILRETIAASHRIVVCAHKSPDGDAIGSSLGWAGYLRSLGKKVDICVPDMVPDSISWLPGAAGILRYDRQPELVQRAFDEADLVCCVDFSSEGRLDEMDHLLLGCKTQRVIIDHHLSPNLEAKLLVSQPHASSASDLVFRVVWQLGGFPQMDQTWATCIYCGMMTDTGGFTYNSTQPYIYYIICLLLTKNIDKDKIYRNVFNNARIPAVRFRGYLMNEKLQVVEGLHASFYTVTRKELKKYDFIKGDLEGLVNVPLTIKGHKLSISLREDTDIDNRILVSLRSVDDFPCNKMAAEFFNGGGHRNASGGKLLCSIQEAEQIALKAILAYADMLK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGATATAAACATTAATATATTGACAGATCAGGAAGCCGCTATTCTCCGAGAGACGATAGCGGCTTCTCATCGTATTGTCGTCTGTGCACATAAGTCGCCAGACGGTGATGCCATCGGCTCTTCTTTGGGATGGGCTGGTTATCTTCGCTCTTTGGGCAAGAAAGTTGACATTTGTGTGCCGGATATGGTACCGGATTCTATTTCCTGGTTGCCTGGAGCTGCCGGTATCCTGCGATATGACAGACAGCCTGAACTGGTGCAGCGAGCTTTCGATGAAGCCGACCTGGTATGCTGTGTTGACTTTAGCAGTGAGGGACGTCTTGATGAGATGGATCATTTATTGTTGGGTTGCAAGACTCAGCGTGTCATCATCGACCACCATCTGTCTCCTAATCTTGAGGCTAAGCTGCTGGTTTCGCAGCCACATGCCAGCAGTGCCAGCGACCTGGTATTCCGTGTAGTCTGGCAGTTGGGAGGTTTCCCACAGATGGATCAGACCTGGGCTACCTGCATCTATTGCGGCATGATGACCGATACGGGCGGTTTCACCTATAATTCTACCCAGCCTTATATCTATTACATCATCTGCTTGCTGCTTACCAAGAACATCGACAAGGATAAGATTTACCGTAATGTCTTCAATAATGCCCGCATTCCGGCAGTCCGGTTTCGTGGCTATCTGATGAATGAAAAGTTGCAGGTAGTAGAGGGTCTTCATGCCAGTTTCTATACAGTGACCCGTAAAGAATTGAAGAAGTATGACTTTATCAAGGGCGACCTGGAAGGACTGGTGAACGTGCCTCTTACCATCAAGGGACACAAACTCTCCATTTCTCTTCGTGAAGATACGGATATAGACAATCGCATATTGGTAAGTCTCCGTTCGGTAGACGATTTCCCATGCAATAAGATGGCAGCCGAGTTCTTCAATGGTGGCGGTCATCGCAATGCTTCTGGCGGCAAATTGCTTTGCAGCATACAGGAGGCAGAGCAGATAGCACTGAAGGCTATCCTGGCATACGCCGATATGCTGAAGTAG\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 4757,
    "end": 5455,
    "strand": 1,
    "locus_tag": "ctg118_4",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,757 - 5,455,\n (total: 699 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKKFLFAMIAFAAVLSFAACNDSETYKDMRDRELDSISSFLRKENIKVISEDEFNRRWKNNEKLTDTAKNNNEWVLFNSNGIYMQVIDQGCGDYIKKGTSVDVLVRFDEYNLSYAAEMSDKCLTLSNKVPAYSYYVDKISVTNTSGTFTGSFVDPKASLMANTYNSSNYGSVSSTVPSGWLIPFTWIKIGRPKTDDERIAHIRLLVPHSYGTTSASGSVQACVYDMTLQKGR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKKFLFAMIAFAAVLSFAACNDSETYKDMRDRELDSISSFLRKENIKVISEDEFNRRWKNNEKLTDTAKNNNEWVLFNSNGIYMQVIDQGCGDYIKKGTSVDVLVRFDEYNLSYAAEMSDKCLTLSNKVPAYSYYVDKISVTNTSGTFTGSFVDPKASLMANTYNSSNYGSVSSTVPSGWLIPFTWIKIGRPKTDDERIAHIRLLVPHSYGTTSASGSVQACVYDMTLQKGR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGAAATTTTTGTTTGCAATGATTGCTTTTGCGGCTGTTTTATCGTTTGCCGCATGCAATGATAGTGAGACTTATAAGGACATGCGCGACAGAGAGCTCGATTCTATCAGCTCTTTCTTGCGTAAGGAAAATATTAAGGTCATCTCTGAGGATGAGTTCAACAGACGTTGGAAAAATAATGAAAAACTGACGGATACAGCAAAGAACAACAACGAATGGGTACTTTTCAACAGTAACGGTATCTACATGCAGGTGATTGACCAGGGATGTGGCGACTATATCAAGAAAGGTACATCGGTAGATGTATTGGTCCGCTTTGATGAGTATAACCTTTCGTATGCTGCTGAAATGAGCGATAAGTGTCTCACGCTTTCAAACAAAGTTCCTGCTTATTCCTATTATGTAGATAAGATAAGCGTTACCAATACTTCCGGTACATTCACCGGTTCTTTCGTTGATCCTAAAGCCAGTCTGATGGCCAATACATATAATTCATCCAATTATGGCAGTGTAAGTTCTACCGTGCCTAGCGGTTGGCTCATACCATTCACCTGGATTAAGATAGGCAGACCGAAGACTGATGATGAACGCATCGCTCATATCCGTTTGCTCGTACCTCACTCTTACGGTACCACATCGGCATCGGGCAGTGTGCAGGCATGTGTCTACGACATGACCCTGCAGAAAGGAAGATAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 5476,
    "end": 6867,
    "strand": 1,
    "locus_tag": "ctg118_5",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,476 - 6,867,\n (total: 1392 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTLIKSISGIRGTIGGPAGDTLNPLDIVKFTSAYATFIRRSGASESNTIVVGRDARISGEMVKNVVCGTLMGMGYDVLNIGLATTPTTELAVTMSGAAGGIIITASHNPRQWNALKLLNEKGEFLTAVNGNEVLGIAEKEDFDYADVDHLGKYTEDNTFNKRHIDSVLALKLVDVEAIKNAHFKVCVDSINSVGGVILPELLDALGVAYTFLNGEPTGDFAHNPEPLEKNLGGIMDELKKGGYDMGIVVDPDVDRLAFICEDGKMFGEEYTLVSVADYVLGKTPGNTVSNLSSTRALRDVTEKHGGKYTAAAVGEVNVTTKMKDVHAVIGGEGNGGVIYPESHYGRDALVGIALFLSSLAHKGCKVSELRASFPNYFIAKNRIDLTPSTDVDAILVKVKEMYGKEKDVTVTDIDGVKLDFPDKWVHLRKSNTEPIIRVYSEASTMEQADELGKKLMQVVYDMQ&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTLIKSISGIRGTIGGPAGDTLNPLDIVKFTSAYATFIRRSGASESNTIVVGRDARISGEMVKNVVCGTLMGMGYDVLNIGLATTPTTELAVTMSGAAGGIIITASHNPRQWNALKLLNEKGEFLTAVNGNEVLGIAEKEDFDYADVDHLGKYTEDNTFNKRHIDSVLALKLVDVEAIKNAHFKVCVDSINSVGGVILPELLDALGVAYTFLNGEPTGDFAHNPEPLEKNLGGIMDELKKGGYDMGIVVDPDVDRLAFICEDGKMFGEEYTLVSVADYVLGKTPGNTVSNLSSTRALRDVTEKHGGKYTAAAVGEVNVTTKMKDVHAVIGGEGNGGVIYPESHYGRDALVGIALFLSSLAHKGCKVSELRASFPNYFIAKNRIDLTPSTDVDAILVKVKEMYGKEKDVTVTDIDGVKLDFPDKWVHLRKSNTEPIIRVYSEASTMEQADELGKKLMQVVYDMQ\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACACTGATTAAGTCAATTTCTGGTATCCGCGGTACTATCGGCGGTCCAGCGGGCGATACTTTGAATCCGCTCGATATCGTAAAGTTCACTTCAGCATACGCTACCTTCATTCGCCGTAGCGGTGCTTCAGAGAGTAATACCATCGTTGTAGGCCGTGATGCGCGCATCTCTGGCGAGATGGTAAAGAATGTGGTTTGTGGAACCCTCATGGGTATGGGCTACGATGTGCTGAACATCGGTCTGGCTACTACTCCTACCACCGAACTTGCTGTTACCATGAGTGGTGCGGCCGGCGGTATCATCATCACAGCTTCTCACAACCCACGCCAGTGGAATGCCCTCAAGCTCCTCAACGAGAAGGGTGAGTTCCTCACAGCAGTTAATGGTAACGAGGTGCTGGGTATCGCAGAGAAGGAAGACTTCGACTATGCGGATGTGGATCATCTCGGAAAATATACTGAAGACAATACCTTCAACAAGCGCCATATCGACTCCGTACTTGCTTTGAAGCTCGTAGATGTCGAAGCAATCAAGAATGCCCACTTCAAGGTTTGTGTAGATTCCATCAACTCAGTTGGTGGCGTTATACTTCCAGAGTTGCTCGATGCGCTCGGTGTAGCATATACTTTCCTCAATGGTGAGCCTACAGGCGACTTTGCTCATAATCCGGAGCCATTGGAGAAGAACCTCGGTGGTATCATGGATGAGTTGAAGAAGGGTGGCTACGATATGGGTATCGTTGTAGACCCTGATGTTGACCGTCTGGCTTTCATCTGCGAAGATGGCAAGATGTTTGGCGAAGAGTATACCTTGGTAAGTGTGGCAGATTACGTATTGGGCAAGACTCCAGGTAATACCGTCAGCAACCTTTCATCTACCCGTGCCCTCCGTGATGTTACAGAGAAGCATGGTGGCAAGTACACCGCAGCTGCTGTAGGCGAGGTGAATGTAACTACCAAGATGAAGGATGTTCACGCTGTTATCGGTGGTGAAGGCAATGGTGGAGTTATCTATCCAGAGAGCCATTACGGTCGTGATGCCCTCGTTGGTATCGCCCTCTTCCTGAGCAGTCTGGCTCACAAGGGCTGCAAGGTGAGCGAGCTCCGTGCCAGCTTCCCTAACTATTTCATCGCCAAGAACCGCATCGACCTGACTCCATCTACCGATGTAGATGCTATCCTCGTGAAGGTTAAGGAGATGTATGGTAAGGAGAAGGATGTCACCGTAACAGATATCGATGGCGTCAAGCTCGATTTCCCTGACAAGTGGGTTCACCTCCGCAAGAGTAATACCGAGCCTATCATCCGCGTATATAGCGAGGCCTCTACTATGGAGCAGGCTGATGAACTGGGCAAGAAGCTCATGCAGGTGGTTTACGATATGCAGTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 7119,
    "end": 8042,
    "strand": 1,
    "locus_tag": "ctg118_6",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,119 - 8,042,\n (total: 924 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MESIIKYYQVAHVGFSLSYPDSSQEMMVVLLEPYQAFECDEQVASAALTSFSLTLNESGEELRKPAGFKEECRQDEEGQLIISGSLGEKQKAFLMAMTDMKSILVTGHDYQHSSLLVPAGTFSQKSAFGSLKATVDTSLMLLYAMRSAAGDTLLFHSSTIVKDGKAYLFLGKSGTGKSTHSGLWLKHIDGTRLLNDDNPVVYISHEGTPMVSGSPWSGKTPCYKNEEYPIGAIVQLRQAPENKIRKQTVIESYVSIKTSVSGKAWEKEIADGQHQTIEKLIGATRLYQLDCLPDAGAALLCSQTISQ&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MESIIKYYQVAHVGFSLSYPDSSQEMMVVLLEPYQAFECDEQVASAALTSFSLTLNESGEELRKPAGFKEECRQDEEGQLIISGSLGEKQKAFLMAMTDMKSILVTGHDYQHSSLLVPAGTFSQKSAFGSLKATVDTSLMLLYAMRSAAGDTLLFHSSTIVKDGKAYLFLGKSGTGKSTHSGLWLKHIDGTRLLNDDNPVVYISHEGTPMVSGSPWSGKTPCYKNEEYPIGAIVQLRQAPENKIRKQTVIESYVSIKTSVSGKAWEKEIADGQHQTIEKLIGATRLYQLDCLPDAGAALLCSQTISQ\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGAATCTATTATAAAGTATTATCAGGTAGCCCATGTCGGGTTCAGCCTTTCATATCCTGATTCCTCTCAGGAGATGATGGTTGTTTTACTGGAGCCTTATCAGGCGTTTGAATGCGATGAACAGGTCGCATCTGCTGCCCTGACCTCCTTCTCTCTTACCTTGAACGAAAGCGGGGAAGAACTGAGGAAACCTGCCGGTTTCAAGGAGGAATGCAGACAGGATGAGGAGGGACAGCTCATTATCAGCGGTAGTCTGGGAGAGAAGCAGAAGGCGTTCCTGATGGCAATGACTGATATGAAATCGATACTGGTTACAGGTCATGATTATCAGCATTCCAGTCTTCTGGTTCCTGCTGGTACCTTCAGCCAGAAGTCGGCTTTCGGATCCCTCAAGGCAACCGTTGACACCTCGCTGATGCTGCTCTATGCCATGCGTTCGGCTGCCGGAGATACACTCCTGTTTCATTCTTCTACCATAGTAAAGGATGGAAAGGCTTATCTCTTCCTGGGCAAGAGCGGAACGGGCAAGAGTACGCATTCCGGACTGTGGCTCAAACATATCGATGGCACCCGATTGCTGAATGATGACAACCCGGTGGTATATATATCGCACGAAGGAACGCCCATGGTGAGTGGCTCGCCTTGGAGCGGAAAGACACCTTGCTATAAGAACGAGGAATATCCGATAGGGGCAATTGTCCAATTGCGCCAGGCACCAGAGAATAAAATCAGAAAACAGACCGTCATAGAGTCTTATGTGTCTATCAAGACTTCTGTCTCCGGCAAGGCATGGGAGAAGGAAATTGCAGATGGCCAGCATCAAACGATAGAGAAGCTGATCGGGGCTACCCGGCTTTATCAGCTCGACTGTCTGCCTGATGCCGGTGCAGCCCTCCTTTGCAGTCAGACCATCAGCCAGTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 8064,
    "end": 8567,
    "strand": 1,
    "locus_tag": "ctg118_7",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,064 - 8,567,\n (total: 504 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNISYSKYKAIAALEQFIREGRPVKFPVKGTSMLPFIVGDRDCVEFYPVEGELKVGDIVMARVEEGYPVVHRIIGIEPVTGAASPASFSADDCRIVLTGDGNLGFKEHCLRKDVIAKAHAVICPDGTRKSLISQKALRNWRRWQRLRPVRRVLLKIIKLYIRLSYKN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNISYSKYKAIAALEQFIREGRPVKFPVKGTSMLPFIVGDRDCVEFYPVEGELKVGDIVMARVEEGYPVVHRIIGIEPVTGAASPASFSADDCRIVLTGDGNLGFKEHCLRKDVIAKAHAVICPDGTRKSLISQKALRNWRRWQRLRPVRRVLLKIIKLYIRLSYKN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAATATATCCTATTCAAAATATAAGGCAATAGCCGCGCTCGAGCAATTCATCCGTGAAGGTCGTCCTGTCAAGTTTCCGGTCAAGGGAACCAGTATGCTTCCCTTTATCGTAGGTGATAGAGATTGCGTAGAATTCTATCCGGTAGAAGGCGAGTTGAAGGTGGGCGATATTGTGATGGCGAGGGTAGAAGAAGGCTATCCGGTGGTGCATCGCATCATCGGGATAGAGCCTGTTACAGGAGCAGCTTCCCCCGCATCCTTTTCTGCAGATGATTGCCGTATCGTGCTGACGGGCGATGGAAATCTCGGTTTTAAGGAGCATTGCCTGCGCAAGGATGTCATTGCGAAGGCGCATGCTGTCATCTGTCCCGACGGCACCCGCAAGAGTCTCATCTCGCAGAAAGCGCTCAGAAACTGGCGCAGATGGCAGAGGTTGAGGCCTGTGCGTAGGGTCTTGCTTAAAATAATCAAGCTCTATATCCGTTTATCATATAAAAACTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 8581,
    "end": 8847,
    "strand": 1,
    "locus_tag": "ctg118_8",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,581 - 8,847,\n (total: 267 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKIKNDFKLREICGEYVVTAEGMQAVDFTKLISLNETAAFLWKTAEKQGDFTVASLAQALCDEYDVVMAQAEKDCEAIIAQWQKEGLV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKIKNDFKLREICGEYVVTAEGMQAVDFTKLISLNETAAFLWKTAEKQGDFTVASLAQALCDEYDVVMAQAEKDCEAIIAQWQKEGLV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGATCAAGAACGATTTCAAGCTCCGCGAAATTTGCGGTGAGTATGTGGTAACAGCTGAAGGTATGCAGGCAGTAGACTTTACCAAGTTGATCAGTCTCAACGAAACTGCCGCCTTTCTCTGGAAGACGGCTGAGAAACAGGGTGATTTTACGGTAGCTTCGTTGGCTCAGGCTCTGTGCGATGAGTATGATGTAGTCATGGCTCAGGCAGAAAAAGACTGCGAGGCGATTATTGCCCAGTGGCAGAAAGAGGGACTGGTATGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 8844,
    "end": 9446,
    "strand": 1,
    "locus_tag": "ctg118_9",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg118_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg118_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,844 - 9,446,\n (total: 603 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRKYALWFFRQMSAVRGRLLLRIIAGLLQVALGLWLVWLCRRFIDVVIWRGNVLRETIVLFSVIALLIALRQLVFYLSGITEVILQNDMRSRLFRFVLGRKLYAVKHQAEAGSGKPASDMLSGDISQRLERDLSSASSVVTDILPTIVVTLVQLFGAFFLMRSIDSILAWSLLVLTPVVAVCAKYLGSRLKKMTLAIREEE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00118_NODE_44..&amp;from=0&amp;to=9446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRKYALWFFRQMSAVRGRLLLRIIAGLLQVALGLWLVWLCRRFIDVVIWRGNVLRETIVLFSVIALLIALRQLVFYLSGITEVILQNDMRSRLFRFVLGRKLYAVKHQAEAGSGKPASDMLSGDISQRLERDLSSASSVVTDILPTIVVTLVQLFGAFFLMRSIDSILAWSLLVLTPVVAVCAKYLGSRLKKMTLAIREEE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGGAAGTATGCACTTTGGTTTTTTCGCCAGATGTCTGCTGTCCGGGGACGTTTGCTGTTGCGCATCATCGCCGGTCTTCTGCAGGTAGCATTAGGTTTGTGGCTCGTCTGGCTGTGTCGCCGGTTCATCGATGTGGTGATCTGGCGTGGCAATGTGCTGCGCGAAACCATCGTGCTTTTTTCTGTCATCGCCCTGCTGATAGCCCTTCGCCAGCTGGTATTCTATCTTTCCGGCATCACCGAGGTTATCCTCCAGAATGATATGCGTAGCCGCCTTTTCCGGTTTGTGCTGGGTAGGAAACTCTATGCCGTTAAGCATCAGGCTGAGGCTGGTTCCGGAAAACCAGCTTCCGATATGCTTTCCGGTGACATCAGCCAGCGTTTGGAGCGCGATCTCTCATCAGCCTCTTCGGTAGTTACGGATATCCTGCCCACAATCGTAGTCACCCTGGTGCAGCTCTTCGGTGCCTTCTTCCTGATGCGTTCCATCGATTCCATTCTGGCATGGAGTCTTCTGGTACTGACACCGGTGGTTGCAGTCTGTGCCAAGTATCTCGGCAGCCGACTCAAGAAGATGACGCTGGCGATACGCGAGGAGGAG\">Copy to clipboard</span><br>\n</div>"
   }
  ],
  "clusters": [
   {
    "start": 8580,
    "end": 8847,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 9446,
    "product": "RRE-containing",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "ttaCodons": [],
  "type": "RRE-containing",
  "products": [
   "RRE-containing"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP RRE-containing",
  "anchor": "r118c1"
 }
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
