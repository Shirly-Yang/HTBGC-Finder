var recordData = [
 {
  "length": 148158,
  "seq_id": "c00001_NODE_25..",
  "regions": []
 },
 {
  "length": 72237,
  "seq_id": "c00002_NODE_19..",
  "regions": []
 },
 {
  "length": 65804,
  "seq_id": "c00003_NODE_25..",
  "regions": []
 },
 {
  "length": 58671,
  "seq_id": "c00004_NODE_32..",
  "regions": []
 },
 {
  "length": 58067,
  "seq_id": "c00005_NODE_34..",
  "regions": []
 },
 {
  "length": 53343,
  "seq_id": "c00006_NODE_40..",
  "regions": []
 },
 {
  "length": 48672,
  "seq_id": "c00007_NODE_47..",
  "regions": []
 },
 {
  "length": 45244,
  "seq_id": "c00008_NODE_53..",
  "regions": []
 },
 {
  "length": 45230,
  "seq_id": "c00009_NODE_53..",
  "regions": []
 },
 {
  "length": 44048,
  "seq_id": "c00010_NODE_56..",
  "regions": []
 },
 {
  "length": 39979,
  "seq_id": "c00011_NODE_66..",
  "regions": []
 },
 {
  "length": 35716,
  "seq_id": "c00012_NODE_79..",
  "regions": []
 },
 {
  "length": 32765,
  "seq_id": "c00013_NODE_92..",
  "regions": []
 },
 {
  "length": 31274,
  "seq_id": "c00014_NODE_99..",
  "regions": []
 },
 {
  "length": 29496,
  "seq_id": "c00015_NODE_10..",
  "regions": []
 },
 {
  "length": 29473,
  "seq_id": "c00016_NODE_10..",
  "regions": []
 },
 {
  "length": 24189,
  "seq_id": "c00017_NODE_14..",
  "regions": []
 },
 {
  "length": 22720,
  "seq_id": "c00018_NODE_15..",
  "regions": []
 },
 {
  "length": 20774,
  "seq_id": "c00019_NODE_17..",
  "regions": []
 },
 {
  "length": 20274,
  "seq_id": "c00020_NODE_18..",
  "regions": []
 },
 {
  "length": 17086,
  "seq_id": "c00021_NODE_22..",
  "regions": []
 },
 {
  "length": 16605,
  "seq_id": "c00022_NODE_23..",
  "regions": []
 },
 {
  "length": 16588,
  "seq_id": "c00023_NODE_23..",
  "regions": []
 },
 {
  "length": 15896,
  "seq_id": "c00024_NODE_25..",
  "regions": []
 },
 {
  "length": 15871,
  "seq_id": "c00025_NODE_25..",
  "regions": []
 },
 {
  "length": 14564,
  "seq_id": "c00026_NODE_27..",
  "regions": []
 },
 {
  "length": 14114,
  "seq_id": "c00027_NODE_28..",
  "regions": []
 },
 {
  "length": 8996,
  "seq_id": "c00028_NODE_46..",
  "regions": []
 },
 {
  "length": 7397,
  "seq_id": "c00029_NODE_58..",
  "regions": []
 },
 {
  "length": 6180,
  "seq_id": "c00030_NODE_70..",
  "regions": []
 },
 {
  "length": 5999,
  "seq_id": "c00031_NODE_72..",
  "regions": []
 },
 {
  "length": 5758,
  "seq_id": "c00032_NODE_76..",
  "regions": []
 },
 {
  "length": 5332,
  "seq_id": "c00033_NODE_82..",
  "regions": []
 },
 {
  "length": 4688,
  "seq_id": "c00034_NODE_94..",
  "regions": []
 },
 {
  "length": 4505,
  "seq_id": "c00035_NODE_98..",
  "regions": []
 },
 {
  "length": 3865,
  "seq_id": "c00036_NODE_11..",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
