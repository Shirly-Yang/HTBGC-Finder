var recordData = [
 {
  "length": 53873,
  "seq_id": "c00001_NODE_39..",
  "regions": []
 },
 {
  "length": 44590,
  "seq_id": "c00002_NODE_55..",
  "regions": []
 },
 {
  "length": 36713,
  "seq_id": "c00003_NODE_76..",
  "regions": []
 },
 {
  "length": 28293,
  "seq_id": "c00004_NODE_11..",
  "regions": []
 },
 {
  "length": 24798,
  "seq_id": "c00005_NODE_14..",
  "regions": []
 },
 {
  "length": 22724,
  "seq_id": "c00006_NODE_15..",
  "regions": []
 },
 {
  "length": 22375,
  "seq_id": "c00007_NODE_16..",
  "regions": []
 },
 {
  "length": 21726,
  "seq_id": "c00008_NODE_16..",
  "regions": []
 },
 {
  "length": 21281,
  "seq_id": "c00009_NODE_17..",
  "regions": []
 },
 {
  "length": 21240,
  "seq_id": "c00010_NODE_17..",
  "regions": []
 },
 {
  "length": 19934,
  "seq_id": "c00011_NODE_18..",
  "regions": []
 },
 {
  "length": 19001,
  "seq_id": "c00012_NODE_20..",
  "regions": []
 },
 {
  "length": 17923,
  "seq_id": "c00013_NODE_21..",
  "regions": []
 },
 {
  "length": 16861,
  "seq_id": "c00014_NODE_23..",
  "regions": []
 },
 {
  "length": 16623,
  "seq_id": "c00015_NODE_23..",
  "regions": []
 },
 {
  "length": 16358,
  "seq_id": "c00016_NODE_24..",
  "regions": []
 },
 {
  "length": 16203,
  "seq_id": "c00017_NODE_24..",
  "regions": []
 },
 {
  "length": 16200,
  "seq_id": "c00018_NODE_24..",
  "regions": []
 },
 {
  "length": 16052,
  "seq_id": "c00019_NODE_24..",
  "regions": []
 },
 {
  "length": 15979,
  "seq_id": "c00020_NODE_24..",
  "regions": []
 },
 {
  "length": 15894,
  "seq_id": "c00021_NODE_25..",
  "regions": []
 },
 {
  "length": 15822,
  "seq_id": "c00022_NODE_25..",
  "regions": []
 },
 {
  "length": 15578,
  "seq_id": "c00023_NODE_25..",
  "regions": []
 },
 {
  "length": 15543,
  "seq_id": "c00024_NODE_25..",
  "regions": []
 },
 {
  "length": 15349,
  "seq_id": "c00025_NODE_26..",
  "regions": []
 },
 {
  "length": 15033,
  "seq_id": "c00026_NODE_26..",
  "regions": []
 },
 {
  "length": 14949,
  "seq_id": "c00027_NODE_26..",
  "regions": []
 },
 {
  "length": 14032,
  "seq_id": "c00028_NODE_28..",
  "regions": []
 },
 {
  "length": 13596,
  "seq_id": "c00029_NODE_29..",
  "regions": []
 },
 {
  "length": 13225,
  "seq_id": "c00030_NODE_30..",
  "regions": []
 },
 {
  "length": 13202,
  "seq_id": "c00031_NODE_30..",
  "regions": []
 },
 {
  "length": 13141,
  "seq_id": "c00032_NODE_31..",
  "regions": []
 },
 {
  "length": 13032,
  "seq_id": "c00033_NODE_31..",
  "regions": []
 },
 {
  "length": 12956,
  "seq_id": "c00034_NODE_31..",
  "regions": []
 },
 {
  "length": 12945,
  "seq_id": "c00035_NODE_31..",
  "regions": []
 },
 {
  "length": 12940,
  "seq_id": "c00036_NODE_31..",
  "regions": []
 },
 {
  "length": 12860,
  "seq_id": "c00037_NODE_31..",
  "regions": []
 },
 {
  "length": 12505,
  "seq_id": "c00038_NODE_32..",
  "regions": []
 },
 {
  "length": 12456,
  "seq_id": "c00039_NODE_32..",
  "regions": []
 },
 {
  "length": 11914,
  "seq_id": "c00040_NODE_34..",
  "regions": []
 },
 {
  "length": 11651,
  "seq_id": "c00041_NODE_35..",
  "regions": []
 },
 {
  "length": 11523,
  "seq_id": "c00042_NODE_36..",
  "regions": []
 },
 {
  "length": 10838,
  "seq_id": "c00043_NODE_38..",
  "regions": []
 },
 {
  "length": 10820,
  "seq_id": "c00044_NODE_38..",
  "regions": []
 },
 {
  "length": 10785,
  "seq_id": "c00045_NODE_38..",
  "regions": []
 },
 {
  "length": 10566,
  "seq_id": "c00046_NODE_39..",
  "regions": []
 },
 {
  "length": 10468,
  "seq_id": "c00047_NODE_40..",
  "regions": []
 },
 {
  "length": 10271,
  "seq_id": "c00048_NODE_40..",
  "regions": []
 },
 {
  "length": 10201,
  "seq_id": "c00049_NODE_41..",
  "regions": []
 },
 {
  "length": 10098,
  "seq_id": "c00050_NODE_41..",
  "regions": []
 },
 {
  "length": 10043,
  "seq_id": "c00051_NODE_41..",
  "regions": []
 },
 {
  "length": 9950,
  "seq_id": "c00052_NODE_42..",
  "regions": []
 },
 {
  "length": 9914,
  "seq_id": "c00053_NODE_42..",
  "regions": []
 },
 {
  "length": 9804,
  "seq_id": "c00054_NODE_42..",
  "regions": []
 },
 {
  "length": 9574,
  "seq_id": "c00055_NODE_43..",
  "regions": []
 },
 {
  "length": 9563,
  "seq_id": "c00056_NODE_43..",
  "regions": []
 },
 {
  "length": 9430,
  "seq_id": "c00057_NODE_44..",
  "regions": []
 },
 {
  "length": 9385,
  "seq_id": "c00058_NODE_44..",
  "regions": []
 },
 {
  "length": 9307,
  "seq_id": "c00059_NODE_45..",
  "regions": []
 },
 {
  "length": 9052,
  "seq_id": "c00060_NODE_46..",
  "regions": []
 },
 {
  "length": 8905,
  "seq_id": "c00061_NODE_47..",
  "regions": []
 },
 {
  "length": 8890,
  "seq_id": "c00062_NODE_47..",
  "regions": []
 },
 {
  "length": 8802,
  "seq_id": "c00063_NODE_48..",
  "regions": []
 },
 {
  "length": 8687,
  "seq_id": "c00064_NODE_48..",
  "regions": []
 },
 {
  "length": 8618,
  "seq_id": "c00065_NODE_49..",
  "regions": []
 },
 {
  "length": 8570,
  "seq_id": "c00066_NODE_49..",
  "regions": []
 },
 {
  "length": 8505,
  "seq_id": "c00067_NODE_50..",
  "regions": []
 },
 {
  "length": 8481,
  "seq_id": "c00068_NODE_50..",
  "regions": []
 },
 {
  "length": 8385,
  "seq_id": "c00069_NODE_50..",
  "regions": []
 },
 {
  "length": 8362,
  "seq_id": "c00070_NODE_51..",
  "regions": []
 },
 {
  "length": 8227,
  "seq_id": "c00071_NODE_52..",
  "regions": []
 },
 {
  "length": 8108,
  "seq_id": "c00072_NODE_52..",
  "regions": []
 },
 {
  "length": 8026,
  "seq_id": "c00073_NODE_53..",
  "regions": []
 },
 {
  "length": 8025,
  "seq_id": "c00074_NODE_53..",
  "regions": []
 },
 {
  "length": 7987,
  "seq_id": "c00075_NODE_53..",
  "regions": []
 },
 {
  "length": 7914,
  "seq_id": "c00076_NODE_54..",
  "regions": []
 },
 {
  "length": 7831,
  "seq_id": "c00077_NODE_54..",
  "regions": []
 },
 {
  "length": 7782,
  "seq_id": "c00078_NODE_55..",
  "regions": []
 },
 {
  "length": 7751,
  "seq_id": "c00079_NODE_55..",
  "regions": []
 },
 {
  "length": 7694,
  "seq_id": "c00080_NODE_56..",
  "regions": []
 },
 {
  "length": 7670,
  "seq_id": "c00081_NODE_56..",
  "regions": []
 },
 {
  "length": 7592,
  "seq_id": "c00082_NODE_56..",
  "regions": []
 },
 {
  "length": 7505,
  "seq_id": "c00083_NODE_57..",
  "regions": [
   {
    "start": 1,
    "end": 7505,
    "idx": 1,
    "orfs": [
     {
      "start": 2,
      "end": 169,
      "strand": -1,
      "locus_tag": "ctg83_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2 - 169,\n (total: 168 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSEEYSTERLLCEQGSLVHTIKGVSMMPLLDQNKDAVHLIPVNRELQKNDIVLFKR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSEEYSTERLLCEQGSLVHTIKGVSMMPLLDQNKDAVHLIPVNRELQKNDIVLFKR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCGAGGAATATTCAACAGAGAGGCTTCTGTGCGAACAAGGCTCGCTCGTGCATACGATAAAGGGCGTTTCCATGATGCCGCTGCTCGACCAAAATAAAGACGCAGTGCATCTCATCCCCGTAAACCGCGAACTGCAAAAGAACGATATCGTTCTCTTCAAGCGG\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 166,
      "end": 435,
      "strand": -1,
      "locus_tag": "ctg83_2",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 166 - 435,\n (total: 270 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKLKEGFIITKNGNDYIAVAAGEAGKAFNGMIKMNGTAGFIATLLAESDTTAEKVTDAVCEKYEVERDVALENVLKVIDTLRKQGLVEE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKLKEGFIITKNGNDYIAVAAGEAGKAFNGMIKMNGTAGFIATLLAESDTTAEKVTDAVCEKYEVERDVALENVLKVIDTLRKQGLVEE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGCTTAAAGAAGGATTTATCATCACCAAAAACGGAAACGATTATATCGCCGTTGCCGCAGGGGAAGCGGGCAAAGCATTCAACGGAATGATAAAAATGAACGGCACGGCAGGCTTTATCGCCACACTTCTCGCAGAGAGCGACACCACAGCCGAAAAGGTGACTGATGCCGTATGCGAAAAATACGAGGTTGAACGCGATGTAGCTCTCGAAAATGTGCTGAAGGTCATTGACACGCTTAGAAAGCAGGGCTTGGTAGAGGAATGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 432,
      "end": 1154,
      "strand": -1,
      "locus_tag": "ctg83_3",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 432 - 1,154,\n (total: 723 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKYKNTYLLAGIPVEMICTGEYLVRQCRDYITDMTPEFSIEMTEDDIAAEKERSEDKSYSDGYYESLAFYRKLCDKIPDRGIILFHSCAVAVDGKAYLFTAPSGTGKSTHASLWKEILGERVRIINGDKPLIRVIPGHITVYGTPWNGKERWGENSHADIAGICFLSRATENKIVPVSGSDAMPLLYRQTYRTPTAEGLAHVMRSLAEIAQRIPLWRLECNISQEAAELSYNTMSKGEKQ&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKYKNTYLLAGIPVEMICTGEYLVRQCRDYITDMTPEFSIEMTEDDIAAEKERSEDKSYSDGYYESLAFYRKLCDKIPDRGIILFHSCAVAVDGKAYLFTAPSGTGKSTHASLWKEILGERVRIINGDKPLIRVIPGHITVYGTPWNGKERWGENSHADIAGICFLSRATENKIVPVSGSDAMPLLYRQTYRTPTAEGLAHVMRSLAEIAQRIPLWRLECNISQEAAELSYNTMSKGEKQ\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAATATAAAAACACATATCTTCTCGCCGGTATTCCCGTGGAAATGATATGCACGGGCGAATATCTCGTGCGACAGTGCCGCGATTATATTACAGACATGACACCGGAATTTTCCATAGAAATGACAGAGGACGATATCGCGGCGGAAAAAGAGCGCTCGGAAGATAAAAGCTACTCTGACGGGTATTATGAGTCCCTCGCTTTTTACAGAAAGCTATGTGACAAAATTCCGGACAGAGGAATAATCCTCTTTCACAGCTGTGCTGTGGCTGTAGACGGAAAGGCATACCTTTTCACCGCGCCGTCCGGCACGGGAAAAAGTACGCACGCTTCCCTCTGGAAAGAGATTCTCGGAGAGCGCGTGCGCATCATAAACGGCGACAAACCGCTTATCAGGGTAATACCCGGGCACATAACGGTATACGGCACTCCATGGAACGGCAAGGAGCGCTGGGGCGAAAATTCGCATGCGGATATAGCAGGCATATGCTTCCTCTCGCGCGCCACGGAAAATAAGATCGTGCCTGTCTCCGGAAGTGACGCAATGCCGCTTCTCTACCGCCAGACATACAGAACACCCACAGCCGAGGGGCTTGCACATGTAATGCGAAGCCTCGCCGAAATAGCACAGCGCATACCGCTCTGGCGGCTTGAATGCAATATATCGCAGGAAGCCGCCGAGCTTTCATACAATACGATGAGTAAAGGAGAAAAACAATGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 1164,
      "end": 2042,
      "strand": -1,
      "locus_tag": "ctg83_4",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,164 - 2,042,\n (total: 879 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKKVFSLIIALALIFAALFSLSSCFYVNSSEPNYVNYRKYDNAEKYMVGGFSYSSSGIEKVEIDWVAGEVNATATESDILSVYENGTSLAESEQLHYYSDGKTLIIRYCKSLFRGVIDPEQKSLNIEIPHGVELEITSVSADVFSGNLDMKDIRISNVSGDTTITAACADDIDISSVSGDIFVSHAKATDNLEFESVSGDIRNDRAEAGTIKAGSVSGDVELGIFDAAAVDIDTTSGDIVLTLIGDIGIDLDFSTTSGKHSAESDYKTGAKRCTVKAKTVSGDLSTKRNSKV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKKVFSLIIALALIFAALFSLSSCFYVNSSEPNYVNYRKYDNAEKYMVGGFSYSSSGIEKVEIDWVAGEVNATATESDILSVYENGTSLAESEQLHYYSDGKTLIIRYCKSLFRGVIDPEQKSLNIEIPHGVELEITSVSADVFSGNLDMKDIRISNVSGDTTITAACADDIDISSVSGDIFVSHAKATDNLEFESVSGDIRNDRAEAGTIKAGSVSGDVELGIFDAAAVDIDTTSGDIVLTLIGDIGIDLDFSTTSGKHSAESDYKTGAKRCTVKAKTVSGDLSTKRNSKV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAAAGGTATTTTCGCTGATTATCGCACTTGCGCTCATATTTGCCGCTCTGTTTTCGCTCTCATCATGTTTTTATGTCAACAGCAGTGAGCCAAACTATGTAAACTACCGAAAATATGACAATGCCGAAAAATACATGGTAGGCGGCTTCTCCTATTCATCAAGCGGAATAGAAAAAGTTGAGATAGACTGGGTAGCAGGCGAAGTGAATGCCACGGCTACGGAAAGCGACATTCTGAGCGTTTACGAAAACGGGACAAGCCTCGCCGAAAGCGAACAGCTGCACTATTATTCCGACGGCAAAACACTTATCATAAGATATTGTAAATCTCTTTTCAGAGGAGTAATCGACCCCGAGCAAAAGAGTCTGAATATAGAAATCCCTCACGGAGTTGAACTGGAAATAACCTCTGTCAGCGCCGATGTTTTCTCGGGTAACCTTGATATGAAGGATATCAGAATATCCAACGTCTCCGGCGATACGACAATAACAGCCGCCTGCGCCGATGATATTGATATATCGTCCGTATCGGGAGATATATTCGTATCCCATGCAAAAGCTACAGACAATCTGGAATTTGAAAGCGTTTCCGGCGATATAAGAAATGACCGCGCCGAAGCAGGCACCATAAAGGCGGGCAGCGTTTCCGGCGATGTTGAGCTCGGCATTTTCGATGCTGCGGCAGTCGATATAGACACCACAAGCGGAGATATAGTTCTCACCCTAATCGGTGATATAGGAATAGACCTTGATTTCTCCACCACCTCCGGAAAGCACTCTGCCGAATCCGATTATAAAACGGGAGCAAAAAGATGCACTGTAAAAGCTAAAACCGTCAGCGGCGATCTCTCCACAAAGCGAAACAGTAAGGTATAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 2200,
      "end": 2568,
      "strand": 1,
      "locus_tag": "ctg83_5",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,200 - 2,568,\n (total: 369 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MEIILVGACGKMGREVARGLFDGMHIAASVDLRSHCKNISDYRGEADVIIDFSSHTATEETLTYAVRRGLPCVIASTGQNSRERAALTRAAAHIPVFYSENMSLGIAVLLESAKAAAEIMPR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MEIILVGACGKMGREVARGLFDGMHIAASVDLRSHCKNISDYRGEADVIIDFSSHTATEETLTYAVRRGLPCVIASTGQNSRERAALTRAAAHIPVFYSENMSLGIAVLLESAKAAAEIMPR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGAGATAATACTTGTCGGAGCCTGCGGCAAAATGGGCAGAGAAGTAGCAAGGGGGCTTTTTGACGGTATGCATATTGCAGCTTCCGTGGATTTGCGTTCACACTGCAAAAATATATCCGATTACAGGGGTGAGGCAGATGTGATAATAGATTTTTCTTCGCATACGGCAACGGAGGAAACACTCACATATGCCGTGCGACGAGGGCTTCCGTGCGTTATCGCCTCTACCGGTCAAAACAGCCGCGAGAGAGCGGCACTGACAAGGGCGGCGGCGCATATTCCGGTTTTTTATTCCGAAAATATGTCGCTCGGAATAGCCGTACTGCTCGAATCGGCAAAAGCGGCGGCGGAGATAATGCCGAGATAG\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 2625,
      "end": 2906,
      "strand": 1,
      "locus_tag": "ctg83_6",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,625 - 2,906,\n (total: 282 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLARELLSENGRIVTARNGDEPRAGHDIGISSVRIGNIRGYHEVIISNGKETLSFSHEVEDRSVFARGALSAACFIIKKEKGLYGMYDLIHLK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLARELLSENGRIVTARNGDEPRAGHDIGISSVRIGNIRGYHEVIISNGKETLSFSHEVEDRSVFARGALSAACFIIKKEKGLYGMYDLIHLK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTCGCAAGAGAATTGCTTTCCGAAAACGGGCGTATCGTGACGGCGAGAAACGGAGACGAGCCGCGTGCCGGGCATGATATCGGCATTTCCAGCGTGCGCATAGGAAATATCAGGGGCTACCATGAGGTAATCATTTCAAACGGAAAGGAAACGCTGTCTTTTTCCCATGAGGTGGAGGACAGGAGCGTTTTCGCGAGAGGAGCGCTGAGCGCGGCGTGCTTTATCATAAAAAAAGAAAAAGGACTCTACGGAATGTATGACCTGATACATCTGAAATAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 2983,
      "end": 3156,
      "strand": 1,
      "locus_tag": "ctg83_7",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,983 - 3,156,\n (total: 174 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTEKELLYIEDALGHEKYFKDKCNETIANLQDPELKNLVSTMLEKHGKIYQSFYNLL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTEKELLYIEDALGHEKYFKDKCNETIANLQDPELKNLVSTMLEKHGKIYQSFYNLL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGGAAAAAGAACTTTTATATATTGAGGACGCACTCGGACACGAAAAATACTTCAAGGACAAATGCAACGAGACAATAGCAAATCTGCAGGATCCGGAGCTTAAAAATCTCGTTTCGACGATGCTCGAAAAGCACGGAAAAATTTATCAGAGCTTCTATAATCTGCTCTGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 3173,
      "end": 3415,
      "strand": 1,
      "locus_tag": "ctg83_8",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,173 - 3,415,\n (total: 243 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDDRNLMETLLLLEKGVCSLYMHGTIESSTASVNKTFGDALGESLGIQGTVYDKMAAKGWYQTTAAEQNKIQTVKQKFTM&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDDRNLMETLLLLEKGVCSLYMHGTIESSTASVNKTFGDALGESLGIQGTVYDKMAAKGWYQTTAAEQNKIQTVKQKFTM\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGACGACAGAAATCTTATGGAAACGCTCCTTTTGCTTGAGAAGGGTGTTTGCAGTCTTTATATGCACGGCACAATAGAATCCTCTACGGCGAGCGTAAACAAGACATTTGGCGATGCTCTCGGAGAATCACTCGGCATACAGGGTACGGTTTATGACAAGATGGCGGCAAAGGGCTGGTATCAGACGACTGCTGCCGAGCAGAACAAAATTCAGACAGTGAAGCAGAAATTCACGATGTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 3470,
      "end": 4408,
      "strand": -1,
      "locus_tag": "ctg83_9",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,470 - 4,408,\n (total: 939 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Abi<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MINFRKKYPIIAGTLCAILMLAVQAVVQAGFALLTENMTYPKYLPMLLADAVCIAVGIALAFALGLKDIFRSSREGFLHGLGTGGYFIFISVSTLIVSISSSKHGAPLSSVEIAVFVLAMAAVGFAEEIFFRGILSRMIFEKYGEDACGVWFSAIVSGLIFGSVHFINALHADIVGVAVQAVCAAAIGICLTALYYRTGNIYVVASLHAFMDFCALFSSGVFGEGSLSGTISNYSPLQLISALPYIVVSLVLLRRLKMAALLHKPSDSIIAVIGKLSSSQKSKNRLMWLIFCIVLAGLAVYAAKVIRLAIKL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MINFRKKYPIIAGTLCAILMLAVQAVVQAGFALLTENMTYPKYLPMLLADAVCIAVGIALAFALGLKDIFRSSREGFLHGLGTGGYFIFISVSTLIVSISSSKHGAPLSSVEIAVFVLAMAAVGFAEEIFFRGILSRMIFEKYGEDACGVWFSAIVSGLIFGSVHFINALHADIVGVAVQAVCAAAIGICLTALYYRTGNIYVVASLHAFMDFCALFSSGVFGEGSLSGTISNYSPLQLISALPYIVVSLVLLRRLKMAALLHKPSDSIIAVIGKLSSSQKSKNRLMWLIFCIVLAGLAVYAAKVIRLAIKL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATAAATTTCAGAAAAAAGTATCCCATTATCGCGGGAACTCTCTGCGCCATTCTGATGCTTGCCGTGCAGGCTGTCGTGCAGGCAGGATTTGCCCTTCTCACTGAGAATATGACATATCCGAAGTACCTGCCCATGCTCCTTGCGGACGCCGTCTGCATTGCCGTAGGTATCGCGCTTGCCTTCGCTCTCGGGTTGAAAGATATTTTTCGCTCATCGCGTGAGGGCTTTCTTCATGGGCTCGGTACGGGCGGATATTTCATATTTATATCGGTATCCACCCTCATCGTCAGCATCAGCTCATCAAAGCACGGCGCTCCGCTCTCTTCGGTTGAAATAGCGGTTTTTGTGCTCGCAATGGCAGCGGTCGGCTTTGCCGAAGAAATATTCTTCCGCGGGATACTCTCGCGTATGATTTTTGAAAAATACGGCGAAGATGCATGCGGCGTTTGGTTTTCCGCCATAGTATCAGGGCTGATATTCGGTTCTGTTCATTTTATCAATGCGCTTCATGCCGATATCGTCGGAGTTGCTGTTCAGGCGGTATGCGCTGCCGCTATCGGTATATGCCTCACCGCACTTTATTACAGGACGGGAAACATATATGTAGTTGCCTCTCTCCATGCTTTCATGGATTTCTGTGCGCTTTTTTCTTCCGGAGTATTCGGTGAAGGAAGCCTGTCGGGCACCATCAGCAATTACAGCCCGTTGCAGCTCATTTCGGCACTGCCGTATATCGTGGTTTCACTCGTGCTCCTGCGCAGACTGAAAATGGCGGCGCTCCTGCATAAGCCTTCCGACAGCATAATAGCAGTCATCGGCAAGCTTTCCTCATCGCAGAAATCGAAAAACCGCCTCATGTGGCTTATCTTCTGTATAGTGCTTGCGGGACTCGCTGTCTATGCCGCAAAGGTAATACGGCTGGCAATAAAATTATAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 4509,
      "end": 5726,
      "strand": -1,
      "locus_tag": "ctg83_10",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,509 - 5,726,\n (total: 1218 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNNFKKMAALFLALTMVCLAFASCGKKPQEKKGTPVAIVDGEIIYGNDQEILDYLAYYVWMNKIELPTDDKISYAYTTAVTYCTDSVVWYKIYEKELAAKGITFSEKKLKDEIDKAKSFFDDQDGGYEGFRKSLRLSKNFVYNIVKYEAISKEIISIISEKCNVSDEEALAYFNEHISEYTHAPGIVYDAILLEILDMQDASEVAAKKAEAEEYIKKITGGMDFDAAREEVKKKYSGDKYFYTGFASGEATLAEGEYIKVDDLDAEKKTIEEMMAEKNIKIDANANKDSDEYKNYESYINSLYRAELMYALTTATKSGEIYSKPILSTIGYVVVKNIKHNETISFTNFGDVKDEIKETISGEKFDKEVDNYREEMIKKYGVVFNKTDVNWQTSESESTTATTAAN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNNFKKMAALFLALTMVCLAFASCGKKPQEKKGTPVAIVDGEIIYGNDQEILDYLAYYVWMNKIELPTDDKISYAYTTAVTYCTDSVVWYKIYEKELAAKGITFSEKKLKDEIDKAKSFFDDQDGGYEGFRKSLRLSKNFVYNIVKYEAISKEIISIISEKCNVSDEEALAYFNEHISEYTHAPGIVYDAILLEILDMQDASEVAAKKAEAEEYIKKITGGMDFDAAREEVKKKYSGDKYFYTGFASGEATLAEGEYIKVDDLDAEKKTIEEMMAEKNIKIDANANKDSDEYKNYESYINSLYRAELMYALTTATKSGEIYSKPILSTIGYVVVKNIKHNETISFTNFGDVKDEIKETISGEKFDKEVDNYREEMIKKYGVVFNKTDVNWQTSESESTTATTAAN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAATAATTTTAAAAAGATGGCGGCGCTTTTCCTTGCGCTGACTATGGTCTGCCTTGCTTTTGCATCGTGCGGAAAGAAGCCGCAGGAAAAAAAGGGCACTCCCGTCGCTATAGTCGACGGAGAAATAATCTACGGAAACGATCAGGAAATTCTTGATTATCTCGCATACTATGTATGGATGAATAAAATCGAGTTGCCGACAGACGATAAGATTTCTTATGCTTATACCACCGCCGTAACATACTGTACGGATTCTGTTGTCTGGTACAAAATCTATGAAAAAGAGCTTGCTGCAAAGGGCATTACTTTCAGCGAGAAAAAGCTCAAGGACGAAATTGATAAAGCAAAATCGTTTTTCGATGATCAGGACGGCGGCTATGAGGGTTTCCGTAAAAGCTTGAGACTCTCCAAGAATTTTGTCTACAATATAGTAAAATACGAGGCAATTTCAAAAGAGATTATCTCAATAATATCAGAAAAATGCAATGTTTCCGACGAAGAAGCACTTGCTTATTTCAATGAGCATATAAGCGAATATACGCACGCCCCCGGCATTGTATATGACGCGATCCTGCTCGAAATTCTCGATATGCAGGATGCTTCCGAGGTCGCGGCAAAAAAAGCCGAAGCCGAGGAATATATCAAAAAAATAACAGGCGGAATGGACTTTGATGCCGCACGCGAAGAAGTCAAGAAGAAATACAGCGGTGATAAGTATTTCTACACGGGCTTTGCTTCCGGCGAGGCTACCCTTGCCGAGGGCGAATATATAAAAGTGGATGACCTCGATGCGGAGAAAAAGACTATCGAAGAAATGATGGCTGAAAAGAATATAAAAATCGACGCCAACGCCAACAAGGATTCTGATGAATATAAGAATTACGAATCATACATCAATTCGCTCTACCGTGCAGAATTGATGTACGCGCTCACCACGGCGACAAAGAGCGGCGAGATATACAGTAAGCCGATTCTTTCTACCATAGGCTATGTCGTAGTGAAAAATATAAAACATAATGAAACCATTTCATTCACAAACTTCGGCGATGTAAAGGATGAAATCAAAGAGACAATCTCCGGCGAAAAATTTGATAAAGAGGTTGACAACTATCGCGAAGAAATGATAAAAAAATACGGTGTTGTTTTCAATAAAACAGATGTAAACTGGCAGACAAGCGAAAGCGAGTCCACCACAGCTACAACGGCGGCAAACTGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 5817,
      "end": 6302,
      "strand": -1,
      "locus_tag": "ctg83_11",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,817 - 6,302,\n (total: 486 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTLTEKVAYIKGLVAALETDKNDKVFSAVLDLLSDLAATVSDLDDKSEYLEKYIEEVDEDLGALEDEFYGDECDDCECKDCAEEDCDCRCDDCLDDDCDCCDDDCDCIEVECPYCGETVCLDDTVDFDNVKCPACGETFSCVCDDDCDCCDDDDCGCGCEH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTLTEKVAYIKGLVAALETDKNDKVFSAVLDLLSDLAATVSDLDDKSEYLEKYIEEVDEDLGALEDEFYGDECDDCECKDCAEEDCDCRCDDCLDDDCDCCDDDCDCIEVECPYCGETVCLDDTVDFDNVKCPACGETFSCVCDDDCDCCDDDDCGCGCEH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACACTTACCGAAAAAGTTGCTTATATAAAGGGTCTTGTAGCCGCTCTCGAAACAGACAAGAACGATAAGGTTTTCTCTGCTGTGCTTGATCTTCTCTCCGACCTTGCCGCTACGGTCTCCGATCTTGACGACAAGTCAGAGTATCTTGAAAAGTACATCGAAGAGGTTGACGAGGATCTCGGCGCTCTCGAAGATGAATTCTACGGCGATGAGTGCGACGATTGCGAATGCAAGGATTGCGCAGAAGAAGATTGCGACTGCCGTTGCGACGATTGTCTCGATGACGATTGCGACTGCTGCGACGACGACTGCGACTGCATAGAGGTAGAATGCCCTTACTGCGGCGAGACGGTATGCCTCGATGATACCGTTGATTTTGACAATGTAAAGTGCCCTGCCTGCGGCGAAACCTTCAGCTGTGTCTGCGACGACGATTGCGACTGCTGTGATGATGACGACTGCGGTTGCGGTTGCGAGCACTGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 6337,
      "end": 6903,
      "strand": -1,
      "locus_tag": "ctg83_12",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,337 - 6,903,\n (total: 567 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MVIAGDFKNGITFEMDGNVMQVIEFQHVKPGKGAAFVRTKLRNVISGAVVEKTFSPTDKFPPAIVDRRDMQYSYNDGDLYYFMDMESYDMIPVSKSLLPDNFKFVKEEMMCKIVSYKGNVFSVEPPMFVELQVTEVEPGFKGDTAQGAKKPATLETGATIQVPLFIENGEILRIDTRTGEYLERVKTK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MVIAGDFKNGITFEMDGNVMQVIEFQHVKPGKGAAFVRTKLRNVISGAVVEKTFSPTDKFPPAIVDRRDMQYSYNDGDLYYFMDMESYDMIPVSKSLLPDNFKFVKEEMMCKIVSYKGNVFSVEPPMFVELQVTEVEPGFKGDTAQGAKKPATLETGATIQVPLFIENGEILRIDTRTGEYLERVKTK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGTTATCGCAGGCGATTTTAAAAACGGCATTACATTTGAAATGGACGGGAATGTAATGCAGGTTATCGAATTCCAGCATGTAAAACCCGGCAAGGGCGCGGCTTTCGTCCGCACAAAGCTGAGAAATGTCATTTCCGGTGCTGTCGTCGAAAAGACCTTCAGCCCCACAGACAAGTTCCCGCCCGCTATCGTTGACAGAAGAGATATGCAGTATTCCTACAATGACGGCGATCTCTACTACTTCATGGATATGGAATCATACGATATGATTCCCGTTTCCAAGAGCCTTCTTCCCGACAACTTCAAGTTCGTAAAGGAAGAAATGATGTGCAAGATCGTTTCCTACAAGGGAAATGTATTCAGCGTTGAGCCTCCTATGTTCGTAGAGCTTCAGGTTACCGAGGTTGAGCCCGGTTTTAAGGGTGATACGGCTCAGGGCGCAAAGAAACCCGCTACTCTTGAAACAGGAGCTACTATCCAGGTTCCGCTTTTCATCGAAAACGGTGAAATCCTCCGCATCGACACAAGAACAGGCGAATATCTCGAAAGAGTAAAAACGAAATAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 7024,
      "end": 7503,
      "strand": -1,
      "locus_tag": "ctg83_13",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,024 - 7,503,\n (total: 480 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=RPHGVPRNVKLERGFLTMDFGCILNGYCSDMTRTVSVGKADEEMKKVYNTVLRAQTAAIDFIREGVLCCDADKVARDIIDADYKGYFGHSLGHGVGMYIHEEPRLSARCTKVLKVGHVVTVEPGIYIPGKYGVRIEDMMQITPSGAIDITKSPKNLIEI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"RPHGVPRNVKLERGFLTMDFGCILNGYCSDMTRTVSVGKADEEMKKVYNTVLRAQTAAIDFIREGVLCCDADKVARDIIDADYKGYFGHSLGHGVGMYIHEEPRLSARCTKVLKVGHVVTVEPGIYIPGKYGVRIEDMMQITPSGAIDITKSPKNLIEI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"CGTCCTCACGGTGTTCCGAGAAACGTAAAGCTTGAACGCGGATTTCTCACGATGGACTTCGGTTGCATTCTGAACGGCTACTGCTCCGATATGACGCGTACCGTTTCCGTCGGCAAAGCTGACGAAGAAATGAAAAAGGTTTACAATACCGTCCTGCGCGCACAGACCGCAGCTATAGATTTCATCCGCGAGGGTGTTCTCTGCTGCGATGCGGACAAGGTTGCCCGCGACATCATAGACGCCGATTACAAGGGATACTTCGGTCACTCTCTCGGTCACGGCGTAGGAATGTATATCCATGAGGAGCCGCGTCTCTCCGCCAGATGCACAAAGGTGCTGAAGGTCGGTCATGTCGTCACGGTCGAGCCCGGCATTTATATCCCCGGAAAATACGGCGTCAGAATAGAGGATATGATGCAGATTACACCTTCCGGAGCAATTGACATCACAAAAAGTCCGAAAAATCTTATAGAAATATAA\">Copy to clipboard</span><br>\n</div>"
     }
    ],
    "clusters": [
     {
      "start": 165,
      "end": 435,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 7505,
      "product": "RRE-containing",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "ttaCodons": [],
    "type": "RRE-containing",
    "products": [
     "RRE-containing"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP RRE-containing",
    "anchor": "r83c1"
   }
  ]
 },
 {
  "length": 7498,
  "seq_id": "c00084_NODE_57..",
  "regions": []
 },
 {
  "length": 7393,
  "seq_id": "c00085_NODE_58..",
  "regions": []
 },
 {
  "length": 7380,
  "seq_id": "c00086_NODE_58..",
  "regions": []
 },
 {
  "length": 7334,
  "seq_id": "c00087_NODE_58..",
  "regions": []
 },
 {
  "length": 7156,
  "seq_id": "c00088_NODE_60..",
  "regions": []
 },
 {
  "length": 7142,
  "seq_id": "c00089_NODE_60..",
  "regions": []
 },
 {
  "length": 6636,
  "seq_id": "c00090_NODE_65..",
  "regions": []
 },
 {
  "length": 6633,
  "seq_id": "c00091_NODE_65..",
  "regions": []
 },
 {
  "length": 6567,
  "seq_id": "c00092_NODE_65..",
  "regions": []
 },
 {
  "length": 6541,
  "seq_id": "c00093_NODE_65..",
  "regions": []
 },
 {
  "length": 6455,
  "seq_id": "c00094_NODE_66..",
  "regions": []
 },
 {
  "length": 6374,
  "seq_id": "c00095_NODE_67..",
  "regions": []
 },
 {
  "length": 6364,
  "seq_id": "c00096_NODE_67..",
  "regions": []
 },
 {
  "length": 6318,
  "seq_id": "c00097_NODE_68..",
  "regions": []
 },
 {
  "length": 6312,
  "seq_id": "c00098_NODE_68..",
  "regions": []
 },
 {
  "length": 6283,
  "seq_id": "c00099_NODE_68..",
  "regions": []
 },
 {
  "length": 6208,
  "seq_id": "c00100_NODE_69..",
  "regions": []
 },
 {
  "length": 6119,
  "seq_id": "c00101_NODE_71..",
  "regions": []
 },
 {
  "length": 5910,
  "seq_id": "c00102_NODE_73..",
  "regions": []
 },
 {
  "length": 5878,
  "seq_id": "c00103_NODE_74..",
  "regions": []
 },
 {
  "length": 5781,
  "seq_id": "c00104_NODE_75..",
  "regions": []
 },
 {
  "length": 5721,
  "seq_id": "c00105_NODE_76..",
  "regions": []
 },
 {
  "length": 5679,
  "seq_id": "c00106_NODE_77..",
  "regions": []
 },
 {
  "length": 5651,
  "seq_id": "c00107_NODE_77..",
  "regions": []
 },
 {
  "length": 5433,
  "seq_id": "c00108_NODE_81..",
  "regions": []
 },
 {
  "length": 5407,
  "seq_id": "c00109_NODE_81..",
  "regions": []
 },
 {
  "length": 5316,
  "seq_id": "c00110_NODE_82..",
  "regions": []
 },
 {
  "length": 5309,
  "seq_id": "c00111_NODE_82..",
  "regions": []
 },
 {
  "length": 5297,
  "seq_id": "c00112_NODE_83..",
  "regions": []
 },
 {
  "length": 5160,
  "seq_id": "c00113_NODE_85..",
  "regions": []
 },
 {
  "length": 5140,
  "seq_id": "c00114_NODE_85..",
  "regions": []
 },
 {
  "length": 5010,
  "seq_id": "c00115_NODE_88..",
  "regions": []
 },
 {
  "length": 4983,
  "seq_id": "c00116_NODE_89..",
  "regions": []
 },
 {
  "length": 4979,
  "seq_id": "c00117_NODE_89..",
  "regions": []
 },
 {
  "length": 4965,
  "seq_id": "c00118_NODE_89..",
  "regions": []
 },
 {
  "length": 4911,
  "seq_id": "c00119_NODE_90..",
  "regions": []
 },
 {
  "length": 4851,
  "seq_id": "c00120_NODE_91..",
  "regions": []
 },
 {
  "length": 4817,
  "seq_id": "c00121_NODE_92..",
  "regions": []
 },
 {
  "length": 4813,
  "seq_id": "c00122_NODE_92..",
  "regions": []
 },
 {
  "length": 4770,
  "seq_id": "c00123_NODE_93..",
  "regions": []
 },
 {
  "length": 4766,
  "seq_id": "c00124_NODE_93..",
  "regions": []
 },
 {
  "length": 4724,
  "seq_id": "c00125_NODE_94..",
  "regions": []
 },
 {
  "length": 4640,
  "seq_id": "c00126_NODE_95..",
  "regions": []
 },
 {
  "length": 4624,
  "seq_id": "c00127_NODE_96..",
  "regions": []
 },
 {
  "length": 4450,
  "seq_id": "c00128_NODE_10..",
  "regions": []
 },
 {
  "length": 4283,
  "seq_id": "c00129_NODE_10..",
  "regions": []
 },
 {
  "length": 4239,
  "seq_id": "c00130_NODE_10..",
  "regions": []
 },
 {
  "length": 4146,
  "seq_id": "c00131_NODE_10..",
  "regions": []
 },
 {
  "length": 4137,
  "seq_id": "c00132_NODE_10..",
  "regions": []
 },
 {
  "length": 3999,
  "seq_id": "c00133_NODE_11..",
  "regions": []
 },
 {
  "length": 3998,
  "seq_id": "c00134_NODE_11..",
  "regions": []
 },
 {
  "length": 3875,
  "seq_id": "c00135_NODE_11..",
  "regions": []
 },
 {
  "length": 3830,
  "seq_id": "c00136_NODE_11..",
  "regions": []
 },
 {
  "length": 3810,
  "seq_id": "c00137_NODE_11..",
  "regions": []
 },
 {
  "length": 3746,
  "seq_id": "c00138_NODE_12..",
  "regions": []
 },
 {
  "length": 3622,
  "seq_id": "c00139_NODE_12..",
  "regions": []
 },
 {
  "length": 3612,
  "seq_id": "c00140_NODE_12..",
  "regions": []
 },
 {
  "length": 3585,
  "seq_id": "c00141_NODE_12..",
  "regions": []
 },
 {
  "length": 3416,
  "seq_id": "c00142_NODE_13..",
  "regions": []
 },
 {
  "length": 3382,
  "seq_id": "c00143_NODE_13..",
  "regions": []
 },
 {
  "length": 3306,
  "seq_id": "c00144_NODE_13..",
  "regions": []
 },
 {
  "length": 3292,
  "seq_id": "c00145_NODE_13..",
  "regions": []
 },
 {
  "length": 3199,
  "seq_id": "c00146_NODE_14..",
  "regions": []
 },
 {
  "length": 3177,
  "seq_id": "c00147_NODE_14..",
  "regions": []
 },
 {
  "length": 3107,
  "seq_id": "c00148_NODE_14..",
  "regions": []
 },
 {
  "length": 3096,
  "seq_id": "c00149_NODE_14..",
  "regions": []
 },
 {
  "length": 3085,
  "seq_id": "c00150_NODE_14..",
  "regions": []
 },
 {
  "length": 3044,
  "seq_id": "c00151_NODE_15..",
  "regions": []
 },
 {
  "length": 3026,
  "seq_id": "c00152_NODE_15..",
  "regions": []
 },
 {
  "length": 3020,
  "seq_id": "c00153_NODE_15..",
  "regions": []
 },
 {
  "length": 2947,
  "seq_id": "c00154_NODE_15..",
  "regions": []
 },
 {
  "length": 2825,
  "seq_id": "c00155_NODE_16..",
  "regions": []
 },
 {
  "length": 2796,
  "seq_id": "c00156_NODE_16..",
  "regions": []
 },
 {
  "length": 2750,
  "seq_id": "c00157_NODE_16..",
  "regions": []
 },
 {
  "length": 2745,
  "seq_id": "c00158_NODE_16..",
  "regions": []
 },
 {
  "length": 2741,
  "seq_id": "c00159_NODE_16..",
  "regions": []
 },
 {
  "length": 2688,
  "seq_id": "c00160_NODE_17..",
  "regions": []
 },
 {
  "length": 2683,
  "seq_id": "c00161_NODE_17..",
  "regions": []
 },
 {
  "length": 2558,
  "seq_id": "c00162_NODE_18..",
  "regions": []
 },
 {
  "length": 2525,
  "seq_id": "c00163_NODE_18..",
  "regions": []
 },
 {
  "length": 2504,
  "seq_id": "c00164_NODE_18..",
  "regions": []
 },
 {
  "length": 2471,
  "seq_id": "c00165_NODE_18..",
  "regions": []
 },
 {
  "length": 2466,
  "seq_id": "c00166_NODE_19..",
  "regions": []
 },
 {
  "length": 2421,
  "seq_id": "c00167_NODE_19..",
  "regions": []
 },
 {
  "length": 2321,
  "seq_id": "c00168_NODE_20..",
  "regions": []
 },
 {
  "length": 2302,
  "seq_id": "c00169_NODE_20..",
  "regions": []
 },
 {
  "length": 2114,
  "seq_id": "c00170_NODE_22..",
  "regions": []
 },
 {
  "length": 2064,
  "seq_id": "c00171_NODE_23..",
  "regions": []
 },
 {
  "length": 2028,
  "seq_id": "c00172_NODE_23..",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r83c1"
 ],
 "r83c1": {
  "start": 1,
  "end": 7505,
  "idx": 1,
  "orfs": [
   {
    "start": 2,
    "end": 169,
    "strand": -1,
    "locus_tag": "ctg83_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2 - 169,\n (total: 168 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSEEYSTERLLCEQGSLVHTIKGVSMMPLLDQNKDAVHLIPVNRELQKNDIVLFKR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSEEYSTERLLCEQGSLVHTIKGVSMMPLLDQNKDAVHLIPVNRELQKNDIVLFKR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCGAGGAATATTCAACAGAGAGGCTTCTGTGCGAACAAGGCTCGCTCGTGCATACGATAAAGGGCGTTTCCATGATGCCGCTGCTCGACCAAAATAAAGACGCAGTGCATCTCATCCCCGTAAACCGCGAACTGCAAAAGAACGATATCGTTCTCTTCAAGCGG\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 166,
    "end": 435,
    "strand": -1,
    "locus_tag": "ctg83_2",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 166 - 435,\n (total: 270 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKLKEGFIITKNGNDYIAVAAGEAGKAFNGMIKMNGTAGFIATLLAESDTTAEKVTDAVCEKYEVERDVALENVLKVIDTLRKQGLVEE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKLKEGFIITKNGNDYIAVAAGEAGKAFNGMIKMNGTAGFIATLLAESDTTAEKVTDAVCEKYEVERDVALENVLKVIDTLRKQGLVEE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGCTTAAAGAAGGATTTATCATCACCAAAAACGGAAACGATTATATCGCCGTTGCCGCAGGGGAAGCGGGCAAAGCATTCAACGGAATGATAAAAATGAACGGCACGGCAGGCTTTATCGCCACACTTCTCGCAGAGAGCGACACCACAGCCGAAAAGGTGACTGATGCCGTATGCGAAAAATACGAGGTTGAACGCGATGTAGCTCTCGAAAATGTGCTGAAGGTCATTGACACGCTTAGAAAGCAGGGCTTGGTAGAGGAATGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 432,
    "end": 1154,
    "strand": -1,
    "locus_tag": "ctg83_3",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 432 - 1,154,\n (total: 723 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKYKNTYLLAGIPVEMICTGEYLVRQCRDYITDMTPEFSIEMTEDDIAAEKERSEDKSYSDGYYESLAFYRKLCDKIPDRGIILFHSCAVAVDGKAYLFTAPSGTGKSTHASLWKEILGERVRIINGDKPLIRVIPGHITVYGTPWNGKERWGENSHADIAGICFLSRATENKIVPVSGSDAMPLLYRQTYRTPTAEGLAHVMRSLAEIAQRIPLWRLECNISQEAAELSYNTMSKGEKQ&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKYKNTYLLAGIPVEMICTGEYLVRQCRDYITDMTPEFSIEMTEDDIAAEKERSEDKSYSDGYYESLAFYRKLCDKIPDRGIILFHSCAVAVDGKAYLFTAPSGTGKSTHASLWKEILGERVRIINGDKPLIRVIPGHITVYGTPWNGKERWGENSHADIAGICFLSRATENKIVPVSGSDAMPLLYRQTYRTPTAEGLAHVMRSLAEIAQRIPLWRLECNISQEAAELSYNTMSKGEKQ\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAATATAAAAACACATATCTTCTCGCCGGTATTCCCGTGGAAATGATATGCACGGGCGAATATCTCGTGCGACAGTGCCGCGATTATATTACAGACATGACACCGGAATTTTCCATAGAAATGACAGAGGACGATATCGCGGCGGAAAAAGAGCGCTCGGAAGATAAAAGCTACTCTGACGGGTATTATGAGTCCCTCGCTTTTTACAGAAAGCTATGTGACAAAATTCCGGACAGAGGAATAATCCTCTTTCACAGCTGTGCTGTGGCTGTAGACGGAAAGGCATACCTTTTCACCGCGCCGTCCGGCACGGGAAAAAGTACGCACGCTTCCCTCTGGAAAGAGATTCTCGGAGAGCGCGTGCGCATCATAAACGGCGACAAACCGCTTATCAGGGTAATACCCGGGCACATAACGGTATACGGCACTCCATGGAACGGCAAGGAGCGCTGGGGCGAAAATTCGCATGCGGATATAGCAGGCATATGCTTCCTCTCGCGCGCCACGGAAAATAAGATCGTGCCTGTCTCCGGAAGTGACGCAATGCCGCTTCTCTACCGCCAGACATACAGAACACCCACAGCCGAGGGGCTTGCACATGTAATGCGAAGCCTCGCCGAAATAGCACAGCGCATACCGCTCTGGCGGCTTGAATGCAATATATCGCAGGAAGCCGCCGAGCTTTCATACAATACGATGAGTAAAGGAGAAAAACAATGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 1164,
    "end": 2042,
    "strand": -1,
    "locus_tag": "ctg83_4",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,164 - 2,042,\n (total: 879 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKKVFSLIIALALIFAALFSLSSCFYVNSSEPNYVNYRKYDNAEKYMVGGFSYSSSGIEKVEIDWVAGEVNATATESDILSVYENGTSLAESEQLHYYSDGKTLIIRYCKSLFRGVIDPEQKSLNIEIPHGVELEITSVSADVFSGNLDMKDIRISNVSGDTTITAACADDIDISSVSGDIFVSHAKATDNLEFESVSGDIRNDRAEAGTIKAGSVSGDVELGIFDAAAVDIDTTSGDIVLTLIGDIGIDLDFSTTSGKHSAESDYKTGAKRCTVKAKTVSGDLSTKRNSKV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKKVFSLIIALALIFAALFSLSSCFYVNSSEPNYVNYRKYDNAEKYMVGGFSYSSSGIEKVEIDWVAGEVNATATESDILSVYENGTSLAESEQLHYYSDGKTLIIRYCKSLFRGVIDPEQKSLNIEIPHGVELEITSVSADVFSGNLDMKDIRISNVSGDTTITAACADDIDISSVSGDIFVSHAKATDNLEFESVSGDIRNDRAEAGTIKAGSVSGDVELGIFDAAAVDIDTTSGDIVLTLIGDIGIDLDFSTTSGKHSAESDYKTGAKRCTVKAKTVSGDLSTKRNSKV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAAAGGTATTTTCGCTGATTATCGCACTTGCGCTCATATTTGCCGCTCTGTTTTCGCTCTCATCATGTTTTTATGTCAACAGCAGTGAGCCAAACTATGTAAACTACCGAAAATATGACAATGCCGAAAAATACATGGTAGGCGGCTTCTCCTATTCATCAAGCGGAATAGAAAAAGTTGAGATAGACTGGGTAGCAGGCGAAGTGAATGCCACGGCTACGGAAAGCGACATTCTGAGCGTTTACGAAAACGGGACAAGCCTCGCCGAAAGCGAACAGCTGCACTATTATTCCGACGGCAAAACACTTATCATAAGATATTGTAAATCTCTTTTCAGAGGAGTAATCGACCCCGAGCAAAAGAGTCTGAATATAGAAATCCCTCACGGAGTTGAACTGGAAATAACCTCTGTCAGCGCCGATGTTTTCTCGGGTAACCTTGATATGAAGGATATCAGAATATCCAACGTCTCCGGCGATACGACAATAACAGCCGCCTGCGCCGATGATATTGATATATCGTCCGTATCGGGAGATATATTCGTATCCCATGCAAAAGCTACAGACAATCTGGAATTTGAAAGCGTTTCCGGCGATATAAGAAATGACCGCGCCGAAGCAGGCACCATAAAGGCGGGCAGCGTTTCCGGCGATGTTGAGCTCGGCATTTTCGATGCTGCGGCAGTCGATATAGACACCACAAGCGGAGATATAGTTCTCACCCTAATCGGTGATATAGGAATAGACCTTGATTTCTCCACCACCTCCGGAAAGCACTCTGCCGAATCCGATTATAAAACGGGAGCAAAAAGATGCACTGTAAAAGCTAAAACCGTCAGCGGCGATCTCTCCACAAAGCGAAACAGTAAGGTATAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 2200,
    "end": 2568,
    "strand": 1,
    "locus_tag": "ctg83_5",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,200 - 2,568,\n (total: 369 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MEIILVGACGKMGREVARGLFDGMHIAASVDLRSHCKNISDYRGEADVIIDFSSHTATEETLTYAVRRGLPCVIASTGQNSRERAALTRAAAHIPVFYSENMSLGIAVLLESAKAAAEIMPR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MEIILVGACGKMGREVARGLFDGMHIAASVDLRSHCKNISDYRGEADVIIDFSSHTATEETLTYAVRRGLPCVIASTGQNSRERAALTRAAAHIPVFYSENMSLGIAVLLESAKAAAEIMPR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGAGATAATACTTGTCGGAGCCTGCGGCAAAATGGGCAGAGAAGTAGCAAGGGGGCTTTTTGACGGTATGCATATTGCAGCTTCCGTGGATTTGCGTTCACACTGCAAAAATATATCCGATTACAGGGGTGAGGCAGATGTGATAATAGATTTTTCTTCGCATACGGCAACGGAGGAAACACTCACATATGCCGTGCGACGAGGGCTTCCGTGCGTTATCGCCTCTACCGGTCAAAACAGCCGCGAGAGAGCGGCACTGACAAGGGCGGCGGCGCATATTCCGGTTTTTTATTCCGAAAATATGTCGCTCGGAATAGCCGTACTGCTCGAATCGGCAAAAGCGGCGGCGGAGATAATGCCGAGATAG\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 2625,
    "end": 2906,
    "strand": 1,
    "locus_tag": "ctg83_6",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,625 - 2,906,\n (total: 282 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLARELLSENGRIVTARNGDEPRAGHDIGISSVRIGNIRGYHEVIISNGKETLSFSHEVEDRSVFARGALSAACFIIKKEKGLYGMYDLIHLK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLARELLSENGRIVTARNGDEPRAGHDIGISSVRIGNIRGYHEVIISNGKETLSFSHEVEDRSVFARGALSAACFIIKKEKGLYGMYDLIHLK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTCGCAAGAGAATTGCTTTCCGAAAACGGGCGTATCGTGACGGCGAGAAACGGAGACGAGCCGCGTGCCGGGCATGATATCGGCATTTCCAGCGTGCGCATAGGAAATATCAGGGGCTACCATGAGGTAATCATTTCAAACGGAAAGGAAACGCTGTCTTTTTCCCATGAGGTGGAGGACAGGAGCGTTTTCGCGAGAGGAGCGCTGAGCGCGGCGTGCTTTATCATAAAAAAAGAAAAAGGACTCTACGGAATGTATGACCTGATACATCTGAAATAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 2983,
    "end": 3156,
    "strand": 1,
    "locus_tag": "ctg83_7",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,983 - 3,156,\n (total: 174 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTEKELLYIEDALGHEKYFKDKCNETIANLQDPELKNLVSTMLEKHGKIYQSFYNLL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTEKELLYIEDALGHEKYFKDKCNETIANLQDPELKNLVSTMLEKHGKIYQSFYNLL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGGAAAAAGAACTTTTATATATTGAGGACGCACTCGGACACGAAAAATACTTCAAGGACAAATGCAACGAGACAATAGCAAATCTGCAGGATCCGGAGCTTAAAAATCTCGTTTCGACGATGCTCGAAAAGCACGGAAAAATTTATCAGAGCTTCTATAATCTGCTCTGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 3173,
    "end": 3415,
    "strand": 1,
    "locus_tag": "ctg83_8",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,173 - 3,415,\n (total: 243 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDDRNLMETLLLLEKGVCSLYMHGTIESSTASVNKTFGDALGESLGIQGTVYDKMAAKGWYQTTAAEQNKIQTVKQKFTM&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDDRNLMETLLLLEKGVCSLYMHGTIESSTASVNKTFGDALGESLGIQGTVYDKMAAKGWYQTTAAEQNKIQTVKQKFTM\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGACGACAGAAATCTTATGGAAACGCTCCTTTTGCTTGAGAAGGGTGTTTGCAGTCTTTATATGCACGGCACAATAGAATCCTCTACGGCGAGCGTAAACAAGACATTTGGCGATGCTCTCGGAGAATCACTCGGCATACAGGGTACGGTTTATGACAAGATGGCGGCAAAGGGCTGGTATCAGACGACTGCTGCCGAGCAGAACAAAATTCAGACAGTGAAGCAGAAATTCACGATGTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 3470,
    "end": 4408,
    "strand": -1,
    "locus_tag": "ctg83_9",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,470 - 4,408,\n (total: 939 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Abi<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MINFRKKYPIIAGTLCAILMLAVQAVVQAGFALLTENMTYPKYLPMLLADAVCIAVGIALAFALGLKDIFRSSREGFLHGLGTGGYFIFISVSTLIVSISSSKHGAPLSSVEIAVFVLAMAAVGFAEEIFFRGILSRMIFEKYGEDACGVWFSAIVSGLIFGSVHFINALHADIVGVAVQAVCAAAIGICLTALYYRTGNIYVVASLHAFMDFCALFSSGVFGEGSLSGTISNYSPLQLISALPYIVVSLVLLRRLKMAALLHKPSDSIIAVIGKLSSSQKSKNRLMWLIFCIVLAGLAVYAAKVIRLAIKL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MINFRKKYPIIAGTLCAILMLAVQAVVQAGFALLTENMTYPKYLPMLLADAVCIAVGIALAFALGLKDIFRSSREGFLHGLGTGGYFIFISVSTLIVSISSSKHGAPLSSVEIAVFVLAMAAVGFAEEIFFRGILSRMIFEKYGEDACGVWFSAIVSGLIFGSVHFINALHADIVGVAVQAVCAAAIGICLTALYYRTGNIYVVASLHAFMDFCALFSSGVFGEGSLSGTISNYSPLQLISALPYIVVSLVLLRRLKMAALLHKPSDSIIAVIGKLSSSQKSKNRLMWLIFCIVLAGLAVYAAKVIRLAIKL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATAAATTTCAGAAAAAAGTATCCCATTATCGCGGGAACTCTCTGCGCCATTCTGATGCTTGCCGTGCAGGCTGTCGTGCAGGCAGGATTTGCCCTTCTCACTGAGAATATGACATATCCGAAGTACCTGCCCATGCTCCTTGCGGACGCCGTCTGCATTGCCGTAGGTATCGCGCTTGCCTTCGCTCTCGGGTTGAAAGATATTTTTCGCTCATCGCGTGAGGGCTTTCTTCATGGGCTCGGTACGGGCGGATATTTCATATTTATATCGGTATCCACCCTCATCGTCAGCATCAGCTCATCAAAGCACGGCGCTCCGCTCTCTTCGGTTGAAATAGCGGTTTTTGTGCTCGCAATGGCAGCGGTCGGCTTTGCCGAAGAAATATTCTTCCGCGGGATACTCTCGCGTATGATTTTTGAAAAATACGGCGAAGATGCATGCGGCGTTTGGTTTTCCGCCATAGTATCAGGGCTGATATTCGGTTCTGTTCATTTTATCAATGCGCTTCATGCCGATATCGTCGGAGTTGCTGTTCAGGCGGTATGCGCTGCCGCTATCGGTATATGCCTCACCGCACTTTATTACAGGACGGGAAACATATATGTAGTTGCCTCTCTCCATGCTTTCATGGATTTCTGTGCGCTTTTTTCTTCCGGAGTATTCGGTGAAGGAAGCCTGTCGGGCACCATCAGCAATTACAGCCCGTTGCAGCTCATTTCGGCACTGCCGTATATCGTGGTTTCACTCGTGCTCCTGCGCAGACTGAAAATGGCGGCGCTCCTGCATAAGCCTTCCGACAGCATAATAGCAGTCATCGGCAAGCTTTCCTCATCGCAGAAATCGAAAAACCGCCTCATGTGGCTTATCTTCTGTATAGTGCTTGCGGGACTCGCTGTCTATGCCGCAAAGGTAATACGGCTGGCAATAAAATTATAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 4509,
    "end": 5726,
    "strand": -1,
    "locus_tag": "ctg83_10",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,509 - 5,726,\n (total: 1218 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNNFKKMAALFLALTMVCLAFASCGKKPQEKKGTPVAIVDGEIIYGNDQEILDYLAYYVWMNKIELPTDDKISYAYTTAVTYCTDSVVWYKIYEKELAAKGITFSEKKLKDEIDKAKSFFDDQDGGYEGFRKSLRLSKNFVYNIVKYEAISKEIISIISEKCNVSDEEALAYFNEHISEYTHAPGIVYDAILLEILDMQDASEVAAKKAEAEEYIKKITGGMDFDAAREEVKKKYSGDKYFYTGFASGEATLAEGEYIKVDDLDAEKKTIEEMMAEKNIKIDANANKDSDEYKNYESYINSLYRAELMYALTTATKSGEIYSKPILSTIGYVVVKNIKHNETISFTNFGDVKDEIKETISGEKFDKEVDNYREEMIKKYGVVFNKTDVNWQTSESESTTATTAAN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNNFKKMAALFLALTMVCLAFASCGKKPQEKKGTPVAIVDGEIIYGNDQEILDYLAYYVWMNKIELPTDDKISYAYTTAVTYCTDSVVWYKIYEKELAAKGITFSEKKLKDEIDKAKSFFDDQDGGYEGFRKSLRLSKNFVYNIVKYEAISKEIISIISEKCNVSDEEALAYFNEHISEYTHAPGIVYDAILLEILDMQDASEVAAKKAEAEEYIKKITGGMDFDAAREEVKKKYSGDKYFYTGFASGEATLAEGEYIKVDDLDAEKKTIEEMMAEKNIKIDANANKDSDEYKNYESYINSLYRAELMYALTTATKSGEIYSKPILSTIGYVVVKNIKHNETISFTNFGDVKDEIKETISGEKFDKEVDNYREEMIKKYGVVFNKTDVNWQTSESESTTATTAAN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAATAATTTTAAAAAGATGGCGGCGCTTTTCCTTGCGCTGACTATGGTCTGCCTTGCTTTTGCATCGTGCGGAAAGAAGCCGCAGGAAAAAAAGGGCACTCCCGTCGCTATAGTCGACGGAGAAATAATCTACGGAAACGATCAGGAAATTCTTGATTATCTCGCATACTATGTATGGATGAATAAAATCGAGTTGCCGACAGACGATAAGATTTCTTATGCTTATACCACCGCCGTAACATACTGTACGGATTCTGTTGTCTGGTACAAAATCTATGAAAAAGAGCTTGCTGCAAAGGGCATTACTTTCAGCGAGAAAAAGCTCAAGGACGAAATTGATAAAGCAAAATCGTTTTTCGATGATCAGGACGGCGGCTATGAGGGTTTCCGTAAAAGCTTGAGACTCTCCAAGAATTTTGTCTACAATATAGTAAAATACGAGGCAATTTCAAAAGAGATTATCTCAATAATATCAGAAAAATGCAATGTTTCCGACGAAGAAGCACTTGCTTATTTCAATGAGCATATAAGCGAATATACGCACGCCCCCGGCATTGTATATGACGCGATCCTGCTCGAAATTCTCGATATGCAGGATGCTTCCGAGGTCGCGGCAAAAAAAGCCGAAGCCGAGGAATATATCAAAAAAATAACAGGCGGAATGGACTTTGATGCCGCACGCGAAGAAGTCAAGAAGAAATACAGCGGTGATAAGTATTTCTACACGGGCTTTGCTTCCGGCGAGGCTACCCTTGCCGAGGGCGAATATATAAAAGTGGATGACCTCGATGCGGAGAAAAAGACTATCGAAGAAATGATGGCTGAAAAGAATATAAAAATCGACGCCAACGCCAACAAGGATTCTGATGAATATAAGAATTACGAATCATACATCAATTCGCTCTACCGTGCAGAATTGATGTACGCGCTCACCACGGCGACAAAGAGCGGCGAGATATACAGTAAGCCGATTCTTTCTACCATAGGCTATGTCGTAGTGAAAAATATAAAACATAATGAAACCATTTCATTCACAAACTTCGGCGATGTAAAGGATGAAATCAAAGAGACAATCTCCGGCGAAAAATTTGATAAAGAGGTTGACAACTATCGCGAAGAAATGATAAAAAAATACGGTGTTGTTTTCAATAAAACAGATGTAAACTGGCAGACAAGCGAAAGCGAGTCCACCACAGCTACAACGGCGGCAAACTGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 5817,
    "end": 6302,
    "strand": -1,
    "locus_tag": "ctg83_11",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,817 - 6,302,\n (total: 486 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTLTEKVAYIKGLVAALETDKNDKVFSAVLDLLSDLAATVSDLDDKSEYLEKYIEEVDEDLGALEDEFYGDECDDCECKDCAEEDCDCRCDDCLDDDCDCCDDDCDCIEVECPYCGETVCLDDTVDFDNVKCPACGETFSCVCDDDCDCCDDDDCGCGCEH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTLTEKVAYIKGLVAALETDKNDKVFSAVLDLLSDLAATVSDLDDKSEYLEKYIEEVDEDLGALEDEFYGDECDDCECKDCAEEDCDCRCDDCLDDDCDCCDDDCDCIEVECPYCGETVCLDDTVDFDNVKCPACGETFSCVCDDDCDCCDDDDCGCGCEH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACACTTACCGAAAAAGTTGCTTATATAAAGGGTCTTGTAGCCGCTCTCGAAACAGACAAGAACGATAAGGTTTTCTCTGCTGTGCTTGATCTTCTCTCCGACCTTGCCGCTACGGTCTCCGATCTTGACGACAAGTCAGAGTATCTTGAAAAGTACATCGAAGAGGTTGACGAGGATCTCGGCGCTCTCGAAGATGAATTCTACGGCGATGAGTGCGACGATTGCGAATGCAAGGATTGCGCAGAAGAAGATTGCGACTGCCGTTGCGACGATTGTCTCGATGACGATTGCGACTGCTGCGACGACGACTGCGACTGCATAGAGGTAGAATGCCCTTACTGCGGCGAGACGGTATGCCTCGATGATACCGTTGATTTTGACAATGTAAAGTGCCCTGCCTGCGGCGAAACCTTCAGCTGTGTCTGCGACGACGATTGCGACTGCTGTGATGATGACGACTGCGGTTGCGGTTGCGAGCACTGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 6337,
    "end": 6903,
    "strand": -1,
    "locus_tag": "ctg83_12",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,337 - 6,903,\n (total: 567 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MVIAGDFKNGITFEMDGNVMQVIEFQHVKPGKGAAFVRTKLRNVISGAVVEKTFSPTDKFPPAIVDRRDMQYSYNDGDLYYFMDMESYDMIPVSKSLLPDNFKFVKEEMMCKIVSYKGNVFSVEPPMFVELQVTEVEPGFKGDTAQGAKKPATLETGATIQVPLFIENGEILRIDTRTGEYLERVKTK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MVIAGDFKNGITFEMDGNVMQVIEFQHVKPGKGAAFVRTKLRNVISGAVVEKTFSPTDKFPPAIVDRRDMQYSYNDGDLYYFMDMESYDMIPVSKSLLPDNFKFVKEEMMCKIVSYKGNVFSVEPPMFVELQVTEVEPGFKGDTAQGAKKPATLETGATIQVPLFIENGEILRIDTRTGEYLERVKTK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGTTATCGCAGGCGATTTTAAAAACGGCATTACATTTGAAATGGACGGGAATGTAATGCAGGTTATCGAATTCCAGCATGTAAAACCCGGCAAGGGCGCGGCTTTCGTCCGCACAAAGCTGAGAAATGTCATTTCCGGTGCTGTCGTCGAAAAGACCTTCAGCCCCACAGACAAGTTCCCGCCCGCTATCGTTGACAGAAGAGATATGCAGTATTCCTACAATGACGGCGATCTCTACTACTTCATGGATATGGAATCATACGATATGATTCCCGTTTCCAAGAGCCTTCTTCCCGACAACTTCAAGTTCGTAAAGGAAGAAATGATGTGCAAGATCGTTTCCTACAAGGGAAATGTATTCAGCGTTGAGCCTCCTATGTTCGTAGAGCTTCAGGTTACCGAGGTTGAGCCCGGTTTTAAGGGTGATACGGCTCAGGGCGCAAAGAAACCCGCTACTCTTGAAACAGGAGCTACTATCCAGGTTCCGCTTTTCATCGAAAACGGTGAAATCCTCCGCATCGACACAAGAACAGGCGAATATCTCGAAAGAGTAAAAACGAAATAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 7024,
    "end": 7503,
    "strand": -1,
    "locus_tag": "ctg83_13",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg83_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg83_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,024 - 7,503,\n (total: 480 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=RPHGVPRNVKLERGFLTMDFGCILNGYCSDMTRTVSVGKADEEMKKVYNTVLRAQTAAIDFIREGVLCCDADKVARDIIDADYKGYFGHSLGHGVGMYIHEEPRLSARCTKVLKVGHVVTVEPGIYIPGKYGVRIEDMMQITPSGAIDITKSPKNLIEI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00083_NODE_57..&amp;from=0&amp;to=7505\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"RPHGVPRNVKLERGFLTMDFGCILNGYCSDMTRTVSVGKADEEMKKVYNTVLRAQTAAIDFIREGVLCCDADKVARDIIDADYKGYFGHSLGHGVGMYIHEEPRLSARCTKVLKVGHVVTVEPGIYIPGKYGVRIEDMMQITPSGAIDITKSPKNLIEI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"CGTCCTCACGGTGTTCCGAGAAACGTAAAGCTTGAACGCGGATTTCTCACGATGGACTTCGGTTGCATTCTGAACGGCTACTGCTCCGATATGACGCGTACCGTTTCCGTCGGCAAAGCTGACGAAGAAATGAAAAAGGTTTACAATACCGTCCTGCGCGCACAGACCGCAGCTATAGATTTCATCCGCGAGGGTGTTCTCTGCTGCGATGCGGACAAGGTTGCCCGCGACATCATAGACGCCGATTACAAGGGATACTTCGGTCACTCTCTCGGTCACGGCGTAGGAATGTATATCCATGAGGAGCCGCGTCTCTCCGCCAGATGCACAAAGGTGCTGAAGGTCGGTCATGTCGTCACGGTCGAGCCCGGCATTTATATCCCCGGAAAATACGGCGTCAGAATAGAGGATATGATGCAGATTACACCTTCCGGAGCAATTGACATCACAAAAAGTCCGAAAAATCTTATAGAAATATAA\">Copy to clipboard</span><br>\n</div>"
   }
  ],
  "clusters": [
   {
    "start": 165,
    "end": 435,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 7505,
    "product": "RRE-containing",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "ttaCodons": [],
  "type": "RRE-containing",
  "products": [
   "RRE-containing"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP RRE-containing",
  "anchor": "r83c1"
 }
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
