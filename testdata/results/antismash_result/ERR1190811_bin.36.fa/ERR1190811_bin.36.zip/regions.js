var recordData = [
 {
  "length": 142961,
  "seq_id": "c00001_NODE_31..",
  "regions": []
 },
 {
  "length": 133996,
  "seq_id": "c00002_NODE_37..",
  "regions": []
 },
 {
  "length": 101090,
  "seq_id": "c00003_NODE_85..",
  "regions": []
 },
 {
  "length": 92762,
  "seq_id": "c00004_NODE_10..",
  "regions": []
 },
 {
  "length": 85730,
  "seq_id": "c00005_NODE_12..",
  "regions": []
 },
 {
  "length": 82370,
  "seq_id": "c00006_NODE_13..",
  "regions": []
 },
 {
  "length": 79576,
  "seq_id": "c00007_NODE_14..",
  "regions": []
 },
 {
  "length": 79180,
  "seq_id": "c00008_NODE_15..",
  "regions": []
 },
 {
  "length": 72865,
  "seq_id": "c00009_NODE_19..",
  "regions": []
 },
 {
  "length": 65797,
  "seq_id": "c00010_NODE_25..",
  "regions": []
 },
 {
  "length": 62254,
  "seq_id": "c00011_NODE_28..",
  "regions": []
 },
 {
  "length": 61793,
  "seq_id": "c00012_NODE_29..",
  "regions": []
 },
 {
  "length": 58198,
  "seq_id": "c00013_NODE_33..",
  "regions": []
 },
 {
  "length": 50271,
  "seq_id": "c00014_NODE_44..",
  "regions": []
 },
 {
  "length": 46534,
  "seq_id": "c00015_NODE_50..",
  "regions": []
 },
 {
  "length": 44282,
  "seq_id": "c00016_NODE_55..",
  "regions": []
 },
 {
  "length": 44277,
  "seq_id": "c00017_NODE_55..",
  "regions": []
 },
 {
  "length": 44249,
  "seq_id": "c00018_NODE_55..",
  "regions": []
 },
 {
  "length": 40663,
  "seq_id": "c00019_NODE_64..",
  "regions": []
 },
 {
  "length": 37345,
  "seq_id": "c00020_NODE_74..",
  "regions": []
 },
 {
  "length": 35840,
  "seq_id": "c00021_NODE_79..",
  "regions": []
 },
 {
  "length": 35666,
  "seq_id": "c00022_NODE_80..",
  "regions": []
 },
 {
  "length": 35190,
  "seq_id": "c00023_NODE_81..",
  "regions": []
 },
 {
  "length": 32575,
  "seq_id": "c00024_NODE_93..",
  "regions": []
 },
 {
  "length": 32480,
  "seq_id": "c00025_NODE_93..",
  "regions": []
 },
 {
  "length": 31871,
  "seq_id": "c00026_NODE_96..",
  "regions": []
 },
 {
  "length": 30904,
  "seq_id": "c00027_NODE_10..",
  "regions": []
 },
 {
  "length": 26953,
  "seq_id": "c00028_NODE_12..",
  "regions": []
 },
 {
  "length": 26233,
  "seq_id": "c00029_NODE_12..",
  "regions": []
 },
 {
  "length": 24201,
  "seq_id": "c00030_NODE_14..",
  "regions": []
 },
 {
  "length": 23077,
  "seq_id": "c00031_NODE_15..",
  "regions": []
 },
 {
  "length": 22198,
  "seq_id": "c00032_NODE_16..",
  "regions": []
 },
 {
  "length": 22068,
  "seq_id": "c00033_NODE_16..",
  "regions": []
 },
 {
  "length": 21869,
  "seq_id": "c00034_NODE_16..",
  "regions": []
 },
 {
  "length": 19390,
  "seq_id": "c00035_NODE_19..",
  "regions": []
 },
 {
  "length": 18722,
  "seq_id": "c00036_NODE_20..",
  "regions": []
 },
 {
  "length": 18114,
  "seq_id": "c00037_NODE_21..",
  "regions": []
 },
 {
  "length": 15400,
  "seq_id": "c00038_NODE_25..",
  "regions": []
 },
 {
  "length": 13278,
  "seq_id": "c00039_NODE_30..",
  "regions": []
 },
 {
  "length": 12278,
  "seq_id": "c00040_NODE_33..",
  "regions": []
 },
 {
  "length": 11645,
  "seq_id": "c00041_NODE_35..",
  "regions": []
 },
 {
  "length": 9321,
  "seq_id": "c00042_NODE_45..",
  "regions": []
 },
 {
  "length": 7358,
  "seq_id": "c00043_NODE_58..",
  "regions": []
 },
 {
  "length": 5826,
  "seq_id": "c00044_NODE_75..",
  "regions": []
 },
 {
  "length": 5146,
  "seq_id": "c00045_NODE_85..",
  "regions": []
 },
 {
  "length": 4537,
  "seq_id": "c00046_NODE_98..",
  "regions": []
 },
 {
  "length": 4481,
  "seq_id": "c00047_NODE_99..",
  "regions": []
 },
 {
  "length": 4373,
  "seq_id": "c00048_NODE_10..",
  "regions": []
 },
 {
  "length": 4237,
  "seq_id": "c00049_NODE_10..",
  "regions": []
 },
 {
  "length": 2536,
  "seq_id": "c00050_NODE_18..",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
