var recordData = [
 {
  "length": 35826,
  "seq_id": "c00001_NODE_79..",
  "regions": []
 },
 {
  "length": 32741,
  "seq_id": "c00002_NODE_92..",
  "regions": []
 },
 {
  "length": 31808,
  "seq_id": "c00003_NODE_96..",
  "regions": []
 },
 {
  "length": 31332,
  "seq_id": "c00004_NODE_99..",
  "regions": []
 },
 {
  "length": 31189,
  "seq_id": "c00005_NODE_99..",
  "regions": []
 },
 {
  "length": 29100,
  "seq_id": "c00006_NODE_11..",
  "regions": []
 },
 {
  "length": 27767,
  "seq_id": "c00007_NODE_11..",
  "regions": []
 },
 {
  "length": 27544,
  "seq_id": "c00008_NODE_12..",
  "regions": []
 },
 {
  "length": 27226,
  "seq_id": "c00009_NODE_12..",
  "regions": []
 },
 {
  "length": 26932,
  "seq_id": "c00010_NODE_12..",
  "regions": []
 },
 {
  "length": 24358,
  "seq_id": "c00011_NODE_14..",
  "regions": []
 },
 {
  "length": 24324,
  "seq_id": "c00012_NODE_14..",
  "regions": []
 },
 {
  "length": 23687,
  "seq_id": "c00013_NODE_14..",
  "regions": []
 },
 {
  "length": 22491,
  "seq_id": "c00014_NODE_15..",
  "regions": []
 },
 {
  "length": 21616,
  "seq_id": "c00015_NODE_16..",
  "regions": []
 },
 {
  "length": 21194,
  "seq_id": "c00016_NODE_17..",
  "regions": []
 },
 {
  "length": 21165,
  "seq_id": "c00017_NODE_17..",
  "regions": []
 },
 {
  "length": 21032,
  "seq_id": "c00018_NODE_17..",
  "regions": []
 },
 {
  "length": 20743,
  "seq_id": "c00019_NODE_17..",
  "regions": []
 },
 {
  "length": 20033,
  "seq_id": "c00020_NODE_18..",
  "regions": []
 },
 {
  "length": 20029,
  "seq_id": "c00021_NODE_18..",
  "regions": []
 },
 {
  "length": 19978,
  "seq_id": "c00022_NODE_18..",
  "regions": []
 },
 {
  "length": 19714,
  "seq_id": "c00023_NODE_19..",
  "regions": []
 },
 {
  "length": 19669,
  "seq_id": "c00024_NODE_19..",
  "regions": []
 },
 {
  "length": 19656,
  "seq_id": "c00025_NODE_19..",
  "regions": []
 },
 {
  "length": 19433,
  "seq_id": "c00026_NODE_19..",
  "regions": []
 },
 {
  "length": 18597,
  "seq_id": "c00027_NODE_20..",
  "regions": []
 },
 {
  "length": 17988,
  "seq_id": "c00028_NODE_21..",
  "regions": []
 },
 {
  "length": 17692,
  "seq_id": "c00029_NODE_21..",
  "regions": []
 },
 {
  "length": 17688,
  "seq_id": "c00030_NODE_21..",
  "regions": []
 },
 {
  "length": 17538,
  "seq_id": "c00031_NODE_22..",
  "regions": []
 },
 {
  "length": 17366,
  "seq_id": "c00032_NODE_22..",
  "regions": []
 },
 {
  "length": 17312,
  "seq_id": "c00033_NODE_22..",
  "regions": []
 },
 {
  "length": 17208,
  "seq_id": "c00034_NODE_22..",
  "regions": []
 },
 {
  "length": 17148,
  "seq_id": "c00035_NODE_22..",
  "regions": []
 },
 {
  "length": 16904,
  "seq_id": "c00036_NODE_23..",
  "regions": []
 },
 {
  "length": 16844,
  "seq_id": "c00037_NODE_23..",
  "regions": []
 },
 {
  "length": 15960,
  "seq_id": "c00038_NODE_25..",
  "regions": []
 },
 {
  "length": 15212,
  "seq_id": "c00039_NODE_26..",
  "regions": []
 },
 {
  "length": 14901,
  "seq_id": "c00040_NODE_26..",
  "regions": []
 },
 {
  "length": 14524,
  "seq_id": "c00041_NODE_27..",
  "regions": []
 },
 {
  "length": 14291,
  "seq_id": "c00042_NODE_28..",
  "regions": []
 },
 {
  "length": 13946,
  "seq_id": "c00043_NODE_28..",
  "regions": []
 },
 {
  "length": 13678,
  "seq_id": "c00044_NODE_29..",
  "regions": []
 },
 {
  "length": 13651,
  "seq_id": "c00045_NODE_29..",
  "regions": []
 },
 {
  "length": 13450,
  "seq_id": "c00046_NODE_30..",
  "regions": []
 },
 {
  "length": 13337,
  "seq_id": "c00047_NODE_30..",
  "regions": []
 },
 {
  "length": 13293,
  "seq_id": "c00048_NODE_30..",
  "regions": []
 },
 {
  "length": 13034,
  "seq_id": "c00049_NODE_31..",
  "regions": []
 },
 {
  "length": 12925,
  "seq_id": "c00050_NODE_31..",
  "regions": []
 },
 {
  "length": 12780,
  "seq_id": "c00051_NODE_32..",
  "regions": []
 },
 {
  "length": 12402,
  "seq_id": "c00052_NODE_33..",
  "regions": []
 },
 {
  "length": 12361,
  "seq_id": "c00053_NODE_33..",
  "regions": []
 },
 {
  "length": 12317,
  "seq_id": "c00054_NODE_33..",
  "regions": []
 },
 {
  "length": 12186,
  "seq_id": "c00055_NODE_33..",
  "regions": []
 },
 {
  "length": 12096,
  "seq_id": "c00056_NODE_34..",
  "regions": []
 },
 {
  "length": 11966,
  "seq_id": "c00057_NODE_34..",
  "regions": []
 },
 {
  "length": 11947,
  "seq_id": "c00058_NODE_34..",
  "regions": []
 },
 {
  "length": 11873,
  "seq_id": "c00059_NODE_35..",
  "regions": []
 },
 {
  "length": 11799,
  "seq_id": "c00060_NODE_35..",
  "regions": []
 },
 {
  "length": 11709,
  "seq_id": "c00061_NODE_35..",
  "regions": []
 },
 {
  "length": 11680,
  "seq_id": "c00062_NODE_35..",
  "regions": []
 },
 {
  "length": 11672,
  "seq_id": "c00063_NODE_35..",
  "regions": []
 },
 {
  "length": 11633,
  "seq_id": "c00064_NODE_35..",
  "regions": []
 },
 {
  "length": 11548,
  "seq_id": "c00065_NODE_35..",
  "regions": []
 },
 {
  "length": 11454,
  "seq_id": "c00066_NODE_36..",
  "regions": []
 },
 {
  "length": 11337,
  "seq_id": "c00067_NODE_36..",
  "regions": []
 },
 {
  "length": 11081,
  "seq_id": "c00068_NODE_37..",
  "regions": []
 },
 {
  "length": 10983,
  "seq_id": "c00069_NODE_38..",
  "regions": []
 },
 {
  "length": 10944,
  "seq_id": "c00070_NODE_38..",
  "regions": []
 },
 {
  "length": 10905,
  "seq_id": "c00071_NODE_38..",
  "regions": []
 },
 {
  "length": 10793,
  "seq_id": "c00072_NODE_38..",
  "regions": []
 },
 {
  "length": 10718,
  "seq_id": "c00073_NODE_38..",
  "regions": []
 },
 {
  "length": 10245,
  "seq_id": "c00074_NODE_40..",
  "regions": []
 },
 {
  "length": 10143,
  "seq_id": "c00075_NODE_41..",
  "regions": []
 },
 {
  "length": 10134,
  "seq_id": "c00076_NODE_41..",
  "regions": []
 },
 {
  "length": 10091,
  "seq_id": "c00077_NODE_41..",
  "regions": []
 },
 {
  "length": 10025,
  "seq_id": "c00078_NODE_41..",
  "regions": []
 },
 {
  "length": 9838,
  "seq_id": "c00079_NODE_42..",
  "regions": []
 },
 {
  "length": 9387,
  "seq_id": "c00080_NODE_44..",
  "regions": []
 },
 {
  "length": 9244,
  "seq_id": "c00081_NODE_45..",
  "regions": []
 },
 {
  "length": 9234,
  "seq_id": "c00082_NODE_45..",
  "regions": []
 },
 {
  "length": 9225,
  "seq_id": "c00083_NODE_45..",
  "regions": []
 },
 {
  "length": 9156,
  "seq_id": "c00084_NODE_46..",
  "regions": []
 },
 {
  "length": 9095,
  "seq_id": "c00085_NODE_46..",
  "regions": []
 },
 {
  "length": 8953,
  "seq_id": "c00086_NODE_47..",
  "regions": []
 },
 {
  "length": 8934,
  "seq_id": "c00087_NODE_47..",
  "regions": []
 },
 {
  "length": 8760,
  "seq_id": "c00088_NODE_48..",
  "regions": []
 },
 {
  "length": 8703,
  "seq_id": "c00089_NODE_48..",
  "regions": []
 },
 {
  "length": 8629,
  "seq_id": "c00090_NODE_49..",
  "regions": []
 },
 {
  "length": 8589,
  "seq_id": "c00091_NODE_49..",
  "regions": []
 },
 {
  "length": 8553,
  "seq_id": "c00092_NODE_49..",
  "regions": []
 },
 {
  "length": 8488,
  "seq_id": "c00093_NODE_50..",
  "regions": []
 },
 {
  "length": 8469,
  "seq_id": "c00094_NODE_50..",
  "regions": []
 },
 {
  "length": 8402,
  "seq_id": "c00095_NODE_50..",
  "regions": []
 },
 {
  "length": 8388,
  "seq_id": "c00096_NODE_50..",
  "regions": []
 },
 {
  "length": 8368,
  "seq_id": "c00097_NODE_51..",
  "regions": []
 },
 {
  "length": 8366,
  "seq_id": "c00098_NODE_51..",
  "regions": []
 },
 {
  "length": 8271,
  "seq_id": "c00099_NODE_51..",
  "regions": []
 },
 {
  "length": 8243,
  "seq_id": "c00100_NODE_51..",
  "regions": []
 },
 {
  "length": 8208,
  "seq_id": "c00101_NODE_52..",
  "regions": []
 },
 {
  "length": 8203,
  "seq_id": "c00102_NODE_52..",
  "regions": []
 },
 {
  "length": 8048,
  "seq_id": "c00103_NODE_53..",
  "regions": []
 },
 {
  "length": 8000,
  "seq_id": "c00104_NODE_53..",
  "regions": []
 },
 {
  "length": 7970,
  "seq_id": "c00105_NODE_53..",
  "regions": []
 },
 {
  "length": 7888,
  "seq_id": "c00106_NODE_54..",
  "regions": []
 },
 {
  "length": 7865,
  "seq_id": "c00107_NODE_54..",
  "regions": []
 },
 {
  "length": 7857,
  "seq_id": "c00108_NODE_54..",
  "regions": []
 },
 {
  "length": 7846,
  "seq_id": "c00109_NODE_54..",
  "regions": []
 },
 {
  "length": 7831,
  "seq_id": "c00110_NODE_54..",
  "regions": []
 },
 {
  "length": 7698,
  "seq_id": "c00111_NODE_55..",
  "regions": []
 },
 {
  "length": 7552,
  "seq_id": "c00112_NODE_57..",
  "regions": []
 },
 {
  "length": 7538,
  "seq_id": "c00113_NODE_57..",
  "regions": []
 },
 {
  "length": 7393,
  "seq_id": "c00114_NODE_58..",
  "regions": []
 },
 {
  "length": 7372,
  "seq_id": "c00115_NODE_58..",
  "regions": []
 },
 {
  "length": 7226,
  "seq_id": "c00116_NODE_59..",
  "regions": []
 },
 {
  "length": 7136,
  "seq_id": "c00117_NODE_60..",
  "regions": []
 },
 {
  "length": 7003,
  "seq_id": "c00118_NODE_61..",
  "regions": []
 },
 {
  "length": 6893,
  "seq_id": "c00119_NODE_62..",
  "regions": []
 },
 {
  "length": 6798,
  "seq_id": "c00120_NODE_63..",
  "regions": []
 },
 {
  "length": 6776,
  "seq_id": "c00121_NODE_63..",
  "regions": []
 },
 {
  "length": 6717,
  "seq_id": "c00122_NODE_64..",
  "regions": []
 },
 {
  "length": 6646,
  "seq_id": "c00123_NODE_64..",
  "regions": []
 },
 {
  "length": 6537,
  "seq_id": "c00124_NODE_65..",
  "regions": []
 },
 {
  "length": 6525,
  "seq_id": "c00125_NODE_66..",
  "regions": [
   {
    "start": 1,
    "end": 6525,
    "idx": 1,
    "orfs": [
     {
      "start": 3,
      "end": 680,
      "strand": 1,
      "locus_tag": "ctg125_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 680,\n (total: 678 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=GIVPGAKLFGSEDLYADQYLFVNGYPKRILANGGTPVGILSSDGYAAEDSLSLCDAFVFCGGARFYPYHFQVMEYAAKSGKPVLGICLGMQMMNTYFLVAEEAERRGWDGPLLALFEQMKKERYMFTEPVDGHWDGHITRDNVDRFKHPIHITPGSRLERLTGKQTILGASMHNYRITHPARSLTVAGRTDDGIIEALEYGEQMLGVQFHPEADDQNDELFRAIL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"GIVPGAKLFGSEDLYADQYLFVNGYPKRILANGGTPVGILSSDGYAAEDSLSLCDAFVFCGGARFYPYHFQVMEYAAKSGKPVLGICLGMQMMNTYFLVAEEAERRGWDGPLLALFEQMKKERYMFTEPVDGHWDGHITRDNVDRFKHPIHITPGSRLERLTGKQTILGASMHNYRITHPARSLTVAGRTDDGIIEALEYGEQMLGVQFHPEADDQNDELFRAIL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GGGATCGTGCCGGGCGCAAAGCTGTTCGGCTCGGAGGATCTGTACGCGGATCAATATTTATTTGTAAACGGCTATCCGAAGCGGATTCTTGCAAACGGCGGCACGCCCGTCGGGATCCTCAGCAGCGACGGCTATGCGGCGGAGGACAGCCTTTCGCTCTGCGACGCGTTTGTGTTCTGCGGCGGGGCGCGGTTCTATCCGTACCATTTTCAGGTCATGGAGTACGCTGCGAAATCCGGCAAGCCCGTGCTCGGCATCTGCCTCGGGATGCAGATGATGAACACCTATTTCCTCGTTGCCGAAGAGGCCGAACGCCGCGGCTGGGACGGGCCGCTGCTCGCGCTGTTCGAGCAGATGAAAAAAGAGCGCTATATGTTCACCGAACCCGTGGACGGCCACTGGGACGGCCATATCACGCGGGACAATGTCGACCGCTTCAAGCATCCCATCCATATAACGCCCGGCAGCCGCCTCGAACGTCTGACAGGGAAGCAGACGATCCTGGGCGCGTCGATGCACAACTATCGTATTACGCACCCAGCCCGGTCGCTGACCGTCGCGGGCCGGACGGACGACGGCATCATCGAGGCGCTGGAATACGGTGAGCAGATGCTCGGCGTTCAGTTCCACCCCGAAGCCGACGACCAGAACGACGAACTGTTCCGCGCCATTCTGTGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 857,
      "end": 1828,
      "strand": 1,
      "locus_tag": "ctg125_2",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 857 - 1,828,\n (total: 972 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSNNHGDIVIEDTTINAGSAKGYGYGPFAFDVCGYSSYNGVSVTVKGNSVINGNIEISRSSNKSPVGLTLESGTVTGELKIDDSIKLGENTTITKSDSFKVAAPAGYKWDEGTLKKITYVAEAGGVKYESLQKAIDAAKSKAVVTMLADTRENVTISTPYNGLMLHASAAALGGRAYLFSGPCGRGKSTHTRLWQQTFGEAVQVFNDDKPALRRLDGRWFAYGTPWCGKDGINLNQKWPLGGICFLEKAQENRIRRLSAAEALPLILAQTTYRLQPHSMELLLASLDSLLREIPVFLLENRPEEAAARLSYDTMRRAAEEEGL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSNNHGDIVIEDTTINAGSAKGYGYGPFAFDVCGYSSYNGVSVTVKGNSVINGNIEISRSSNKSPVGLTLESGTVTGELKIDDSIKLGENTTITKSDSFKVAAPAGYKWDEGTLKKITYVAEAGGVKYESLQKAIDAAKSKAVVTMLADTRENVTISTPYNGLMLHASAAALGGRAYLFSGPCGRGKSTHTRLWQQTFGEAVQVFNDDKPALRRLDGRWFAYGTPWCGKDGINLNQKWPLGGICFLEKAQENRIRRLSAAEALPLILAQTTYRLQPHSMELLLASLDSLLREIPVFLLENRPEEAAARLSYDTMRRAAEEEGL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCCAACAACCACGGTGACATCGTGATCGAAGACACCACGATCAACGCTGGCAGCGCAAAGGGATACGGCTACGGCCCGTTCGCCTTCGACGTCTGCGGCTATAGCAGCTACAACGGTGTCTCCGTCACCGTCAAGGGCAACAGCGTCATCAACGGCAACATCGAGATTTCCCGCAGCAGCAATAAGAGTCCCGTTGGCCTGACGCTGGAGAGCGGCACGGTGACCGGCGAACTGAAGATCGACGACTCCATCAAGCTCGGCGAAAACACCACCATCACCAAGTCCGATTCCTTCAAAGTCGCAGCCCCCGCCGGCTACAAGTGGGACGAAGGCACGCTGAAGAAGATCACCTACGTTGCCGAAGCTGGCGGTGTCAAGTACGAATCCCTCCAGAAAGCCATCGACGCGGCCAAGTCTAAAGCGGTCGTCACGATGCTTGCTGATACCCGCGAGAATGTCACTATCAGTACACCCTACAACGGTCTGATGCTCCACGCGTCGGCGGCGGCGCTTGGGGGGAGGGCGTACCTCTTTTCCGGCCCCTGCGGGCGCGGAAAATCGACCCATACGCGTCTCTGGCAGCAGACGTTTGGAGAGGCCGTGCAGGTCTTCAATGACGATAAGCCCGCCCTCCGCCGTCTGGACGGCCGCTGGTTCGCCTACGGCACCCCGTGGTGCGGCAAGGACGGCATCAATCTCAACCAGAAATGGCCCCTCGGCGGCATCTGCTTTCTCGAAAAGGCGCAGGAGAACCGCATCCGCCGCCTGTCCGCCGCCGAGGCGCTGCCGCTGATTCTGGCGCAGACCACGTACCGGCTCCAGCCGCACAGTATGGAGCTTCTGCTCGCGTCGCTGGACAGCCTGCTGCGGGAAATTCCGGTCTTCCTGCTGGAAAACCGCCCGGAGGAAGCCGCCGCCCGCCTGAGCTATGACACCATGCGCCGCGCGGCGGAGGAGGAAGGACTATGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 1825,
      "end": 2091,
      "strand": 1,
      "locus_tag": "ctg125_3",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,825 - 2,091,\n (total: 267 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKLKENFVLRQVAGSYAVLAVGAASVDFNGMLTLNESGALLWRALEQGADRPALLAALTAEYDVSDAQAEQDIDEFLSTLQKAGCLEA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKLKENFVLRQVAGSYAVLAVGAASVDFNGMLTLNESGALLWRALEQGADRPALLAALTAEYDVSDAQAEQDIDEFLSTLQKAGCLEA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAACTCAAAGAAAACTTTGTTCTGCGTCAGGTGGCCGGCAGCTATGCCGTCCTCGCCGTCGGCGCAGCCAGCGTGGATTTTAACGGTATGCTGACGCTCAACGAATCCGGCGCGCTCCTATGGCGCGCGCTGGAACAGGGCGCCGACCGCCCCGCGCTCCTCGCCGCCCTCACCGCAGAATACGACGTATCTGACGCACAGGCCGAACAGGATATCGACGAATTTCTGTCCACCCTGCAAAAAGCCGGGTGCCTGGAGGCGTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 2379,
      "end": 2540,
      "strand": 1,
      "locus_tag": "ctg125_4",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,379 - 2,540,\n (total: 162 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLGRLADFDAIDAGAGRRFPDVSKTFWGFYDIVEATSEHTYTFDSELLHEKWN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLGRLADFDAIDAGAGRRFPDVSKTFWGFYDIVEATSEHTYTFDSELLHEKWN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTTGGCCGTCTTGCCGACTTTGACGCCATTGACGCCGGTGCGGGCAGACGCTTCCCCGACGTGAGCAAGACCTTCTGGGGCTTCTACGACATCGTTGAGGCAACCAGCGAACATACTTACACCTTCGACAGCGAGCTGCTGCACGAAAAGTGGAACTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 2610,
      "end": 3575,
      "strand": 1,
      "locus_tag": "ctg125_5",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,610 - 3,575,\n (total: 966 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=LENRERESFFLIITSAVSGRPLSAQERARYAPDMLPTMSALARRHDLTHLLALGLKNNGLCGEQGKELDNEMFRAAFRCEQLEHELKKICGTLEKARIPFIPLKGSVLRRYYPEPWMRTSCDIDVFVREADLDRAMEALSENLSYRIGEISDHDVQIYTPNGQHIELHRNLIEDHRINQAAEVLAAVWDTAIPHSGWTYWLEMPDELFYFYHIAHMAKHVDNGGCGIRPFLDIWVLTHRVPHDRDKREQLLADGGLSTFAKQAERLTEVWFGNAAHDEATRRLERYILYGGVYGTVDNRMSVRQAKSGGKLRYAWSRIWLP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"LENRERESFFLIITSAVSGRPLSAQERARYAPDMLPTMSALARRHDLTHLLALGLKNNGLCGEQGKELDNEMFRAAFRCEQLEHELKKICGTLEKARIPFIPLKGSVLRRYYPEPWMRTSCDIDVFVREADLDRAMEALSENLSYRIGEISDHDVQIYTPNGQHIELHRNLIEDHRINQAAEVLAAVWDTAIPHSGWTYWLEMPDELFYFYHIAHMAKHVDNGGCGIRPFLDIWVLTHRVPHDRDKREQLLADGGLSTFAKQAERLTEVWFGNAAHDEATRRLERYILYGGVYGTVDNRMSVRQAKSGGKLRYAWSRIWLP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"TTGGAAAACAGAGAGCGTGAGAGTTTCTTTCTTATCATCACTTCGGCGGTCAGCGGACGTCCGCTTTCCGCGCAGGAGCGTGCGCGCTATGCCCCGGATATGCTGCCCACCATGAGTGCGCTTGCGCGGCGGCATGACCTCACGCACCTGCTTGCGCTCGGTTTGAAAAACAACGGTCTTTGCGGTGAGCAGGGCAAGGAGCTTGACAACGAAATGTTCCGTGCGGCCTTCCGCTGTGAGCAGCTCGAGCATGAGCTGAAAAAAATCTGCGGAACGCTTGAAAAGGCTCGGATCCCCTTTATTCCCCTGAAAGGCTCGGTGCTCCGCCGGTACTATCCCGAGCCGTGGATGCGGACAAGCTGCGATATCGACGTATTTGTCCGTGAGGCAGATCTGGACAGGGCGATGGAGGCGCTTTCGGAGAACCTTTCGTACCGGATCGGGGAGATCTCTGACCATGATGTCCAGATCTATACCCCAAACGGACAGCATATCGAGCTGCACCGGAACCTCATTGAGGATCACCGGATCAATCAGGCGGCGGAGGTGCTGGCGGCAGTGTGGGATACCGCAATTCCGCACAGCGGCTGGACATACTGGCTGGAAATGCCGGACGAGCTGTTCTATTTCTACCACATCGCACATATGGCAAAGCACGTCGATAACGGCGGCTGCGGTATCCGCCCCTTCCTGGATATCTGGGTGCTGACGCACCGTGTCCCGCACGACCGGGACAAGCGGGAACAGCTCCTCGCGGACGGCGGACTGTCCACATTTGCGAAGCAGGCGGAGCGGCTGACCGAGGTGTGGTTCGGGAACGCCGCGCACGACGAGGCGACGCGCCGTCTGGAACGCTATATCCTGTACGGCGGCGTATATGGCACGGTGGATAATCGGATGTCGGTGCGGCAGGCCAAAAGCGGCGGAAAGCTGCGTTATGCGTGGTCCCGCATCTGGCTTCCCTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 3551,
      "end": 4474,
      "strand": 1,
      "locus_tag": "ctg125_6",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,551 - 4,474,\n (total: 924 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Polysacc_synt_2<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VVPHLASLNGCKRFVLISTDKAVNPTNIMGASKRLCEMIIQSFSRKIHDGKADELPPLHVHSSDESGSMREIMKSAKNAKTEFVAVRFGNVLGSNGSVVPRFKEQIAKGGPVTVTHPDVIRYFMTIPEAAALVLQAGTYAKGGEIFVLDMGSPVKIDTLARNLIKLSGLRPDVDIKIEYTGLRPGEKLYEERLMSEEGLRTTPNQLIHIGSPIRFDTDVFLRQLQMLMKAAYAGNEEELRAQVERVVTTYQPAGRHGSEHKGEAFEKQMELVEHKEAQREGTPRRHEGRRGNYGARSLPRHEAAVKE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VVPHLASLNGCKRFVLISTDKAVNPTNIMGASKRLCEMIIQSFSRKIHDGKADELPPLHVHSSDESGSMREIMKSAKNAKTEFVAVRFGNVLGSNGSVVPRFKEQIAKGGPVTVTHPDVIRYFMTIPEAAALVLQAGTYAKGGEIFVLDMGSPVKIDTLARNLIKLSGLRPDVDIKIEYTGLRPGEKLYEERLMSEEGLRTTPNQLIHIGSPIRFDTDVFLRQLQMLMKAAYAGNEEELRAQVERVVTTYQPAGRHGSEHKGEAFEKQMELVEHKEAQREGTPRRHEGRRGNYGARSLPRHEAAVKE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGGTCCCGCATCTGGCTTCCCTAAACGGCTGCAAGCGCTTTGTTCTGATCTCGACCGACAAGGCGGTGAACCCCACGAACATCATGGGCGCGTCCAAGCGCCTGTGCGAGATGATCATTCAGTCGTTCAGCCGCAAGATCCACGACGGCAAGGCGGACGAGCTGCCGCCGCTTCACGTGCACAGCAGCGACGAGAGCGGCAGTATGCGCGAGATCATGAAGTCCGCCAAAAATGCGAAAACCGAGTTTGTGGCCGTGCGCTTCGGCAATGTCCTCGGCAGCAACGGCTCTGTCGTGCCGCGCTTTAAGGAGCAGATCGCAAAGGGCGGCCCGGTGACGGTCACGCACCCCGATGTCATCCGCTACTTCATGACGATCCCGGAAGCCGCCGCGCTTGTCCTGCAGGCGGGAACCTATGCGAAGGGCGGGGAGATCTTCGTGCTCGACATGGGCTCCCCCGTAAAGATCGACACGCTTGCGCGAAATCTGATCAAGCTCTCGGGTCTGCGCCCCGACGTGGATATCAAAATCGAGTATACGGGCCTGCGCCCCGGCGAGAAGCTGTATGAAGAAAGGCTGATGTCGGAGGAGGGCCTGCGCACAACGCCGAACCAGCTGATCCATATCGGCAGCCCGATCCGTTTCGATACGGATGTTTTTCTCAGACAGCTGCAAATGCTCATGAAGGCGGCCTATGCCGGAAACGAAGAGGAACTCCGCGCGCAGGTCGAACGCGTGGTCACGACCTATCAGCCTGCCGGAAGACATGGCTCAGAGCACAAGGGTGAAGCCTTTGAGAAGCAGATGGAGCTTGTCGAGCATAAGGAGGCCCAAAGGGAAGGCACACCGCGGCGTCATGAAGGCCGTCGGGGAAACTACGGAGCAAGAAGCCTGCCCCGTCACGAGGCGGCGGTAAAAGAGTGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 4570,
      "end": 6288,
      "strand": -1,
      "locus_tag": "ctg125_7",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,570 - 6,288,\n (total: 1719 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIDNYRFSTLEYKRPDLEARRAKLAEWKNAAVHAESYAALRALMFEIDRETCELFTQYSIAHIRHTLDTRDEFYETEIAYLQDTLPTLSGAEVELSEAIASSPFRPDIEQEFGKQYFVSMDLQKKLYCEANVPLRQQESRLTNEYQKIMATAEIPFDGKTLNLYGLQKYFEHSDRAMRAAAVKAYSKFYEANEPRLEEIWDELIKIRNQMGKNLGYENYIPVGYLEQGRTDYGEQEVASFREQVRTVLVPLCKKLYDAQAKRLGVDHVMWYDEKMVFPDGNAEPAGDDAFMVKTAQKMYHEISPETGEFIDFMIDHELMDLQNKPGKASTGYMTSLPSLKAPFVFSCFNHTIFDMQVLTHELGHAFAGYMAMRSQPISDYYSESTDIAEIHSMSMEQFAYPYAEWFFGDQADKFRFAHLQEALTFVPFGVAVDEFQHICYAHPELTPKERTYQWHLLEEKYMPWRHYENDPFFERGGYWYHKLHIYLYPFYYINYTLTTMGAMEFKKKYAEDKAAAWQDYLNLCKTGGSRSYLETLRYANLSNPFEAGSVARACGYAEDILLKQIAEQAQNV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIDNYRFSTLEYKRPDLEARRAKLAEWKNAAVHAESYAALRALMFEIDRETCELFTQYSIAHIRHTLDTRDEFYETEIAYLQDTLPTLSGAEVELSEAIASSPFRPDIEQEFGKQYFVSMDLQKKLYCEANVPLRQQESRLTNEYQKIMATAEIPFDGKTLNLYGLQKYFEHSDRAMRAAAVKAYSKFYEANEPRLEEIWDELIKIRNQMGKNLGYENYIPVGYLEQGRTDYGEQEVASFREQVRTVLVPLCKKLYDAQAKRLGVDHVMWYDEKMVFPDGNAEPAGDDAFMVKTAQKMYHEISPETGEFIDFMIDHELMDLQNKPGKASTGYMTSLPSLKAPFVFSCFNHTIFDMQVLTHELGHAFAGYMAMRSQPISDYYSESTDIAEIHSMSMEQFAYPYAEWFFGDQADKFRFAHLQEALTFVPFGVAVDEFQHICYAHPELTPKERTYQWHLLEEKYMPWRHYENDPFFERGGYWYHKLHIYLYPFYYINYTLTTMGAMEFKKKYAEDKAAAWQDYLNLCKTGGSRSYLETLRYANLSNPFEAGSVARACGYAEDILLKQIAEQAQNV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATAGACAATTACAGGTTCTCAACACTCGAATACAAGCGCCCCGATCTGGAAGCGCGGCGCGCTAAGCTTGCCGAATGGAAAAACGCGGCTGTACACGCGGAGAGCTACGCCGCGCTGCGCGCGCTGATGTTTGAGATCGACCGCGAGACCTGCGAGCTGTTCACGCAGTATTCCATCGCACACATCCGGCATACGCTCGACACGCGCGACGAATTTTATGAGACGGAGATTGCCTATCTGCAGGACACGCTGCCCACGCTCAGCGGCGCGGAGGTCGAACTCAGCGAAGCCATTGCGTCCAGCCCCTTCCGCCCGGATATCGAGCAGGAGTTCGGCAAGCAGTATTTCGTCTCCATGGATCTGCAGAAGAAGCTGTACTGCGAGGCCAATGTTCCGCTGCGCCAGCAGGAGAGCCGCCTGACCAATGAATATCAGAAAATCATGGCCACAGCGGAAATACCGTTCGACGGCAAGACGCTGAACCTCTATGGCCTGCAGAAGTATTTTGAGCATTCCGACCGTGCGATGCGCGCTGCCGCCGTCAAGGCGTACTCCAAATTCTATGAGGCCAACGAGCCGCGTCTGGAGGAGATCTGGGACGAGCTGATCAAAATCCGCAACCAGATGGGCAAAAACCTCGGCTATGAGAACTACATCCCCGTCGGCTATCTGGAGCAGGGCCGCACGGATTACGGCGAACAGGAGGTCGCGTCTTTCCGCGAGCAGGTACGCACCGTTCTTGTTCCGCTGTGCAAGAAGCTCTATGACGCGCAGGCCAAGCGCCTTGGCGTTGATCACGTCATGTGGTACGACGAAAAGATGGTATTTCCGGATGGCAACGCTGAGCCTGCGGGTGACGACGCGTTCATGGTCAAGACCGCGCAGAAGATGTACCACGAGATCAGCCCGGAAACCGGCGAATTTATCGACTTCATGATCGACCATGAGCTGATGGATTTGCAGAACAAGCCCGGCAAGGCCTCCACCGGCTATATGACGAGTCTGCCCAGCCTGAAAGCACCGTTTGTGTTCTCCTGCTTTAACCATACGATTTTTGATATGCAGGTGCTGACGCACGAGCTGGGCCACGCGTTCGCGGGCTATATGGCCATGCGCAGCCAGCCCATTTCGGACTATTACAGCGAGTCGACCGATATTGCGGAGATCCACTCCATGTCCATGGAGCAGTTTGCCTATCCCTATGCCGAGTGGTTCTTCGGCGATCAGGCGGACAAGTTCCGCTTCGCACATCTGCAGGAGGCGCTGACCTTCGTGCCCTTCGGCGTGGCCGTGGACGAGTTCCAGCACATCTGCTATGCCCATCCTGAGCTGACGCCGAAGGAGCGGACATATCAGTGGCACCTGCTGGAGGAAAAGTATATGCCGTGGCGGCACTATGAGAACGACCCGTTCTTTGAACGCGGCGGCTACTGGTACCACAAGCTGCATATCTACCTCTATCCGTTCTACTATATCAACTACACGCTCACGACGATGGGCGCGATGGAGTTCAAGAAGAAGTACGCCGAGGATAAGGCCGCCGCATGGCAGGACTATCTGAACCTCTGCAAGACCGGCGGCAGCCGCAGCTATCTGGAGACGCTGCGCTATGCAAATCTGTCCAACCCCTTCGAGGCTGGCTCTGTCGCGCGTGCCTGCGGGTACGCGGAGGACATTCTGCTCAAGCAGATCGCGGAGCAGGCGCAGAACGTGTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 6411,
      "end": 6524,
      "strand": 1,
      "locus_tag": "ctg125_8",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,411 - 6,524,\n (total: 114 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MHMACRSCNKTYVNLQAHFPLDLTEAADGEIEVFLRVA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MHMACRSCNKTYVNLQAHFPLDLTEAADGEIEVFLRVA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCACATGGCCTGCCGCAGCTGCAATAAAACTTATGTAAACTTACAGGCCCATTTCCCGCTTGACCTCACCGAAGCAGCGGACGGCGAAATCGAGGTCTTCCTTCGTGTGGCC\">Copy to clipboard</span><br>\n</div>"
     }
    ],
    "clusters": [
     {
      "start": 1824,
      "end": 2091,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 6525,
      "product": "RRE-containing",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "ttaCodons": [],
    "type": "RRE-containing",
    "products": [
     "RRE-containing"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP RRE-containing",
    "anchor": "r125c1"
   }
  ]
 },
 {
  "length": 6496,
  "seq_id": "c00126_NODE_66..",
  "regions": []
 },
 {
  "length": 6441,
  "seq_id": "c00127_NODE_66..",
  "regions": []
 },
 {
  "length": 6436,
  "seq_id": "c00128_NODE_67..",
  "regions": []
 },
 {
  "length": 6428,
  "seq_id": "c00129_NODE_67..",
  "regions": []
 },
 {
  "length": 6408,
  "seq_id": "c00130_NODE_67..",
  "regions": []
 },
 {
  "length": 6380,
  "seq_id": "c00131_NODE_67..",
  "regions": []
 },
 {
  "length": 6337,
  "seq_id": "c00132_NODE_68..",
  "regions": []
 },
 {
  "length": 6330,
  "seq_id": "c00133_NODE_68..",
  "regions": []
 },
 {
  "length": 6318,
  "seq_id": "c00134_NODE_68..",
  "regions": []
 },
 {
  "length": 6239,
  "seq_id": "c00135_NODE_69..",
  "regions": []
 },
 {
  "length": 6226,
  "seq_id": "c00136_NODE_69..",
  "regions": []
 },
 {
  "length": 6173,
  "seq_id": "c00137_NODE_70..",
  "regions": []
 },
 {
  "length": 6139,
  "seq_id": "c00138_NODE_70..",
  "regions": []
 },
 {
  "length": 6108,
  "seq_id": "c00139_NODE_71..",
  "regions": []
 },
 {
  "length": 6034,
  "seq_id": "c00140_NODE_72..",
  "regions": []
 },
 {
  "length": 6012,
  "seq_id": "c00141_NODE_72..",
  "regions": []
 },
 {
  "length": 6009,
  "seq_id": "c00142_NODE_72..",
  "regions": []
 },
 {
  "length": 5953,
  "seq_id": "c00143_NODE_73..",
  "regions": []
 },
 {
  "length": 5836,
  "seq_id": "c00144_NODE_75..",
  "regions": []
 },
 {
  "length": 5777,
  "seq_id": "c00145_NODE_75..",
  "regions": []
 },
 {
  "length": 5759,
  "seq_id": "c00146_NODE_76..",
  "regions": []
 },
 {
  "length": 5714,
  "seq_id": "c00147_NODE_76..",
  "regions": []
 },
 {
  "length": 5577,
  "seq_id": "c00148_NODE_78..",
  "regions": []
 },
 {
  "length": 5576,
  "seq_id": "c00149_NODE_78..",
  "regions": [
   {
    "start": 1,
    "end": 5576,
    "idx": 1,
    "orfs": [
     {
      "start": 3,
      "end": 2315,
      "strand": -1,
      "locus_tag": "ctg149_1",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg149_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg149_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 2,315,\n (total: 2313 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: AMP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNVSFSTRGWQQIPWEQQVQMAETMRFGGVELYNVHKTPELTGRGGPLHRYTAAATARELWQKGLCIPCFDTACDIAGENCTETVTALMQLAHDVQCPYVSVTAQRDDDARISAALEALLPAAEAQGITILLKTSGVFSDTARLRTLLDAFACDQLGALWDMHHPYRDHGESADTTIKNLGAYVRHVHLRDSDDDGSYDLIGEGTLPVGSMMQALSSIDYDGYISLEWKPEWMPDLTDPEVIFPHFVNYMHRFDSPRGKKKTLYDNAAHTGKFVWKKDSLISETFPQVLDRMVEEFPDQYAFKYTTLDYTRTYAQFRDDVDDFARALVSLGVRRGSKVAIWATNVPAWFITFWAATKIGAVLVTVNTAYKIHEAEYLLRQSDTHTLVMIDHCLDSNYREIIQTLCPELADAKPGSALHCRKLPFLRNVITVGFRMPGCLTFDEAMDRANMVPREQILRMAAGVRPDDVCNMQYTSGTTGFPKGVMLTHYNVVNDGKCIGDRMDLSTADRMMIQVPMFHCFGMVLSMTSCMTHGATLCPMPYFSAKVSLACINQERITCFNGVPTMFIAMFNHPDYKKTDFSYMRTGIMAGSGCPPELMRRAAQPDEMHMTDIVSVYGQTESAPGSTMSACGDPLDLRCNTVGYAFPHIECKIIDPETGEEVPDGVNGEFCSRGYNTMKGYYKMPEATAATVDKEGWLHSGDLACRDENGCYRITGRLKDMIIRGGENIYPKEIEEFIYTHPAVKDVQVIGVPDKKYGEEAMACIILKEPGS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00149_NODE_78..&amp;from=0&amp;to=5576\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNVSFSTRGWQQIPWEQQVQMAETMRFGGVELYNVHKTPELTGRGGPLHRYTAAATARELWQKGLCIPCFDTACDIAGENCTETVTALMQLAHDVQCPYVSVTAQRDDDARISAALEALLPAAEAQGITILLKTSGVFSDTARLRTLLDAFACDQLGALWDMHHPYRDHGESADTTIKNLGAYVRHVHLRDSDDDGSYDLIGEGTLPVGSMMQALSSIDYDGYISLEWKPEWMPDLTDPEVIFPHFVNYMHRFDSPRGKKKTLYDNAAHTGKFVWKKDSLISETFPQVLDRMVEEFPDQYAFKYTTLDYTRTYAQFRDDVDDFARALVSLGVRRGSKVAIWATNVPAWFITFWAATKIGAVLVTVNTAYKIHEAEYLLRQSDTHTLVMIDHCLDSNYREIIQTLCPELADAKPGSALHCRKLPFLRNVITVGFRMPGCLTFDEAMDRANMVPREQILRMAAGVRPDDVCNMQYTSGTTGFPKGVMLTHYNVVNDGKCIGDRMDLSTADRMMIQVPMFHCFGMVLSMTSCMTHGATLCPMPYFSAKVSLACINQERITCFNGVPTMFIAMFNHPDYKKTDFSYMRTGIMAGSGCPPELMRRAAQPDEMHMTDIVSVYGQTESAPGSTMSACGDPLDLRCNTVGYAFPHIECKIIDPETGEEVPDGVNGEFCSRGYNTMKGYYKMPEATAATVDKEGWLHSGDLACRDENGCYRITGRLKDMIIRGGENIYPKEIEEFIYTHPAVKDVQVIGVPDKKYGEEAMACIILKEPGS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAATGTATCGTTTTCCACACGCGGCTGGCAGCAGATCCCCTGGGAGCAGCAGGTGCAGATGGCCGAGACCATGCGCTTCGGCGGCGTCGAGCTCTATAACGTCCACAAAACGCCGGAGCTGACCGGCCGCGGCGGCCCGCTGCACCGCTATACCGCCGCCGCGACGGCGCGGGAGCTCTGGCAGAAGGGCCTGTGCATCCCGTGCTTCGATACCGCCTGCGACATCGCGGGCGAGAACTGCACCGAGACCGTGACAGCCCTCATGCAGCTGGCGCACGACGTGCAGTGTCCGTATGTCTCCGTGACTGCGCAGCGCGATGACGACGCGCGGATCTCCGCCGCACTCGAAGCGCTCCTCCCCGCCGCCGAGGCGCAGGGGATCACGATCCTGCTCAAGACCAGCGGCGTCTTTTCCGACACGGCCCGGCTGCGCACGCTGCTCGATGCGTTTGCCTGCGACCAGCTGGGCGCGCTCTGGGATATGCACCATCCCTACCGGGACCACGGCGAATCCGCCGACACGACCATCAAAAACCTCGGTGCCTACGTCCGCCACGTTCACCTGCGCGACTCGGACGACGACGGCAGCTATGACCTCATCGGCGAGGGCACGCTGCCCGTCGGCAGCATGATGCAGGCACTGTCCTCCATCGACTATGACGGGTACATCTCGCTCGAGTGGAAGCCGGAATGGATGCCCGACCTGACCGACCCGGAGGTCATCTTCCCACATTTCGTCAACTACATGCACCGCTTCGATTCCCCGCGCGGCAAGAAAAAGACGCTCTACGACAACGCCGCGCATACCGGCAAGTTCGTCTGGAAGAAAGACAGCCTCATCTCCGAGACCTTCCCGCAGGTGCTCGACCGGATGGTCGAGGAATTCCCGGACCAGTACGCGTTCAAATACACGACGCTCGACTACACGCGGACCTACGCGCAGTTCCGCGACGACGTGGACGATTTTGCCCGCGCGCTCGTCTCGCTCGGCGTGCGCCGGGGCAGCAAGGTCGCCATCTGGGCTACGAACGTGCCCGCGTGGTTCATCACCTTCTGGGCCGCGACGAAGATCGGCGCCGTGCTCGTCACGGTCAACACGGCGTACAAGATCCATGAGGCGGAATATCTGCTGCGGCAGTCCGACACGCACACGCTCGTCATGATCGACCACTGTCTGGACTCGAACTACCGTGAGATCATCCAGACCCTCTGCCCGGAGCTGGCCGACGCAAAGCCCGGCTCCGCCCTGCACTGCCGCAAGCTGCCGTTCCTGCGCAACGTCATCACCGTCGGCTTCCGGATGCCGGGCTGCCTGACCTTCGACGAGGCGATGGATCGGGCCAATATGGTCCCGCGCGAGCAGATTTTGCGCATGGCCGCGGGCGTGCGGCCGGACGACGTGTGCAACATGCAGTACACTTCCGGCACAACGGGCTTCCCGAAGGGCGTCATGCTGACGCACTACAACGTCGTCAACGACGGCAAATGCATCGGCGACCGGATGGATCTGTCCACGGCCGACCGGATGATGATCCAGGTGCCGATGTTCCACTGCTTCGGCATGGTGCTCTCCATGACCTCCTGCATGACGCACGGCGCGACGCTCTGCCCGATGCCGTATTTCTCGGCCAAGGTCTCGCTCGCCTGCATCAATCAGGAGCGCATCACCTGCTTCAACGGTGTTCCGACGATGTTCATCGCCATGTTCAACCATCCGGACTACAAAAAGACCGATTTTTCCTACATGCGCACTGGCATCATGGCCGGTTCCGGCTGCCCGCCGGAGCTGATGCGCCGGGCTGCCCAGCCGGACGAGATGCACATGACCGACATCGTCAGCGTCTACGGCCAGACCGAATCCGCCCCCGGCAGCACCATGAGCGCCTGCGGCGACCCGCTCGATCTGCGGTGCAACACGGTCGGCTACGCTTTCCCGCACATCGAGTGCAAGATCATCGACCCCGAGACCGGCGAGGAAGTGCCGGACGGCGTCAACGGCGAGTTCTGCTCGCGCGGCTACAACACCATGAAAGGCTACTACAAGATGCCCGAGGCCACGGCCGCCACCGTTGACAAGGAGGGCTGGCTGCACTCCGGCGATCTGGCCTGCCGGGACGAAAACGGCTGCTACCGCATCACCGGGCGGCTGAAGGACATGATCATCCGCGGCGGCGAGAACATCTACCCCAAGGAGATTGAGGAATTCATCTACACCCACCCGGCCGTCAAGGACGTACAGGTCATCGGCGTGCCGGACAAGAAATACGGCGAGGAGGCCATGGCCTGCATCATCCTCAAGGAGCCCGGCAGC\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 2330,
      "end": 3748,
      "strand": -1,
      "locus_tag": "ctg149_2",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg149_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg149_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,330 - 3,748,\n (total: 1419 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: HMGL-like<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKHISVTDTTIRQAGKAAGYTLSFREKIELAKLLDRLGVSVIELHAVENPKIDSLLIKSVASAVKESAVCVPVALDPASVSLVWAALREAKHPRIQVPAPVSAVQMEYLAGKKPAAMLEAIRQTVAAARSVCEDVEFLADDATRADPAFLAEALQTAIAAGAAGVTVCDAAGSMLPDAFGSFVRGIYEAVPQTKDVRFGVSCSDALSMADACAVSAIAAGAGEIKAAAYCVDTANLAHMAKLLAAKAQDFGVVSTLQFTQMNRLLSQIAWMCQTGRSQLSPFDNGVQTSSGAVLTVHDTQEAVMKMAAALGYDLSEEDGAKVYEAFCRIAAKKQTVGEKELDAIIASAALQVPPTYRLESYVINTGNTISASAQMKLTKNGQTLSGVSLGDGPVDAAFLAIESILGRHYELDDFQIQAVTEGREAMGESVVKLRSGGKLYSGRGISTDIIGASVHAYLNAINKIVYEEAANA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00149_NODE_78..&amp;from=0&amp;to=5576\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKHISVTDTTIRQAGKAAGYTLSFREKIELAKLLDRLGVSVIELHAVENPKIDSLLIKSVASAVKESAVCVPVALDPASVSLVWAALREAKHPRIQVPAPVSAVQMEYLAGKKPAAMLEAIRQTVAAARSVCEDVEFLADDATRADPAFLAEALQTAIAAGAAGVTVCDAAGSMLPDAFGSFVRGIYEAVPQTKDVRFGVSCSDALSMADACAVSAIAAGAGEIKAAAYCVDTANLAHMAKLLAAKAQDFGVVSTLQFTQMNRLLSQIAWMCQTGRSQLSPFDNGVQTSSGAVLTVHDTQEAVMKMAAALGYDLSEEDGAKVYEAFCRIAAKKQTVGEKELDAIIASAALQVPPTYRLESYVINTGNTISASAQMKLTKNGQTLSGVSLGDGPVDAAFLAIESILGRHYELDDFQIQAVTEGREAMGESVVKLRSGGKLYSGRGISTDIIGASVHAYLNAINKIVYEEAANA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAACACATTTCCGTGACAGATACCACGATCCGCCAGGCGGGCAAGGCCGCGGGCTATACGCTCTCGTTCCGCGAGAAGATCGAGCTTGCCAAGCTCCTCGACCGGCTGGGCGTGAGCGTCATTGAGCTGCACGCGGTCGAAAACCCAAAGATCGACAGTCTGCTCATCAAATCCGTCGCCTCTGCGGTGAAGGAAAGCGCCGTGTGCGTGCCGGTCGCGCTGGACCCGGCGAGCGTATCGCTGGTCTGGGCCGCGCTCAGGGAGGCGAAGCACCCGCGCATCCAGGTCCCCGCGCCGGTCAGCGCCGTGCAGATGGAATACCTCGCGGGCAAAAAGCCCGCCGCCATGCTCGAGGCGATCCGCCAGACCGTCGCGGCGGCGCGGTCGGTCTGCGAGGACGTGGAATTCCTCGCGGACGACGCCACGCGCGCCGATCCCGCCTTCCTCGCTGAGGCGCTGCAGACCGCGATCGCGGCCGGTGCGGCCGGCGTGACCGTCTGCGACGCGGCGGGGAGCATGCTGCCGGACGCGTTCGGCAGCTTCGTGCGCGGGATCTATGAAGCCGTGCCGCAGACGAAGGACGTGCGCTTCGGCGTGAGCTGCTCGGACGCGCTGTCGATGGCGGACGCGTGCGCCGTGAGCGCCATCGCCGCCGGGGCCGGCGAGATCAAGGCCGCGGCCTACTGCGTCGACACTGCGAACCTCGCGCACATGGCGAAGCTGCTGGCGGCCAAAGCCCAGGACTTCGGCGTCGTCAGCACGCTGCAGTTCACGCAGATGAACCGCCTGCTGTCACAGATCGCCTGGATGTGTCAGACGGGCCGCAGCCAGCTCTCGCCGTTTGACAACGGCGTGCAGACCTCCTCCGGCGCAGTTTTGACCGTGCATGACACGCAGGAGGCCGTCATGAAGATGGCTGCCGCCCTCGGCTACGATCTTTCGGAGGAGGACGGGGCGAAGGTCTACGAGGCCTTCTGCCGCATCGCGGCGAAGAAGCAGACCGTGGGCGAGAAGGAGCTCGACGCCATCATCGCCTCCGCCGCGCTGCAGGTGCCGCCGACGTACCGGCTCGAAAGCTACGTCATCAACACCGGCAACACCATCAGCGCTTCGGCGCAGATGAAGCTCACGAAAAACGGCCAGACGCTCTCGGGCGTGAGCCTGGGCGACGGCCCGGTCGACGCGGCGTTCCTGGCCATCGAATCGATCCTCGGCCGCCATTACGAGCTGGACGATTTCCAGATTCAGGCCGTCACCGAGGGCCGCGAGGCCATGGGCGAGTCGGTCGTCAAGCTCCGCAGCGGCGGCAAGCTCTATTCCGGCCGCGGCATCTCGACCGATATCATCGGCGCGTCCGTGCACGCGTATCTCAACGCCATCAACAAGATCGTCTACGAAGAAGCGGCGAACGCCTGA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 4200,
      "end": 4517,
      "strand": 1,
      "locus_tag": "ctg149_3",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg149_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg149_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,200 - 4,517,\n (total: 318 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLHDIGGGVGHGRLQNKQEISHLRVAVVVKNRHSELKIVERRQRPPQQSVQNHRQLRARHRSVPAALTGTMAASSSMIRNRETQTFFMEHSSLYTPLSCILRPRV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00149_NODE_78..&amp;from=0&amp;to=5576\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLHDIGGGVGHGRLQNKQEISHLRVAVVVKNRHSELKIVERRQRPPQQSVQNHRQLRARHRSVPAALTGTMAASSSMIRNRETQTFFMEHSSLYTPLSCILRPRV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTCCACGACATCGGCGGTGGCGTGGGCCACGGCCGCCTCCAGAATAAGCAGGAAATATCACACCTGCGCGTCGCGGTTGTCGTCAAAAATCGGCATTCCGAGCTGAAGATCGTCGAGCGACGACAGCGTCCGCCCCAGCAGTCCGTTCAAAATCACCGCCAGCTGCGCGCACGTCACCGCAGCGTCCCAGCGGCGCTGACTGGCACAATGGCCGCCAGCAGCAGTATGATCAGAAACAGGGAAACGCAGACCTTTTTCATGGAACATTCCTCTTTGTATACCCCCCTATCCTGCATCCTCAGGCCTAGGGTGTAA\">Copy to clipboard</span><br>\n</div>"
     },
     {
      "start": 4649,
      "end": 5575,
      "strand": -1,
      "locus_tag": "ctg149_4",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg149_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg149_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,649 - 5,575,\n (total: 927 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=GELYIDGKLMNDVAPKDRDIAMVFQNYALYPHMTVYDNMAFSLKLKKTPKAEIDRKVREAAEILDITQYLNRKPKALSGGQRQRVAIGRAIVRNPKVFLMDEPLSNLDAKLRNQMRAEIIKLREKIDTTFIYVTHDQVEAMTLGDRIVIMRDGFIQQIGTPQEVFNHPANLFVAGFIGTPQMNFFDATLSKKGDKYVATVQGKDFELPADKQEALKKMDKVPVDIIAGVRPVHIHLSQDGIDAMVDVSELMGSELHLHVNSNGKDVVIVVPTTDIDLDAVHGSHKPVKYSFKPELMHFFDKETEKNLF&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00149_NODE_78..&amp;from=0&amp;to=5576\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"GELYIDGKLMNDVAPKDRDIAMVFQNYALYPHMTVYDNMAFSLKLKKTPKAEIDRKVREAAEILDITQYLNRKPKALSGGQRQRVAIGRAIVRNPKVFLMDEPLSNLDAKLRNQMRAEIIKLREKIDTTFIYVTHDQVEAMTLGDRIVIMRDGFIQQIGTPQEVFNHPANLFVAGFIGTPQMNFFDATLSKKGDKYVATVQGKDFELPADKQEALKKMDKVPVDIIAGVRPVHIHLSQDGIDAMVDVSELMGSELHLHVNSNGKDVVIVVPTTDIDLDAVHGSHKPVKYSFKPELMHFFDKETEKNLF\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GGCGAGCTGTACATCGACGGCAAGCTCATGAACGACGTGGCCCCGAAGGACCGCGACATCGCCATGGTCTTCCAGAACTACGCTCTGTATCCCCACATGACCGTTTATGATAACATGGCCTTCTCCCTGAAGCTGAAGAAGACCCCGAAGGCGGAAATCGACCGCAAGGTCCGTGAGGCCGCCGAGATCCTCGATATCACCCAGTACCTCAACCGTAAGCCGAAGGCTCTGTCCGGCGGCCAGCGCCAGCGTGTCGCTATCGGCCGCGCCATCGTCCGGAACCCGAAGGTCTTCCTGATGGACGAGCCGCTGTCCAACCTCGACGCCAAGCTGCGTAACCAGATGCGCGCTGAGATCATCAAGCTGCGCGAGAAGATCGACACCACCTTCATCTACGTCACCCACGACCAGGTCGAGGCCATGACCCTGGGCGACCGCATCGTCATCATGCGCGACGGCTTCATCCAGCAGATCGGCACCCCGCAGGAGGTCTTCAACCATCCGGCAAACCTCTTCGTCGCCGGCTTCATCGGCACGCCGCAGATGAACTTCTTTGACGCAACGCTGTCCAAGAAGGGCGACAAGTACGTCGCGACCGTGCAGGGCAAGGACTTCGAGCTGCCCGCCGACAAGCAGGAAGCGCTCAAGAAGATGGATAAGGTTCCCGTCGACATCATCGCCGGTGTCCGCCCGGTCCATATCCACCTGTCTCAGGACGGCATCGACGCCATGGTCGACGTCTCCGAGCTGATGGGCTCCGAGCTGCATCTGCACGTCAACTCCAACGGCAAGGACGTCGTCATCGTCGTCCCGACGACCGACATCGACCTCGACGCTGTCCACGGCAGCCACAAGCCCGTGAAGTACAGCTTCAAGCCCGAGCTGATGCACTTCTTCGACAAGGAAACCGAGAAGAACCTGTTCTGA\">Copy to clipboard</span><br>\n</div>"
     }
    ],
    "clusters": [
     {
      "start": 2,
      "end": 3748,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 5576,
      "product": "betalactone",
      "category": "other",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "ttaCodons": [],
    "type": "betalactone",
    "products": [
     "betalactone"
    ],
    "product_categories": [
     "other"
    ],
    "cssClass": "other betalactone",
    "anchor": "r149c1"
   }
  ]
 },
 {
  "length": 5565,
  "seq_id": "c00150_NODE_79..",
  "regions": []
 },
 {
  "length": 5465,
  "seq_id": "c00151_NODE_80..",
  "regions": []
 },
 {
  "length": 5452,
  "seq_id": "c00152_NODE_80..",
  "regions": []
 },
 {
  "length": 5439,
  "seq_id": "c00153_NODE_81..",
  "regions": []
 },
 {
  "length": 5397,
  "seq_id": "c00154_NODE_81..",
  "regions": []
 },
 {
  "length": 5390,
  "seq_id": "c00155_NODE_81..",
  "regions": []
 },
 {
  "length": 5342,
  "seq_id": "c00156_NODE_82..",
  "regions": []
 },
 {
  "length": 5250,
  "seq_id": "c00157_NODE_83..",
  "regions": []
 },
 {
  "length": 5208,
  "seq_id": "c00158_NODE_84..",
  "regions": []
 },
 {
  "length": 5167,
  "seq_id": "c00159_NODE_85..",
  "regions": []
 },
 {
  "length": 5155,
  "seq_id": "c00160_NODE_85..",
  "regions": []
 },
 {
  "length": 5078,
  "seq_id": "c00161_NODE_87..",
  "regions": []
 },
 {
  "length": 5011,
  "seq_id": "c00162_NODE_88..",
  "regions": []
 },
 {
  "length": 4946,
  "seq_id": "c00163_NODE_89..",
  "regions": []
 },
 {
  "length": 4944,
  "seq_id": "c00164_NODE_89..",
  "regions": []
 },
 {
  "length": 4906,
  "seq_id": "c00165_NODE_90..",
  "regions": []
 },
 {
  "length": 4887,
  "seq_id": "c00166_NODE_90..",
  "regions": []
 },
 {
  "length": 4872,
  "seq_id": "c00167_NODE_91..",
  "regions": []
 },
 {
  "length": 4861,
  "seq_id": "c00168_NODE_91..",
  "regions": []
 },
 {
  "length": 4849,
  "seq_id": "c00169_NODE_91..",
  "regions": []
 },
 {
  "length": 4812,
  "seq_id": "c00170_NODE_92..",
  "regions": []
 },
 {
  "length": 4807,
  "seq_id": "c00171_NODE_92..",
  "regions": []
 },
 {
  "length": 4787,
  "seq_id": "c00172_NODE_92..",
  "regions": []
 },
 {
  "length": 4728,
  "seq_id": "c00173_NODE_93..",
  "regions": []
 },
 {
  "length": 4720,
  "seq_id": "c00174_NODE_94..",
  "regions": []
 },
 {
  "length": 4689,
  "seq_id": "c00175_NODE_94..",
  "regions": []
 },
 {
  "length": 4670,
  "seq_id": "c00176_NODE_95..",
  "regions": []
 },
 {
  "length": 4614,
  "seq_id": "c00177_NODE_96..",
  "regions": []
 },
 {
  "length": 4606,
  "seq_id": "c00178_NODE_96..",
  "regions": []
 },
 {
  "length": 4604,
  "seq_id": "c00179_NODE_96..",
  "regions": []
 },
 {
  "length": 4536,
  "seq_id": "c00180_NODE_98..",
  "regions": []
 },
 {
  "length": 4456,
  "seq_id": "c00181_NODE_99..",
  "regions": []
 },
 {
  "length": 4439,
  "seq_id": "c00182_NODE_10..",
  "regions": []
 },
 {
  "length": 4427,
  "seq_id": "c00183_NODE_10..",
  "regions": []
 },
 {
  "length": 4403,
  "seq_id": "c00184_NODE_10..",
  "regions": []
 },
 {
  "length": 4394,
  "seq_id": "c00185_NODE_10..",
  "regions": []
 },
 {
  "length": 4383,
  "seq_id": "c00186_NODE_10..",
  "regions": []
 },
 {
  "length": 4371,
  "seq_id": "c00187_NODE_10..",
  "regions": []
 },
 {
  "length": 4358,
  "seq_id": "c00188_NODE_10..",
  "regions": []
 },
 {
  "length": 4287,
  "seq_id": "c00189_NODE_10..",
  "regions": []
 },
 {
  "length": 4282,
  "seq_id": "c00190_NODE_10..",
  "regions": []
 },
 {
  "length": 4217,
  "seq_id": "c00191_NODE_10..",
  "regions": []
 },
 {
  "length": 4212,
  "seq_id": "c00192_NODE_10..",
  "regions": []
 },
 {
  "length": 4203,
  "seq_id": "c00193_NODE_10..",
  "regions": []
 },
 {
  "length": 4164,
  "seq_id": "c00194_NODE_10..",
  "regions": []
 },
 {
  "length": 4126,
  "seq_id": "c00195_NODE_10..",
  "regions": []
 },
 {
  "length": 4079,
  "seq_id": "c00196_NODE_10..",
  "regions": []
 },
 {
  "length": 4040,
  "seq_id": "c00197_NODE_11..",
  "regions": []
 },
 {
  "length": 4039,
  "seq_id": "c00198_NODE_11..",
  "regions": []
 },
 {
  "length": 4023,
  "seq_id": "c00199_NODE_11..",
  "regions": []
 },
 {
  "length": 4000,
  "seq_id": "c00200_NODE_11..",
  "regions": []
 },
 {
  "length": 3952,
  "seq_id": "c00201_NODE_11..",
  "regions": []
 },
 {
  "length": 3933,
  "seq_id": "c00202_NODE_11..",
  "regions": []
 },
 {
  "length": 3926,
  "seq_id": "c00203_NODE_11..",
  "regions": []
 },
 {
  "length": 3871,
  "seq_id": "c00204_NODE_11..",
  "regions": []
 },
 {
  "length": 3843,
  "seq_id": "c00205_NODE_11..",
  "regions": []
 },
 {
  "length": 3842,
  "seq_id": "c00206_NODE_11..",
  "regions": []
 },
 {
  "length": 3810,
  "seq_id": "c00207_NODE_11..",
  "regions": []
 },
 {
  "length": 3793,
  "seq_id": "c00208_NODE_11..",
  "regions": []
 },
 {
  "length": 3766,
  "seq_id": "c00209_NODE_11..",
  "regions": []
 },
 {
  "length": 3671,
  "seq_id": "c00210_NODE_12..",
  "regions": []
 },
 {
  "length": 3652,
  "seq_id": "c00211_NODE_12..",
  "regions": []
 },
 {
  "length": 3462,
  "seq_id": "c00212_NODE_13..",
  "regions": []
 },
 {
  "length": 3454,
  "seq_id": "c00213_NODE_13..",
  "regions": []
 },
 {
  "length": 3430,
  "seq_id": "c00214_NODE_13..",
  "regions": []
 },
 {
  "length": 3316,
  "seq_id": "c00215_NODE_13..",
  "regions": []
 },
 {
  "length": 3287,
  "seq_id": "c00216_NODE_13..",
  "regions": []
 },
 {
  "length": 3279,
  "seq_id": "c00217_NODE_13..",
  "regions": []
 },
 {
  "length": 3278,
  "seq_id": "c00218_NODE_13..",
  "regions": []
 },
 {
  "length": 3239,
  "seq_id": "c00219_NODE_14..",
  "regions": []
 },
 {
  "length": 3225,
  "seq_id": "c00220_NODE_14..",
  "regions": []
 },
 {
  "length": 3211,
  "seq_id": "c00221_NODE_14..",
  "regions": []
 },
 {
  "length": 3156,
  "seq_id": "c00222_NODE_14..",
  "regions": []
 },
 {
  "length": 3151,
  "seq_id": "c00223_NODE_14..",
  "regions": []
 },
 {
  "length": 3149,
  "seq_id": "c00224_NODE_14..",
  "regions": []
 },
 {
  "length": 3073,
  "seq_id": "c00225_NODE_14..",
  "regions": []
 },
 {
  "length": 3061,
  "seq_id": "c00226_NODE_14..",
  "regions": []
 },
 {
  "length": 3043,
  "seq_id": "c00227_NODE_15..",
  "regions": []
 },
 {
  "length": 2992,
  "seq_id": "c00228_NODE_15..",
  "regions": []
 },
 {
  "length": 2978,
  "seq_id": "c00229_NODE_15..",
  "regions": []
 },
 {
  "length": 2965,
  "seq_id": "c00230_NODE_15..",
  "regions": []
 },
 {
  "length": 2923,
  "seq_id": "c00231_NODE_15..",
  "regions": []
 },
 {
  "length": 2840,
  "seq_id": "c00232_NODE_16..",
  "regions": []
 },
 {
  "length": 2838,
  "seq_id": "c00233_NODE_16..",
  "regions": []
 },
 {
  "length": 2835,
  "seq_id": "c00234_NODE_16..",
  "regions": []
 },
 {
  "length": 2834,
  "seq_id": "c00235_NODE_16..",
  "regions": []
 },
 {
  "length": 2831,
  "seq_id": "c00236_NODE_16..",
  "regions": []
 },
 {
  "length": 2826,
  "seq_id": "c00237_NODE_16..",
  "regions": []
 },
 {
  "length": 2823,
  "seq_id": "c00238_NODE_16..",
  "regions": []
 },
 {
  "length": 2821,
  "seq_id": "c00239_NODE_16..",
  "regions": []
 },
 {
  "length": 2784,
  "seq_id": "c00240_NODE_16..",
  "regions": []
 },
 {
  "length": 2777,
  "seq_id": "c00241_NODE_16..",
  "regions": []
 },
 {
  "length": 2762,
  "seq_id": "c00242_NODE_16..",
  "regions": []
 },
 {
  "length": 2761,
  "seq_id": "c00243_NODE_16..",
  "regions": []
 },
 {
  "length": 2749,
  "seq_id": "c00244_NODE_16..",
  "regions": []
 },
 {
  "length": 2712,
  "seq_id": "c00245_NODE_17..",
  "regions": []
 },
 {
  "length": 2710,
  "seq_id": "c00246_NODE_17..",
  "regions": []
 },
 {
  "length": 2692,
  "seq_id": "c00247_NODE_17..",
  "regions": []
 },
 {
  "length": 2690,
  "seq_id": "c00248_NODE_17..",
  "regions": []
 },
 {
  "length": 2653,
  "seq_id": "c00249_NODE_17..",
  "regions": []
 },
 {
  "length": 2629,
  "seq_id": "c00250_NODE_17..",
  "regions": []
 },
 {
  "length": 2627,
  "seq_id": "c00251_NODE_17..",
  "regions": []
 },
 {
  "length": 2598,
  "seq_id": "c00252_NODE_17..",
  "regions": []
 },
 {
  "length": 2586,
  "seq_id": "c00253_NODE_18..",
  "regions": []
 },
 {
  "length": 2569,
  "seq_id": "c00254_NODE_18..",
  "regions": []
 },
 {
  "length": 2565,
  "seq_id": "c00255_NODE_18..",
  "regions": []
 },
 {
  "length": 2546,
  "seq_id": "c00256_NODE_18..",
  "regions": []
 },
 {
  "length": 2546,
  "seq_id": "c00257_NODE_18..",
  "regions": []
 },
 {
  "length": 2523,
  "seq_id": "c00258_NODE_18..",
  "regions": []
 },
 {
  "length": 2511,
  "seq_id": "c00259_NODE_18..",
  "regions": []
 },
 {
  "length": 2469,
  "seq_id": "c00260_NODE_18..",
  "regions": []
 },
 {
  "length": 2409,
  "seq_id": "c00261_NODE_19..",
  "regions": []
 },
 {
  "length": 2405,
  "seq_id": "c00262_NODE_19..",
  "regions": []
 },
 {
  "length": 2370,
  "seq_id": "c00263_NODE_19..",
  "regions": []
 },
 {
  "length": 2368,
  "seq_id": "c00264_NODE_19..",
  "regions": []
 },
 {
  "length": 2339,
  "seq_id": "c00265_NODE_20..",
  "regions": []
 },
 {
  "length": 2304,
  "seq_id": "c00266_NODE_20..",
  "regions": []
 },
 {
  "length": 2218,
  "seq_id": "c00267_NODE_21..",
  "regions": []
 },
 {
  "length": 2199,
  "seq_id": "c00268_NODE_21..",
  "regions": []
 },
 {
  "length": 2186,
  "seq_id": "c00269_NODE_21..",
  "regions": []
 },
 {
  "length": 2164,
  "seq_id": "c00270_NODE_22..",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r125c1",
  "r149c1"
 ],
 "r125c1": {
  "start": 1,
  "end": 6525,
  "idx": 1,
  "orfs": [
   {
    "start": 3,
    "end": 680,
    "strand": 1,
    "locus_tag": "ctg125_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 680,\n (total: 678 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=GIVPGAKLFGSEDLYADQYLFVNGYPKRILANGGTPVGILSSDGYAAEDSLSLCDAFVFCGGARFYPYHFQVMEYAAKSGKPVLGICLGMQMMNTYFLVAEEAERRGWDGPLLALFEQMKKERYMFTEPVDGHWDGHITRDNVDRFKHPIHITPGSRLERLTGKQTILGASMHNYRITHPARSLTVAGRTDDGIIEALEYGEQMLGVQFHPEADDQNDELFRAIL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"GIVPGAKLFGSEDLYADQYLFVNGYPKRILANGGTPVGILSSDGYAAEDSLSLCDAFVFCGGARFYPYHFQVMEYAAKSGKPVLGICLGMQMMNTYFLVAEEAERRGWDGPLLALFEQMKKERYMFTEPVDGHWDGHITRDNVDRFKHPIHITPGSRLERLTGKQTILGASMHNYRITHPARSLTVAGRTDDGIIEALEYGEQMLGVQFHPEADDQNDELFRAIL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GGGATCGTGCCGGGCGCAAAGCTGTTCGGCTCGGAGGATCTGTACGCGGATCAATATTTATTTGTAAACGGCTATCCGAAGCGGATTCTTGCAAACGGCGGCACGCCCGTCGGGATCCTCAGCAGCGACGGCTATGCGGCGGAGGACAGCCTTTCGCTCTGCGACGCGTTTGTGTTCTGCGGCGGGGCGCGGTTCTATCCGTACCATTTTCAGGTCATGGAGTACGCTGCGAAATCCGGCAAGCCCGTGCTCGGCATCTGCCTCGGGATGCAGATGATGAACACCTATTTCCTCGTTGCCGAAGAGGCCGAACGCCGCGGCTGGGACGGGCCGCTGCTCGCGCTGTTCGAGCAGATGAAAAAAGAGCGCTATATGTTCACCGAACCCGTGGACGGCCACTGGGACGGCCATATCACGCGGGACAATGTCGACCGCTTCAAGCATCCCATCCATATAACGCCCGGCAGCCGCCTCGAACGTCTGACAGGGAAGCAGACGATCCTGGGCGCGTCGATGCACAACTATCGTATTACGCACCCAGCCCGGTCGCTGACCGTCGCGGGCCGGACGGACGACGGCATCATCGAGGCGCTGGAATACGGTGAGCAGATGCTCGGCGTTCAGTTCCACCCCGAAGCCGACGACCAGAACGACGAACTGTTCCGCGCCATTCTGTGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 857,
    "end": 1828,
    "strand": 1,
    "locus_tag": "ctg125_2",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 857 - 1,828,\n (total: 972 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSNNHGDIVIEDTTINAGSAKGYGYGPFAFDVCGYSSYNGVSVTVKGNSVINGNIEISRSSNKSPVGLTLESGTVTGELKIDDSIKLGENTTITKSDSFKVAAPAGYKWDEGTLKKITYVAEAGGVKYESLQKAIDAAKSKAVVTMLADTRENVTISTPYNGLMLHASAAALGGRAYLFSGPCGRGKSTHTRLWQQTFGEAVQVFNDDKPALRRLDGRWFAYGTPWCGKDGINLNQKWPLGGICFLEKAQENRIRRLSAAEALPLILAQTTYRLQPHSMELLLASLDSLLREIPVFLLENRPEEAAARLSYDTMRRAAEEEGL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSNNHGDIVIEDTTINAGSAKGYGYGPFAFDVCGYSSYNGVSVTVKGNSVINGNIEISRSSNKSPVGLTLESGTVTGELKIDDSIKLGENTTITKSDSFKVAAPAGYKWDEGTLKKITYVAEAGGVKYESLQKAIDAAKSKAVVTMLADTRENVTISTPYNGLMLHASAAALGGRAYLFSGPCGRGKSTHTRLWQQTFGEAVQVFNDDKPALRRLDGRWFAYGTPWCGKDGINLNQKWPLGGICFLEKAQENRIRRLSAAEALPLILAQTTYRLQPHSMELLLASLDSLLREIPVFLLENRPEEAAARLSYDTMRRAAEEEGL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCCAACAACCACGGTGACATCGTGATCGAAGACACCACGATCAACGCTGGCAGCGCAAAGGGATACGGCTACGGCCCGTTCGCCTTCGACGTCTGCGGCTATAGCAGCTACAACGGTGTCTCCGTCACCGTCAAGGGCAACAGCGTCATCAACGGCAACATCGAGATTTCCCGCAGCAGCAATAAGAGTCCCGTTGGCCTGACGCTGGAGAGCGGCACGGTGACCGGCGAACTGAAGATCGACGACTCCATCAAGCTCGGCGAAAACACCACCATCACCAAGTCCGATTCCTTCAAAGTCGCAGCCCCCGCCGGCTACAAGTGGGACGAAGGCACGCTGAAGAAGATCACCTACGTTGCCGAAGCTGGCGGTGTCAAGTACGAATCCCTCCAGAAAGCCATCGACGCGGCCAAGTCTAAAGCGGTCGTCACGATGCTTGCTGATACCCGCGAGAATGTCACTATCAGTACACCCTACAACGGTCTGATGCTCCACGCGTCGGCGGCGGCGCTTGGGGGGAGGGCGTACCTCTTTTCCGGCCCCTGCGGGCGCGGAAAATCGACCCATACGCGTCTCTGGCAGCAGACGTTTGGAGAGGCCGTGCAGGTCTTCAATGACGATAAGCCCGCCCTCCGCCGTCTGGACGGCCGCTGGTTCGCCTACGGCACCCCGTGGTGCGGCAAGGACGGCATCAATCTCAACCAGAAATGGCCCCTCGGCGGCATCTGCTTTCTCGAAAAGGCGCAGGAGAACCGCATCCGCCGCCTGTCCGCCGCCGAGGCGCTGCCGCTGATTCTGGCGCAGACCACGTACCGGCTCCAGCCGCACAGTATGGAGCTTCTGCTCGCGTCGCTGGACAGCCTGCTGCGGGAAATTCCGGTCTTCCTGCTGGAAAACCGCCCGGAGGAAGCCGCCGCCCGCCTGAGCTATGACACCATGCGCCGCGCGGCGGAGGAGGAAGGACTATGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 1825,
    "end": 2091,
    "strand": 1,
    "locus_tag": "ctg125_3",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,825 - 2,091,\n (total: 267 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKLKENFVLRQVAGSYAVLAVGAASVDFNGMLTLNESGALLWRALEQGADRPALLAALTAEYDVSDAQAEQDIDEFLSTLQKAGCLEA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKLKENFVLRQVAGSYAVLAVGAASVDFNGMLTLNESGALLWRALEQGADRPALLAALTAEYDVSDAQAEQDIDEFLSTLQKAGCLEA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAACTCAAAGAAAACTTTGTTCTGCGTCAGGTGGCCGGCAGCTATGCCGTCCTCGCCGTCGGCGCAGCCAGCGTGGATTTTAACGGTATGCTGACGCTCAACGAATCCGGCGCGCTCCTATGGCGCGCGCTGGAACAGGGCGCCGACCGCCCCGCGCTCCTCGCCGCCCTCACCGCAGAATACGACGTATCTGACGCACAGGCCGAACAGGATATCGACGAATTTCTGTCCACCCTGCAAAAAGCCGGGTGCCTGGAGGCGTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 2379,
    "end": 2540,
    "strand": 1,
    "locus_tag": "ctg125_4",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,379 - 2,540,\n (total: 162 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLGRLADFDAIDAGAGRRFPDVSKTFWGFYDIVEATSEHTYTFDSELLHEKWN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLGRLADFDAIDAGAGRRFPDVSKTFWGFYDIVEATSEHTYTFDSELLHEKWN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTTGGCCGTCTTGCCGACTTTGACGCCATTGACGCCGGTGCGGGCAGACGCTTCCCCGACGTGAGCAAGACCTTCTGGGGCTTCTACGACATCGTTGAGGCAACCAGCGAACATACTTACACCTTCGACAGCGAGCTGCTGCACGAAAAGTGGAACTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 2610,
    "end": 3575,
    "strand": 1,
    "locus_tag": "ctg125_5",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,610 - 3,575,\n (total: 966 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=LENRERESFFLIITSAVSGRPLSAQERARYAPDMLPTMSALARRHDLTHLLALGLKNNGLCGEQGKELDNEMFRAAFRCEQLEHELKKICGTLEKARIPFIPLKGSVLRRYYPEPWMRTSCDIDVFVREADLDRAMEALSENLSYRIGEISDHDVQIYTPNGQHIELHRNLIEDHRINQAAEVLAAVWDTAIPHSGWTYWLEMPDELFYFYHIAHMAKHVDNGGCGIRPFLDIWVLTHRVPHDRDKREQLLADGGLSTFAKQAERLTEVWFGNAAHDEATRRLERYILYGGVYGTVDNRMSVRQAKSGGKLRYAWSRIWLP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"LENRERESFFLIITSAVSGRPLSAQERARYAPDMLPTMSALARRHDLTHLLALGLKNNGLCGEQGKELDNEMFRAAFRCEQLEHELKKICGTLEKARIPFIPLKGSVLRRYYPEPWMRTSCDIDVFVREADLDRAMEALSENLSYRIGEISDHDVQIYTPNGQHIELHRNLIEDHRINQAAEVLAAVWDTAIPHSGWTYWLEMPDELFYFYHIAHMAKHVDNGGCGIRPFLDIWVLTHRVPHDRDKREQLLADGGLSTFAKQAERLTEVWFGNAAHDEATRRLERYILYGGVYGTVDNRMSVRQAKSGGKLRYAWSRIWLP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"TTGGAAAACAGAGAGCGTGAGAGTTTCTTTCTTATCATCACTTCGGCGGTCAGCGGACGTCCGCTTTCCGCGCAGGAGCGTGCGCGCTATGCCCCGGATATGCTGCCCACCATGAGTGCGCTTGCGCGGCGGCATGACCTCACGCACCTGCTTGCGCTCGGTTTGAAAAACAACGGTCTTTGCGGTGAGCAGGGCAAGGAGCTTGACAACGAAATGTTCCGTGCGGCCTTCCGCTGTGAGCAGCTCGAGCATGAGCTGAAAAAAATCTGCGGAACGCTTGAAAAGGCTCGGATCCCCTTTATTCCCCTGAAAGGCTCGGTGCTCCGCCGGTACTATCCCGAGCCGTGGATGCGGACAAGCTGCGATATCGACGTATTTGTCCGTGAGGCAGATCTGGACAGGGCGATGGAGGCGCTTTCGGAGAACCTTTCGTACCGGATCGGGGAGATCTCTGACCATGATGTCCAGATCTATACCCCAAACGGACAGCATATCGAGCTGCACCGGAACCTCATTGAGGATCACCGGATCAATCAGGCGGCGGAGGTGCTGGCGGCAGTGTGGGATACCGCAATTCCGCACAGCGGCTGGACATACTGGCTGGAAATGCCGGACGAGCTGTTCTATTTCTACCACATCGCACATATGGCAAAGCACGTCGATAACGGCGGCTGCGGTATCCGCCCCTTCCTGGATATCTGGGTGCTGACGCACCGTGTCCCGCACGACCGGGACAAGCGGGAACAGCTCCTCGCGGACGGCGGACTGTCCACATTTGCGAAGCAGGCGGAGCGGCTGACCGAGGTGTGGTTCGGGAACGCCGCGCACGACGAGGCGACGCGCCGTCTGGAACGCTATATCCTGTACGGCGGCGTATATGGCACGGTGGATAATCGGATGTCGGTGCGGCAGGCCAAAAGCGGCGGAAAGCTGCGTTATGCGTGGTCCCGCATCTGGCTTCCCTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 3551,
    "end": 4474,
    "strand": 1,
    "locus_tag": "ctg125_6",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,551 - 4,474,\n (total: 924 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Polysacc_synt_2<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VVPHLASLNGCKRFVLISTDKAVNPTNIMGASKRLCEMIIQSFSRKIHDGKADELPPLHVHSSDESGSMREIMKSAKNAKTEFVAVRFGNVLGSNGSVVPRFKEQIAKGGPVTVTHPDVIRYFMTIPEAAALVLQAGTYAKGGEIFVLDMGSPVKIDTLARNLIKLSGLRPDVDIKIEYTGLRPGEKLYEERLMSEEGLRTTPNQLIHIGSPIRFDTDVFLRQLQMLMKAAYAGNEEELRAQVERVVTTYQPAGRHGSEHKGEAFEKQMELVEHKEAQREGTPRRHEGRRGNYGARSLPRHEAAVKE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VVPHLASLNGCKRFVLISTDKAVNPTNIMGASKRLCEMIIQSFSRKIHDGKADELPPLHVHSSDESGSMREIMKSAKNAKTEFVAVRFGNVLGSNGSVVPRFKEQIAKGGPVTVTHPDVIRYFMTIPEAAALVLQAGTYAKGGEIFVLDMGSPVKIDTLARNLIKLSGLRPDVDIKIEYTGLRPGEKLYEERLMSEEGLRTTPNQLIHIGSPIRFDTDVFLRQLQMLMKAAYAGNEEELRAQVERVVTTYQPAGRHGSEHKGEAFEKQMELVEHKEAQREGTPRRHEGRRGNYGARSLPRHEAAVKE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGGTCCCGCATCTGGCTTCCCTAAACGGCTGCAAGCGCTTTGTTCTGATCTCGACCGACAAGGCGGTGAACCCCACGAACATCATGGGCGCGTCCAAGCGCCTGTGCGAGATGATCATTCAGTCGTTCAGCCGCAAGATCCACGACGGCAAGGCGGACGAGCTGCCGCCGCTTCACGTGCACAGCAGCGACGAGAGCGGCAGTATGCGCGAGATCATGAAGTCCGCCAAAAATGCGAAAACCGAGTTTGTGGCCGTGCGCTTCGGCAATGTCCTCGGCAGCAACGGCTCTGTCGTGCCGCGCTTTAAGGAGCAGATCGCAAAGGGCGGCCCGGTGACGGTCACGCACCCCGATGTCATCCGCTACTTCATGACGATCCCGGAAGCCGCCGCGCTTGTCCTGCAGGCGGGAACCTATGCGAAGGGCGGGGAGATCTTCGTGCTCGACATGGGCTCCCCCGTAAAGATCGACACGCTTGCGCGAAATCTGATCAAGCTCTCGGGTCTGCGCCCCGACGTGGATATCAAAATCGAGTATACGGGCCTGCGCCCCGGCGAGAAGCTGTATGAAGAAAGGCTGATGTCGGAGGAGGGCCTGCGCACAACGCCGAACCAGCTGATCCATATCGGCAGCCCGATCCGTTTCGATACGGATGTTTTTCTCAGACAGCTGCAAATGCTCATGAAGGCGGCCTATGCCGGAAACGAAGAGGAACTCCGCGCGCAGGTCGAACGCGTGGTCACGACCTATCAGCCTGCCGGAAGACATGGCTCAGAGCACAAGGGTGAAGCCTTTGAGAAGCAGATGGAGCTTGTCGAGCATAAGGAGGCCCAAAGGGAAGGCACACCGCGGCGTCATGAAGGCCGTCGGGGAAACTACGGAGCAAGAAGCCTGCCCCGTCACGAGGCGGCGGTAAAAGAGTGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 4570,
    "end": 6288,
    "strand": -1,
    "locus_tag": "ctg125_7",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,570 - 6,288,\n (total: 1719 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIDNYRFSTLEYKRPDLEARRAKLAEWKNAAVHAESYAALRALMFEIDRETCELFTQYSIAHIRHTLDTRDEFYETEIAYLQDTLPTLSGAEVELSEAIASSPFRPDIEQEFGKQYFVSMDLQKKLYCEANVPLRQQESRLTNEYQKIMATAEIPFDGKTLNLYGLQKYFEHSDRAMRAAAVKAYSKFYEANEPRLEEIWDELIKIRNQMGKNLGYENYIPVGYLEQGRTDYGEQEVASFREQVRTVLVPLCKKLYDAQAKRLGVDHVMWYDEKMVFPDGNAEPAGDDAFMVKTAQKMYHEISPETGEFIDFMIDHELMDLQNKPGKASTGYMTSLPSLKAPFVFSCFNHTIFDMQVLTHELGHAFAGYMAMRSQPISDYYSESTDIAEIHSMSMEQFAYPYAEWFFGDQADKFRFAHLQEALTFVPFGVAVDEFQHICYAHPELTPKERTYQWHLLEEKYMPWRHYENDPFFERGGYWYHKLHIYLYPFYYINYTLTTMGAMEFKKKYAEDKAAAWQDYLNLCKTGGSRSYLETLRYANLSNPFEAGSVARACGYAEDILLKQIAEQAQNV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIDNYRFSTLEYKRPDLEARRAKLAEWKNAAVHAESYAALRALMFEIDRETCELFTQYSIAHIRHTLDTRDEFYETEIAYLQDTLPTLSGAEVELSEAIASSPFRPDIEQEFGKQYFVSMDLQKKLYCEANVPLRQQESRLTNEYQKIMATAEIPFDGKTLNLYGLQKYFEHSDRAMRAAAVKAYSKFYEANEPRLEEIWDELIKIRNQMGKNLGYENYIPVGYLEQGRTDYGEQEVASFREQVRTVLVPLCKKLYDAQAKRLGVDHVMWYDEKMVFPDGNAEPAGDDAFMVKTAQKMYHEISPETGEFIDFMIDHELMDLQNKPGKASTGYMTSLPSLKAPFVFSCFNHTIFDMQVLTHELGHAFAGYMAMRSQPISDYYSESTDIAEIHSMSMEQFAYPYAEWFFGDQADKFRFAHLQEALTFVPFGVAVDEFQHICYAHPELTPKERTYQWHLLEEKYMPWRHYENDPFFERGGYWYHKLHIYLYPFYYINYTLTTMGAMEFKKKYAEDKAAAWQDYLNLCKTGGSRSYLETLRYANLSNPFEAGSVARACGYAEDILLKQIAEQAQNV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATAGACAATTACAGGTTCTCAACACTCGAATACAAGCGCCCCGATCTGGAAGCGCGGCGCGCTAAGCTTGCCGAATGGAAAAACGCGGCTGTACACGCGGAGAGCTACGCCGCGCTGCGCGCGCTGATGTTTGAGATCGACCGCGAGACCTGCGAGCTGTTCACGCAGTATTCCATCGCACACATCCGGCATACGCTCGACACGCGCGACGAATTTTATGAGACGGAGATTGCCTATCTGCAGGACACGCTGCCCACGCTCAGCGGCGCGGAGGTCGAACTCAGCGAAGCCATTGCGTCCAGCCCCTTCCGCCCGGATATCGAGCAGGAGTTCGGCAAGCAGTATTTCGTCTCCATGGATCTGCAGAAGAAGCTGTACTGCGAGGCCAATGTTCCGCTGCGCCAGCAGGAGAGCCGCCTGACCAATGAATATCAGAAAATCATGGCCACAGCGGAAATACCGTTCGACGGCAAGACGCTGAACCTCTATGGCCTGCAGAAGTATTTTGAGCATTCCGACCGTGCGATGCGCGCTGCCGCCGTCAAGGCGTACTCCAAATTCTATGAGGCCAACGAGCCGCGTCTGGAGGAGATCTGGGACGAGCTGATCAAAATCCGCAACCAGATGGGCAAAAACCTCGGCTATGAGAACTACATCCCCGTCGGCTATCTGGAGCAGGGCCGCACGGATTACGGCGAACAGGAGGTCGCGTCTTTCCGCGAGCAGGTACGCACCGTTCTTGTTCCGCTGTGCAAGAAGCTCTATGACGCGCAGGCCAAGCGCCTTGGCGTTGATCACGTCATGTGGTACGACGAAAAGATGGTATTTCCGGATGGCAACGCTGAGCCTGCGGGTGACGACGCGTTCATGGTCAAGACCGCGCAGAAGATGTACCACGAGATCAGCCCGGAAACCGGCGAATTTATCGACTTCATGATCGACCATGAGCTGATGGATTTGCAGAACAAGCCCGGCAAGGCCTCCACCGGCTATATGACGAGTCTGCCCAGCCTGAAAGCACCGTTTGTGTTCTCCTGCTTTAACCATACGATTTTTGATATGCAGGTGCTGACGCACGAGCTGGGCCACGCGTTCGCGGGCTATATGGCCATGCGCAGCCAGCCCATTTCGGACTATTACAGCGAGTCGACCGATATTGCGGAGATCCACTCCATGTCCATGGAGCAGTTTGCCTATCCCTATGCCGAGTGGTTCTTCGGCGATCAGGCGGACAAGTTCCGCTTCGCACATCTGCAGGAGGCGCTGACCTTCGTGCCCTTCGGCGTGGCCGTGGACGAGTTCCAGCACATCTGCTATGCCCATCCTGAGCTGACGCCGAAGGAGCGGACATATCAGTGGCACCTGCTGGAGGAAAAGTATATGCCGTGGCGGCACTATGAGAACGACCCGTTCTTTGAACGCGGCGGCTACTGGTACCACAAGCTGCATATCTACCTCTATCCGTTCTACTATATCAACTACACGCTCACGACGATGGGCGCGATGGAGTTCAAGAAGAAGTACGCCGAGGATAAGGCCGCCGCATGGCAGGACTATCTGAACCTCTGCAAGACCGGCGGCAGCCGCAGCTATCTGGAGACGCTGCGCTATGCAAATCTGTCCAACCCCTTCGAGGCTGGCTCTGTCGCGCGTGCCTGCGGGTACGCGGAGGACATTCTGCTCAAGCAGATCGCGGAGCAGGCGCAGAACGTGTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 6411,
    "end": 6524,
    "strand": 1,
    "locus_tag": "ctg125_8",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg125_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg125_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,411 - 6,524,\n (total: 114 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MHMACRSCNKTYVNLQAHFPLDLTEAADGEIEVFLRVA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00125_NODE_66..&amp;from=0&amp;to=6525\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MHMACRSCNKTYVNLQAHFPLDLTEAADGEIEVFLRVA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCACATGGCCTGCCGCAGCTGCAATAAAACTTATGTAAACTTACAGGCCCATTTCCCGCTTGACCTCACCGAAGCAGCGGACGGCGAAATCGAGGTCTTCCTTCGTGTGGCC\">Copy to clipboard</span><br>\n</div>"
   }
  ],
  "clusters": [
   {
    "start": 1824,
    "end": 2091,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 6525,
    "product": "RRE-containing",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "ttaCodons": [],
  "type": "RRE-containing",
  "products": [
   "RRE-containing"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP RRE-containing",
  "anchor": "r125c1"
 },
 "r149c1": {
  "start": 1,
  "end": 5576,
  "idx": 1,
  "orfs": [
   {
    "start": 3,
    "end": 2315,
    "strand": -1,
    "locus_tag": "ctg149_1",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg149_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg149_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 2,315,\n (total: 2313 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: AMP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNVSFSTRGWQQIPWEQQVQMAETMRFGGVELYNVHKTPELTGRGGPLHRYTAAATARELWQKGLCIPCFDTACDIAGENCTETVTALMQLAHDVQCPYVSVTAQRDDDARISAALEALLPAAEAQGITILLKTSGVFSDTARLRTLLDAFACDQLGALWDMHHPYRDHGESADTTIKNLGAYVRHVHLRDSDDDGSYDLIGEGTLPVGSMMQALSSIDYDGYISLEWKPEWMPDLTDPEVIFPHFVNYMHRFDSPRGKKKTLYDNAAHTGKFVWKKDSLISETFPQVLDRMVEEFPDQYAFKYTTLDYTRTYAQFRDDVDDFARALVSLGVRRGSKVAIWATNVPAWFITFWAATKIGAVLVTVNTAYKIHEAEYLLRQSDTHTLVMIDHCLDSNYREIIQTLCPELADAKPGSALHCRKLPFLRNVITVGFRMPGCLTFDEAMDRANMVPREQILRMAAGVRPDDVCNMQYTSGTTGFPKGVMLTHYNVVNDGKCIGDRMDLSTADRMMIQVPMFHCFGMVLSMTSCMTHGATLCPMPYFSAKVSLACINQERITCFNGVPTMFIAMFNHPDYKKTDFSYMRTGIMAGSGCPPELMRRAAQPDEMHMTDIVSVYGQTESAPGSTMSACGDPLDLRCNTVGYAFPHIECKIIDPETGEEVPDGVNGEFCSRGYNTMKGYYKMPEATAATVDKEGWLHSGDLACRDENGCYRITGRLKDMIIRGGENIYPKEIEEFIYTHPAVKDVQVIGVPDKKYGEEAMACIILKEPGS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00149_NODE_78..&amp;from=0&amp;to=5576\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNVSFSTRGWQQIPWEQQVQMAETMRFGGVELYNVHKTPELTGRGGPLHRYTAAATARELWQKGLCIPCFDTACDIAGENCTETVTALMQLAHDVQCPYVSVTAQRDDDARISAALEALLPAAEAQGITILLKTSGVFSDTARLRTLLDAFACDQLGALWDMHHPYRDHGESADTTIKNLGAYVRHVHLRDSDDDGSYDLIGEGTLPVGSMMQALSSIDYDGYISLEWKPEWMPDLTDPEVIFPHFVNYMHRFDSPRGKKKTLYDNAAHTGKFVWKKDSLISETFPQVLDRMVEEFPDQYAFKYTTLDYTRTYAQFRDDVDDFARALVSLGVRRGSKVAIWATNVPAWFITFWAATKIGAVLVTVNTAYKIHEAEYLLRQSDTHTLVMIDHCLDSNYREIIQTLCPELADAKPGSALHCRKLPFLRNVITVGFRMPGCLTFDEAMDRANMVPREQILRMAAGVRPDDVCNMQYTSGTTGFPKGVMLTHYNVVNDGKCIGDRMDLSTADRMMIQVPMFHCFGMVLSMTSCMTHGATLCPMPYFSAKVSLACINQERITCFNGVPTMFIAMFNHPDYKKTDFSYMRTGIMAGSGCPPELMRRAAQPDEMHMTDIVSVYGQTESAPGSTMSACGDPLDLRCNTVGYAFPHIECKIIDPETGEEVPDGVNGEFCSRGYNTMKGYYKMPEATAATVDKEGWLHSGDLACRDENGCYRITGRLKDMIIRGGENIYPKEIEEFIYTHPAVKDVQVIGVPDKKYGEEAMACIILKEPGS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAATGTATCGTTTTCCACACGCGGCTGGCAGCAGATCCCCTGGGAGCAGCAGGTGCAGATGGCCGAGACCATGCGCTTCGGCGGCGTCGAGCTCTATAACGTCCACAAAACGCCGGAGCTGACCGGCCGCGGCGGCCCGCTGCACCGCTATACCGCCGCCGCGACGGCGCGGGAGCTCTGGCAGAAGGGCCTGTGCATCCCGTGCTTCGATACCGCCTGCGACATCGCGGGCGAGAACTGCACCGAGACCGTGACAGCCCTCATGCAGCTGGCGCACGACGTGCAGTGTCCGTATGTCTCCGTGACTGCGCAGCGCGATGACGACGCGCGGATCTCCGCCGCACTCGAAGCGCTCCTCCCCGCCGCCGAGGCGCAGGGGATCACGATCCTGCTCAAGACCAGCGGCGTCTTTTCCGACACGGCCCGGCTGCGCACGCTGCTCGATGCGTTTGCCTGCGACCAGCTGGGCGCGCTCTGGGATATGCACCATCCCTACCGGGACCACGGCGAATCCGCCGACACGACCATCAAAAACCTCGGTGCCTACGTCCGCCACGTTCACCTGCGCGACTCGGACGACGACGGCAGCTATGACCTCATCGGCGAGGGCACGCTGCCCGTCGGCAGCATGATGCAGGCACTGTCCTCCATCGACTATGACGGGTACATCTCGCTCGAGTGGAAGCCGGAATGGATGCCCGACCTGACCGACCCGGAGGTCATCTTCCCACATTTCGTCAACTACATGCACCGCTTCGATTCCCCGCGCGGCAAGAAAAAGACGCTCTACGACAACGCCGCGCATACCGGCAAGTTCGTCTGGAAGAAAGACAGCCTCATCTCCGAGACCTTCCCGCAGGTGCTCGACCGGATGGTCGAGGAATTCCCGGACCAGTACGCGTTCAAATACACGACGCTCGACTACACGCGGACCTACGCGCAGTTCCGCGACGACGTGGACGATTTTGCCCGCGCGCTCGTCTCGCTCGGCGTGCGCCGGGGCAGCAAGGTCGCCATCTGGGCTACGAACGTGCCCGCGTGGTTCATCACCTTCTGGGCCGCGACGAAGATCGGCGCCGTGCTCGTCACGGTCAACACGGCGTACAAGATCCATGAGGCGGAATATCTGCTGCGGCAGTCCGACACGCACACGCTCGTCATGATCGACCACTGTCTGGACTCGAACTACCGTGAGATCATCCAGACCCTCTGCCCGGAGCTGGCCGACGCAAAGCCCGGCTCCGCCCTGCACTGCCGCAAGCTGCCGTTCCTGCGCAACGTCATCACCGTCGGCTTCCGGATGCCGGGCTGCCTGACCTTCGACGAGGCGATGGATCGGGCCAATATGGTCCCGCGCGAGCAGATTTTGCGCATGGCCGCGGGCGTGCGGCCGGACGACGTGTGCAACATGCAGTACACTTCCGGCACAACGGGCTTCCCGAAGGGCGTCATGCTGACGCACTACAACGTCGTCAACGACGGCAAATGCATCGGCGACCGGATGGATCTGTCCACGGCCGACCGGATGATGATCCAGGTGCCGATGTTCCACTGCTTCGGCATGGTGCTCTCCATGACCTCCTGCATGACGCACGGCGCGACGCTCTGCCCGATGCCGTATTTCTCGGCCAAGGTCTCGCTCGCCTGCATCAATCAGGAGCGCATCACCTGCTTCAACGGTGTTCCGACGATGTTCATCGCCATGTTCAACCATCCGGACTACAAAAAGACCGATTTTTCCTACATGCGCACTGGCATCATGGCCGGTTCCGGCTGCCCGCCGGAGCTGATGCGCCGGGCTGCCCAGCCGGACGAGATGCACATGACCGACATCGTCAGCGTCTACGGCCAGACCGAATCCGCCCCCGGCAGCACCATGAGCGCCTGCGGCGACCCGCTCGATCTGCGGTGCAACACGGTCGGCTACGCTTTCCCGCACATCGAGTGCAAGATCATCGACCCCGAGACCGGCGAGGAAGTGCCGGACGGCGTCAACGGCGAGTTCTGCTCGCGCGGCTACAACACCATGAAAGGCTACTACAAGATGCCCGAGGCCACGGCCGCCACCGTTGACAAGGAGGGCTGGCTGCACTCCGGCGATCTGGCCTGCCGGGACGAAAACGGCTGCTACCGCATCACCGGGCGGCTGAAGGACATGATCATCCGCGGCGGCGAGAACATCTACCCCAAGGAGATTGAGGAATTCATCTACACCCACCCGGCCGTCAAGGACGTACAGGTCATCGGCGTGCCGGACAAGAAATACGGCGAGGAGGCCATGGCCTGCATCATCCTCAAGGAGCCCGGCAGC\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 2330,
    "end": 3748,
    "strand": -1,
    "locus_tag": "ctg149_2",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg149_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg149_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,330 - 3,748,\n (total: 1419 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) betalactone: HMGL-like<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKHISVTDTTIRQAGKAAGYTLSFREKIELAKLLDRLGVSVIELHAVENPKIDSLLIKSVASAVKESAVCVPVALDPASVSLVWAALREAKHPRIQVPAPVSAVQMEYLAGKKPAAMLEAIRQTVAAARSVCEDVEFLADDATRADPAFLAEALQTAIAAGAAGVTVCDAAGSMLPDAFGSFVRGIYEAVPQTKDVRFGVSCSDALSMADACAVSAIAAGAGEIKAAAYCVDTANLAHMAKLLAAKAQDFGVVSTLQFTQMNRLLSQIAWMCQTGRSQLSPFDNGVQTSSGAVLTVHDTQEAVMKMAAALGYDLSEEDGAKVYEAFCRIAAKKQTVGEKELDAIIASAALQVPPTYRLESYVINTGNTISASAQMKLTKNGQTLSGVSLGDGPVDAAFLAIESILGRHYELDDFQIQAVTEGREAMGESVVKLRSGGKLYSGRGISTDIIGASVHAYLNAINKIVYEEAANA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00149_NODE_78..&amp;from=0&amp;to=5576\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKHISVTDTTIRQAGKAAGYTLSFREKIELAKLLDRLGVSVIELHAVENPKIDSLLIKSVASAVKESAVCVPVALDPASVSLVWAALREAKHPRIQVPAPVSAVQMEYLAGKKPAAMLEAIRQTVAAARSVCEDVEFLADDATRADPAFLAEALQTAIAAGAAGVTVCDAAGSMLPDAFGSFVRGIYEAVPQTKDVRFGVSCSDALSMADACAVSAIAAGAGEIKAAAYCVDTANLAHMAKLLAAKAQDFGVVSTLQFTQMNRLLSQIAWMCQTGRSQLSPFDNGVQTSSGAVLTVHDTQEAVMKMAAALGYDLSEEDGAKVYEAFCRIAAKKQTVGEKELDAIIASAALQVPPTYRLESYVINTGNTISASAQMKLTKNGQTLSGVSLGDGPVDAAFLAIESILGRHYELDDFQIQAVTEGREAMGESVVKLRSGGKLYSGRGISTDIIGASVHAYLNAINKIVYEEAANA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAACACATTTCCGTGACAGATACCACGATCCGCCAGGCGGGCAAGGCCGCGGGCTATACGCTCTCGTTCCGCGAGAAGATCGAGCTTGCCAAGCTCCTCGACCGGCTGGGCGTGAGCGTCATTGAGCTGCACGCGGTCGAAAACCCAAAGATCGACAGTCTGCTCATCAAATCCGTCGCCTCTGCGGTGAAGGAAAGCGCCGTGTGCGTGCCGGTCGCGCTGGACCCGGCGAGCGTATCGCTGGTCTGGGCCGCGCTCAGGGAGGCGAAGCACCCGCGCATCCAGGTCCCCGCGCCGGTCAGCGCCGTGCAGATGGAATACCTCGCGGGCAAAAAGCCCGCCGCCATGCTCGAGGCGATCCGCCAGACCGTCGCGGCGGCGCGGTCGGTCTGCGAGGACGTGGAATTCCTCGCGGACGACGCCACGCGCGCCGATCCCGCCTTCCTCGCTGAGGCGCTGCAGACCGCGATCGCGGCCGGTGCGGCCGGCGTGACCGTCTGCGACGCGGCGGGGAGCATGCTGCCGGACGCGTTCGGCAGCTTCGTGCGCGGGATCTATGAAGCCGTGCCGCAGACGAAGGACGTGCGCTTCGGCGTGAGCTGCTCGGACGCGCTGTCGATGGCGGACGCGTGCGCCGTGAGCGCCATCGCCGCCGGGGCCGGCGAGATCAAGGCCGCGGCCTACTGCGTCGACACTGCGAACCTCGCGCACATGGCGAAGCTGCTGGCGGCCAAAGCCCAGGACTTCGGCGTCGTCAGCACGCTGCAGTTCACGCAGATGAACCGCCTGCTGTCACAGATCGCCTGGATGTGTCAGACGGGCCGCAGCCAGCTCTCGCCGTTTGACAACGGCGTGCAGACCTCCTCCGGCGCAGTTTTGACCGTGCATGACACGCAGGAGGCCGTCATGAAGATGGCTGCCGCCCTCGGCTACGATCTTTCGGAGGAGGACGGGGCGAAGGTCTACGAGGCCTTCTGCCGCATCGCGGCGAAGAAGCAGACCGTGGGCGAGAAGGAGCTCGACGCCATCATCGCCTCCGCCGCGCTGCAGGTGCCGCCGACGTACCGGCTCGAAAGCTACGTCATCAACACCGGCAACACCATCAGCGCTTCGGCGCAGATGAAGCTCACGAAAAACGGCCAGACGCTCTCGGGCGTGAGCCTGGGCGACGGCCCGGTCGACGCGGCGTTCCTGGCCATCGAATCGATCCTCGGCCGCCATTACGAGCTGGACGATTTCCAGATTCAGGCCGTCACCGAGGGCCGCGAGGCCATGGGCGAGTCGGTCGTCAAGCTCCGCAGCGGCGGCAAGCTCTATTCCGGCCGCGGCATCTCGACCGATATCATCGGCGCGTCCGTGCACGCGTATCTCAACGCCATCAACAAGATCGTCTACGAAGAAGCGGCGAACGCCTGA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 4200,
    "end": 4517,
    "strand": 1,
    "locus_tag": "ctg149_3",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg149_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg149_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,200 - 4,517,\n (total: 318 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLHDIGGGVGHGRLQNKQEISHLRVAVVVKNRHSELKIVERRQRPPQQSVQNHRQLRARHRSVPAALTGTMAASSSMIRNRETQTFFMEHSSLYTPLSCILRPRV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00149_NODE_78..&amp;from=0&amp;to=5576\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLHDIGGGVGHGRLQNKQEISHLRVAVVVKNRHSELKIVERRQRPPQQSVQNHRQLRARHRSVPAALTGTMAASSSMIRNRETQTFFMEHSSLYTPLSCILRPRV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTCCACGACATCGGCGGTGGCGTGGGCCACGGCCGCCTCCAGAATAAGCAGGAAATATCACACCTGCGCGTCGCGGTTGTCGTCAAAAATCGGCATTCCGAGCTGAAGATCGTCGAGCGACGACAGCGTCCGCCCCAGCAGTCCGTTCAAAATCACCGCCAGCTGCGCGCACGTCACCGCAGCGTCCCAGCGGCGCTGACTGGCACAATGGCCGCCAGCAGCAGTATGATCAGAAACAGGGAAACGCAGACCTTTTTCATGGAACATTCCTCTTTGTATACCCCCCTATCCTGCATCCTCAGGCCTAGGGTGTAA\">Copy to clipboard</span><br>\n</div>"
   },
   {
    "start": 4649,
    "end": 5575,
    "strand": -1,
    "locus_tag": "ctg149_4",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg149_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg149_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,649 - 5,575,\n (total: 927 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=GELYIDGKLMNDVAPKDRDIAMVFQNYALYPHMTVYDNMAFSLKLKKTPKAEIDRKVREAAEILDITQYLNRKPKALSGGQRQRVAIGRAIVRNPKVFLMDEPLSNLDAKLRNQMRAEIIKLREKIDTTFIYVTHDQVEAMTLGDRIVIMRDGFIQQIGTPQEVFNHPANLFVAGFIGTPQMNFFDATLSKKGDKYVATVQGKDFELPADKQEALKKMDKVPVDIIAGVRPVHIHLSQDGIDAMVDVSELMGSELHLHVNSNGKDVVIVVPTTDIDLDAVHGSHKPVKYSFKPELMHFFDKETEKNLF&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=c00149_NODE_78..&amp;from=0&amp;to=5576\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"GELYIDGKLMNDVAPKDRDIAMVFQNYALYPHMTVYDNMAFSLKLKKTPKAEIDRKVREAAEILDITQYLNRKPKALSGGQRQRVAIGRAIVRNPKVFLMDEPLSNLDAKLRNQMRAEIIKLREKIDTTFIYVTHDQVEAMTLGDRIVIMRDGFIQQIGTPQEVFNHPANLFVAGFIGTPQMNFFDATLSKKGDKYVATVQGKDFELPADKQEALKKMDKVPVDIIAGVRPVHIHLSQDGIDAMVDVSELMGSELHLHVNSNGKDVVIVVPTTDIDLDAVHGSHKPVKYSFKPELMHFFDKETEKNLF\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GGCGAGCTGTACATCGACGGCAAGCTCATGAACGACGTGGCCCCGAAGGACCGCGACATCGCCATGGTCTTCCAGAACTACGCTCTGTATCCCCACATGACCGTTTATGATAACATGGCCTTCTCCCTGAAGCTGAAGAAGACCCCGAAGGCGGAAATCGACCGCAAGGTCCGTGAGGCCGCCGAGATCCTCGATATCACCCAGTACCTCAACCGTAAGCCGAAGGCTCTGTCCGGCGGCCAGCGCCAGCGTGTCGCTATCGGCCGCGCCATCGTCCGGAACCCGAAGGTCTTCCTGATGGACGAGCCGCTGTCCAACCTCGACGCCAAGCTGCGTAACCAGATGCGCGCTGAGATCATCAAGCTGCGCGAGAAGATCGACACCACCTTCATCTACGTCACCCACGACCAGGTCGAGGCCATGACCCTGGGCGACCGCATCGTCATCATGCGCGACGGCTTCATCCAGCAGATCGGCACCCCGCAGGAGGTCTTCAACCATCCGGCAAACCTCTTCGTCGCCGGCTTCATCGGCACGCCGCAGATGAACTTCTTTGACGCAACGCTGTCCAAGAAGGGCGACAAGTACGTCGCGACCGTGCAGGGCAAGGACTTCGAGCTGCCCGCCGACAAGCAGGAAGCGCTCAAGAAGATGGATAAGGTTCCCGTCGACATCATCGCCGGTGTCCGCCCGGTCCATATCCACCTGTCTCAGGACGGCATCGACGCCATGGTCGACGTCTCCGAGCTGATGGGCTCCGAGCTGCATCTGCACGTCAACTCCAACGGCAAGGACGTCGTCATCGTCGTCCCGACGACCGACATCGACCTCGACGCTGTCCACGGCAGCCACAAGCCCGTGAAGTACAGCTTCAAGCCCGAGCTGATGCACTTCTTCGACAAGGAAACCGAGAAGAACCTGTTCTGA\">Copy to clipboard</span><br>\n</div>"
   }
  ],
  "clusters": [
   {
    "start": 2,
    "end": 3748,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 5576,
    "product": "betalactone",
    "category": "other",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "ttaCodons": [],
  "type": "betalactone",
  "products": [
   "betalactone"
  ],
  "product_categories": [
   "other"
  ],
  "cssClass": "other betalactone",
  "anchor": "r149c1"
 }
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
