var recordData = [
 {
  "length": 1796403,
  "seq_id": "NZ_CP085942.1",
  "regions": []
 },
 {
  "length": 1371824,
  "seq_id": "NZ_CP085943.1",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
