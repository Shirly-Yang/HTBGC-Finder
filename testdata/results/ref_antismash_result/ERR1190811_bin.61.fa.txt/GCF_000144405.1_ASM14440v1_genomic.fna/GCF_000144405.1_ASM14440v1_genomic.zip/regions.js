var recordData = [
 {
  "length": 1796408,
  "seq_id": "NC_014370.1",
  "regions": []
 },
 {
  "length": 1371874,
  "seq_id": "NC_014371.1",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
