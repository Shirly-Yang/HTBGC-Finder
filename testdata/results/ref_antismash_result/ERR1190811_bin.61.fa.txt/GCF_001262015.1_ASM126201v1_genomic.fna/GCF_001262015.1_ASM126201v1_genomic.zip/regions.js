var recordData = [
 {
  "length": 1828248,
  "seq_id": "NZ_CP012074.1",
  "regions": []
 },
 {
  "length": 1433558,
  "seq_id": "NZ_CP012075.1",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
